from __future__ import annotations

import bpy

NO_SERIES = "NONE"
"""Identifier used when no series is loaded.

It must not be the empty string. Blender silently *discards* enum items whose
identifier is empty, so a placeholder of "" left the enum with no items at all
and then rejected every assignment to it - including the assignment of "" that
was meant to clear it.
"""


def series_enum_items(self, context):
    scene = getattr(context, "scene", None)
    props = getattr(scene, "dicom_import_props", None) if scene else None
    items = []
    if props is not None:
        try:
            from . import previews as _previews
        except Exception:
            _previews = None
        for idx, entry in enumerate(props.series_items):
            if entry.uid:
                # An icon id of 0 means "no preview", and Blender draws the
                # item without one, so the enum works identically whether or
                # not previews have been built.
                icon = _previews.icon_for(entry.uid) if _previews else 0
                items.append((entry.uid, entry.label, "", icon, idx))
    if not items:
        items.append((NO_SERIES, "No series loaded", "", 0))
    return items


def has_series_selected(props) -> bool:
    """True when the user has actually chosen a series to import."""
    uid = str(getattr(props, "series_uid", "") or "")
    return bool(uid) and uid != NO_SERIES


RECONSTRUCTION_FILTER_ITEMS = (
    (
        "CUBIC",
        "Cubic (Catmull-Rom)",
        "C1 interpolating filter. Reconstructs the gradient across samples, so the "
        "surface lands between them instead of snapping to them. Best default",
    ),
    (
        "LANCZOS",
        "Lanczos",
        "Sharper frequency response than cubic; preserves fine trabecular texture "
        "but rings harder at bone/air edges",
    ),
    (
        "LINEAR",
        "Linear",
        "Fastest, but C0 only - the second derivative jumps at every cell boundary, "
        "which shows up as faceting on smooth anatomy",
    ),
)


class DICOMSeriesItem(bpy.types.PropertyGroup):
    uid: bpy.props.StringProperty()
    label: bpy.props.StringProperty()
    thumbnail: bpy.props.StringProperty(
        name="Thumbnail",
        default="",
        description=(
            (
                "The small picture shown in the series list, saved with the file"
            )
        ),
    )


def _push_volume_look(props, context):
    """Push the surface level, hardness and density onto every volume.

    Same mechanism as the cut, and a named function for the same reason: a
    lambda update callback is compiled where this module's globals are not
    visible, and Blender swallows the resulting NameError so the slider
    silently stops driving anything.
    """
    _push_volume_cut(props, context)


def _push_volume_cut(props, context):
    """Keep every imported volume's cut in step with the panel.

    The slider drives two different things that have to agree: Blender's own
    viewport slice, which costs nothing and shows in Solid shading, and a
    value in the material, which is what puts the same cut into a render.
    Driving only the first would give a volume that is cut on screen and whole
    in the render, which reads as a bug rather than as a setting.
    """
    try:
        import bpy as _bpy
    except Exception:
        return
    for obj in getattr(_bpy.data, "objects", []):
        if obj.type != "VOLUME" or not obj.get("dicom_volume"):
            continue
        data = obj.data
        try:
            data.display.use_slice = bool(props.volume_cut_enabled)
            data.display.slice_axis = str(props.volume_cut_axis)
            data.display.slice_depth = float(props.volume_cut_depth)
        except Exception:
            pass
        _push_cut_to_material(obj, props)

    # Surfaces meshed from a volume follow the same settings, so a cut or a
    # level change is not something that has to be redone on each of them.
    from .operators import _push_cut_to_surface

    for obj in getattr(_bpy.data, "objects", []):
        if obj.type == "MESH" and obj.get("dicom_volume_surface"):
            try:
                _push_cut_to_surface(obj, props)
            except Exception:
                pass


def _push_cut_to_material(obj, props):
    """Set the cut values every material on this volume reads.

    The nodes themselves are written by ``operators`` - the same function the
    material is built with - so that what import sets and what the panel sets
    later cannot drift apart.
    """
    from .operators import _push_cut_to_material_target

    for slot in getattr(obj, "material_slots", []):
        _push_cut_to_material_target(slot.material, props)


class DICOMImportProperties(bpy.types.PropertyGroup):
    source_path: bpy.props.StringProperty(
        name="Source Path",
        description=(
            "Folder holding the DICOM files, or a .zip of them"
        ),
        subtype="FILE_PATH",
    )
    source_is_zip: bpy.props.BoolProperty(
        description=(
            "Tick if the Source Path points at a .zip rather than a folder"
        ),
        name="Source Is Zip",
        default=False,
    )

    import_contrast: bpy.props.EnumProperty(
        name="Type",
        description=(
            (
                "Which kind of image to import. Water shows muscle and organs bright. "
                "Fat shows body fat and bone marrow bright. In phase shows both. Out "
                "of phase draws a dark line wherever fat and muscle meet"
            )
        ),
        items=[
            ("WATER", "Water", "Muscle, organs and vessels; fat suppressed"),
            ("FAT", "Fat", "Subcutaneous fat and marrow; muscle suppressed"),
            ("IN", "In phase", "Fat plus water summed"),
            ("OPP", "Out of phase", "Dark boundary line at every fat/water interface"),
        ],
        default="WATER",
    )
    place_in_patient_space: bpy.props.BoolProperty(
        name="Use Scanner Position",
        description=(
            (
                "Put each scan where the scanner says it belongs, so the separate "
                "parts of a long scan line up into one body and different image types "
                "sit on top of each other. Turn off to drop everything at the centre "
                "instead"
            )
        ),
        default=True,
    )
    series_items: bpy.props.CollectionProperty(type=DICOMSeriesItem)
    series_uid: bpy.props.EnumProperty(
        name="Series",
        items=series_enum_items,
        description=(
            "Which scan to use. The picture shows a slice from the middle of it"
        ),
    )

    threshold: bpy.props.FloatProperty(
        name="Threshold",
        default=100.0,
        description=(
            "Ignore anything darker than this. Raise it to drop faint tissue and "
            "background noise. Lower it to keep more, including things you may "
            "not want"
        ),
    )
    shading_correct: bpy.props.BoolProperty(
        name="Correct Coil Shading",
        description=(
            "Flatten the smooth brightness gradient the scanner's receive "
            "coil leaves across the image. The same tissue reads brighter "
            "near the coil than away from it - measured at 1.7 to 1 across "
            "one limb - so a single threshold lands at a different place "
            "depending on where it is, and the surface follows contours of "
            "the shading instead of the tissue. That is the broad banding on "
            "a surface that should be smooth, and smoothing cannot remove it "
            "because the shading is already smooth. Costs a few seconds"
        ),
        default=False,
    )
    shading_scale_mm: bpy.props.FloatProperty(
        name="Shading Scale (mm)",
        description=(
            "How broad a feature counts as shading rather than anatomy. "
            "Smaller flattens harder and starts removing real variation with "
            "it; larger leaves more of the gradient behind. Around 20mm suits "
            "a body coil"
        ),
        default=20.0, min=5.0, soft_max=80.0,
    )
    threshold_max: bpy.props.FloatProperty(
        name="Max Threshold",
        description=(
            "Ignore anything brighter than this, in the same units as "
            "Threshold. 0 turns it off. A lower threshold on its own cannot "
            "pick out something that is dimmer than its surroundings - on a "
            "T2 spine the bone marrow is well below the fat in the back, so "
            "every setting that keeps the bone keeps the fat too and the "
            "spine ends up buried inside it. Setting a top is what leaves it "
            "standing on its own"
        ),
        default=0.0, min=0.0, soft_max=5000.0,
    )
    stride: bpy.props.IntProperty(
        name="Stride",
        default=1,
        min=1,
        soft_max=8,
        description=(
            "Take every Nth voxel instead of all of them. 1 keeps everything. 2 "
            "gives about an eighth as many points and loads much faster. Raise it "
            "when a scan is too heavy to work with"
        ),
    )
    max_points: bpy.props.IntProperty(
        name="Max Points",
        default=30_000_000,
        min=0,
        soft_max=2000000,
        max=30000000,
        description=(
            "Stop after this many points. The cloud is thinned to fit. Lower it "
            "if Blender struggles; 0 means no limit"
        ),
    )
    safe_mode: bpy.props.BoolProperty(
        name="Safe Mode",
        default=True,
        description=(
            "Refuse to make a cloud bigger than the Safe Cap below. A guard "
            "against freezing Blender with a scan larger than expected"
        ),
    )
    safe_cap_points: bpy.props.IntProperty(
        name="Safe Cap",
        default=30_000_000,
        min=100000,
        soft_max=3000000,
        max=30000000,
        description=(
            "The most points Safe Mode will allow. Anything beyond this is "
            "thinned away at random"
        ),
    )
    point_radius_scale: bpy.props.FloatProperty(
        name="Point Radius",
        default=0.6,
        min=0.05,
        max=3.0,
        description=(
            "How big each point looks. Larger makes a sparse cloud look solid; "
            "smaller shows fine detail but can look see-through"
        ),
    )
    color_mode: bpy.props.EnumProperty(
        description=(
            "How the points are coloured in the viewport"
        ),
        name="Color Mode",
        items=(
            ("GRAYSCALE", "Grayscale", "Map low-to-high intensity to black-to-white"),
            ("HEAT", "Heat", "Map low-to-high intensity to cool-to-hot colors"),
        ),
        default="GRAYSCALE",
    )

    # --- Import-time volume super-resolution -----------------------------
    # Resampling the measured intensity field before thresholding is the most
    # accurate way to gain resolution: partial-volume effects mean a voxel
    # straddling the bone boundary reads part-way between bone and tissue, so an
    # interpolating filter recovers where the boundary is. Doing it after
    # thresholding throws that information away first.
    import_enhance_enabled: bpy.props.BoolProperty(
        name="Enhance Resolution",
        default=False,
        description=(
            (
                "Sharpen the scan by filling in between the measured slices before "
                "anything else happens. Slices are usually far thicker than the "
                "detail within them, and this is the only step that can recover "
                "anything in that direction. Costs memory and time. Applies to "
                "importing and to Import Segmented Features"
            )
        ),
    )

    local_intensity_bands: bpy.props.IntProperty(
        name="Ranges",
        default=4,
        min=2,
        max=32,
        description=(
            (
                "How many brightness groups to split the cloud into. Each becomes its "
                "own object, darkest first. More groups means finer distinctions "
                "between tissues; fewer means broader ones"
            )
        ),
    )

    # --- Surface Shell reconstruction ------------------------------------
    shell_resolution_multiplier: bpy.props.FloatProperty(
        name="Resolution Multiplier",
        default=2.0,
        min=0.25,
        soft_max=4.0,
        max=8.0,
        description=(
            (
                "How fine the mesh is relative to the scan. Higher gives more detail "
                "and takes longer; lower is faster and smoother. The detail you can "
                "get is still limited by Max Vertices"
            )
        ),
    )
    shell_isotropic: bpy.props.BoolProperty(
        name="Equalize Voxel Aspect",
        default=True,
        description=(
            (
                "Make voxels the same size in all directions before building the "
                "mesh. Leave on - without it the mesh inherits the scan's "
                "stair-stepping"
            )
        ),
    )
    shell_filter: bpy.props.EnumProperty(
        description=(
            "How to fill in between measured values when building the mesh. "
            "Cubic is a good default"
        ),
        name="Filter",
        items=RECONSTRUCTION_FILTER_ITEMS,
        default="CUBIC",
    )
    shell_clamp_overshoot: bpy.props.BoolProperty(
        name="Suppress Ringing",
        default=True,
        description=(
            "Stop the sharper filters overshooting at hard edges, which puts "
            "bumps and dents on the surface. Leave on"
        ),
    )
    last_warnings: bpy.props.StringProperty(
        name="Last Warnings",
        default="",
        description="What the last reconstruction warned about",
    )
    shell_surface_sigma: bpy.props.FloatProperty(
        name="Surface Smoothing",
        default=0.6,
        min=0.0,
        soft_max=1.5,
        max=3.0,
        description=(
            (
                "Blur the shape slightly before building the surface. Raise it for a "
                "smoother mesh; raise it too far and small details disappear entirely"
            )
        ),
    )
    shell_gap_bridge: bpy.props.IntProperty(
        name="Fill Holes",
        default=0,
        min=0,
        soft_max=3,
        max=8,
        description=(
            (
                "Whether gaps in the cloud are real or just missing samples. 0 treats "
                "them as real and never joins separate pieces - right for a cloud "
                "split by brightness. Raise it when a solid object is full of holes "
                "and meshes like a sponge; that fills the gaps but also merges things "
                "that sit close together"
            )
        ),
    )
    shell_cover_points: bpy.props.BoolProperty(
        name="Cover Every Point",
        description=(
            (
                "Guarantee every point ends up inside the mesh by wrapping a ball "
                "around each one. Use when you need all the data kept. The result is "
                "blobbier than the normal surface, and the speckle and island filters "
                "are turned off because they would remove points again"
            )
        ),
        default=False,
    )
    shell_cover_radius: bpy.props.FloatProperty(
        name="Cover Radius",
        description=(
            (
                "How big a ball to wrap around each point. Larger closes bigger gaps "
                "but thickens everything and can join separate structures"
            )
        ),
        default=1.0,
        min=0.5,
        soft_max=4.0,
        max=8.0,
    )
    shell_despeckle_min_voxels: bpy.props.IntProperty(
        name="Min Blob Voxels",
        default=8,
        min=0,
        soft_max=200,
        max=100000,
        description=(
            "Throw away isolated specks smaller than this before building the "
            "mesh. Raise it to clean up noise; lower it to keep genuinely tiny "
            "details"
        ),
    )
    shell_keep_cavities: bpy.props.BoolProperty(
        name="Keep Internal Cavities",
        default=True,
        description=(
            (
                "Keep hollow spaces inside the object, like an airway or a marrow "
                "cavity. Turn off to produce a solid shape with no interior surfaces"
            )
        ),
    )
    shell_cavity_min_volume: bpy.props.FloatProperty(
        name="Min Cavity Volume",
        default=8.0,
        min=0.0,
        soft_max=500.0,
        max=1000000.0,
        description=(
            (
                "Ignore hollow spaces smaller than this, treating them as noise "
                "rather than real cavities. Raise it if the inside of the mesh is "
                "full of tiny bubbles"
            )
        ),
    )
    mesh_max_vertices_m: bpy.props.IntProperty(
        name="Max Vertices (M)",
        default=6,
        min=1,
        soft_max=24,
        max=200,
        description=(
            (
                "Limit on mesh size, in millions of vertices. If the mesh would be "
                "bigger, the detail is reduced to fit. This is usually what decides "
                "how detailed your mesh actually gets - raise it for more detail if "
                "you have the memory"
            )
        ),
    )
    shell_min_island_volume: bpy.props.FloatProperty(
        name="Min Island Volume",
        default=20.0,
        min=0.0,
        soft_max=200.0,
        subtype="UNSIGNED",
        description=(
            (
                "Throw away loose pieces smaller than this. Raise it to remove "
                "floating scraps; lower it to keep small separate structures. 0 keeps "
                "everything, and is also the fastest since this is the slowest step"
            )
        ),
    )
    shell_voxel_budget_mv: bpy.props.IntProperty(
        name="Voxel Budget (M)",
        default=96,
        min=4,
        soft_max=256,
        max=2000,
        description=(
            (
                "Memory limit for building the mesh, in millions of voxels. Detail is "
                "reduced to fit rather than failing. Raise it if you have memory "
                "spare"
            )
        ),
    )

    # --- Point cloud shell / upsample operators --------------------------
    pc_shell_thickness: bpy.props.IntProperty(
        name="Shell Thickness",
        default=1,
        min=1,
        soft_max=5,
        max=64,
        description=(
            (
                "How thick a layer to keep at the surface. 1 keeps only the outermost "
                "points; higher keeps a thicker skin"
            )
        ),
    )
    pc_shell_output_suffix: bpy.props.StringProperty(
        name="Output Suffix",
        default="_surface",
        description=(
            "Added to the name of the new cloud"
        ),
    )
    pc_upsample_mode: bpy.props.EnumProperty(
        description=(
            "Solid fills the whole interior with points. Shell places them on "
            "the surface only"
        ),
        name="Upsample Mode",
        items=(
            (
                "SHELL",
                "Surface",
                "Emit points on the reconstructed surface. They sit on interpolated field "
                "crossings, so they are sub-voxel accurate and lie exactly on the anatomy",
            ),
            ("SOLID", "Solid", "Emit points throughout the material interior as well"),
        ),
        default="SHELL",
    )
    pc_upsample_max_points: bpy.props.IntProperty(
        name="Max Points",
        default=2000000,
        min=0,
        soft_max=5000000,
        max=30000000,
        description=(
            "Stop after this many points. 0 means no limit"
        ),
    )
    pc_upsample_output_suffix: bpy.props.StringProperty(
        name="Output Suffix",
        default="_dense",
        description=(
            "Added to the name of the new cloud"
        ),
    )
    mesh_smooth_strength: bpy.props.FloatProperty(
        name="Mesh Smoothing",
        default=0.35,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        description=(
            (
                "Smooth the finished mesh. Raise it to soften noise and bumps; raise "
                "it too far and real detail is rounded away. 0 leaves the mesh "
                "exactly as built"
            )
        ),
    )
    pc_filter_remove_percent: bpy.props.FloatProperty(
        name="Remove Percent",
        default=20.0,
        min=0.0,
        max=99.0,
        subtype="PERCENTAGE",
        description=(
            "What share of the points to delete, by brightness"
        ),
    )
    pc_filter_invert: bpy.props.BoolProperty(
        name="Invert (Remove Lightest)",
        default=False,
        description=(
            "Delete the brightest points instead of the darkest"
        ),
    )
    pc_filter_output_suffix: bpy.props.StringProperty(
        name="Output Suffix",
        default="_filtered",
        description=(
            "Added to the name of the new cloud"
        ),
    )
    mesh_hull_prefix: bpy.props.StringProperty(
        name="Hull Prefix",
        default="Hull_",
        description=(
            "Added to the front of each new mesh's name"
        ),
    )
    mesh_hull_hide_source: bpy.props.BoolProperty(
        name="Hide Source Clouds",
        default=False,
        description=(
            "Hide each point cloud once its mesh is built, so the mesh is not "
            "buried inside its own points"
        ),
    )
    progress_percent: bpy.props.FloatProperty(
        name="Segmentation Progress",
        default=0.0,
        min=0.0,
        max=100.0,
        subtype="PERCENTAGE",
    )
    segmentation_running: bpy.props.BoolProperty(
        name="Segmentation Running",
        default=False,
    )
    mesh_progress_percent: bpy.props.FloatProperty(
        name="Mesh Conversion Progress",
        default=0.0,
        min=0.0,
        max=100.0,
        subtype="PERCENTAGE",
    )
    mesh_conversion_running: bpy.props.BoolProperty(
        name="Mesh Conversion Running",
        default=False,
    )

    last_diagnostics: bpy.props.StringProperty(
        name="Last Diagnostics",
        default="",
        description=(
            (
                "Measurements from the last run, ready for the Copy Diagnostics "
                "button"
            )
        ),
    )
    muscle_boundary_cut: bpy.props.FloatProperty(
        name="Boundary Strength",
        description=(
            (
                "How clear the dividing line between two structures has to be before "
                "they are split apart. Raise it to split more aggressively into "
                "smaller pieces. Lower it to keep structures whole and risk "
                "neighbours being merged together. It will not go past the point "
                "where the tissue itself would vanish"
            )
        ),
        default=0.60, min=0.05, max=0.95,
    )
    muscle_boundary_fat: bpy.props.FloatProperty(
        name="Fat Plane Cut",
        description=(
            (
                "Treat a voxel as a dividing line once this much of it is fat. "
                "Structures are wrapped in thin layers of fat, and lowering this "
                "picks up thinner layers, so more things get separated. Raise it if "
                "things are being split that should be one piece. There is a "
                "floor to it in practice: past the point where the fat planes "
                "are thinner than a voxel, lowering it stops finding boundaries "
                "and starts emptying the inside of every structure instead, and "
                "the result goes back to one lump"
            )
        ),
        default=0.22, min=0.005, max=0.95,
    )
    muscle_link_fraction: bpy.props.FloatProperty(
        name="Slice Linking",
        description=(
            (
                "How much two shapes in neighbouring slices must overlap to be "
                "counted as the same structure. Raise it to keep structures apart "
                "that only touch slightly. Lower it to join shapes more readily, at "
                "the risk of chaining separate structures into one lump"
            )
        ),
        default=0.55, min=0.05, max=0.95,
    )
    muscle_max_fat_fraction: bpy.props.FloatProperty(
        name="Max Fat Fraction",
        description=(
            (
                "How much fat a voxel can contain and still count as muscle rather "
                "than body fat. Raise it to include fattier tissue; lower it to keep "
                "only lean muscle"
            )
        ),
        default=0.35, min=0.05, max=0.95,
    )
    muscle_min_volume: bpy.props.FloatProperty(
        name="Min Muscle (cm3)",
        description=(
            "Throw away separated pieces smaller than this, in cubic centimetres. "
            "Raise it to keep only substantial structures; lower it to keep small "
            "ones too"
        ),
        default=5.0, min=0.0, soft_max=100.0,
    )
    muscle_ct_mode: bpy.props.BoolProperty(
        name="CT Scan",
        description=(
            "Read the selected series as a CT rather than as MR. A CT is one "
            "image where the usual path wants three, but it is a measured "
            "one: the number in a voxel is Hounsfield units and means the "
            "same on every scanner - air about -1000, fat about -100, water "
            "0, muscle around +50, bone above +200. So the fat fraction that "
            "needs two MR series is read straight off a CT voxel, and the "
            "fat planes between muscles are the negative ones. Bone, muscle "
            "and fat are each segmented on their own and named for what they "
            "are, so a bone can never merge with the muscle beside it. "
            "Boundary Strength applies to muscle, the one class with "
            "boundaries running through it; bone and fat are already parted "
            "by being a different class. Only one series is read - the one "
            "selected above"
        ),
        default=False,
    )
    muscle_bone_core: bpy.props.FloatProperty(
        name="Min Bone Seed (cm3)",
        description=(
            "Smallest piece of cortex that seeds a bone of its own, when CT "
            "Scan is on. Below this it is treated as noise at the cortex "
            "level rather than a bone, and gets absorbed into whichever bone "
            "reaches it. Lower it to pick up smaller bones; raise it if one "
            "bone is coming apart into several"
        ),
        default=0.05, min=0.005, soft_max=2.0,
    )
    muscle_bone_cortex: bpy.props.FloatProperty(
        name="Cortex Level (HU)",
        description=(
            "How dense a voxel has to be to count as cortical bone, when CT "
            "Scan is on. Each bone is a shell of dense cortex around a softer "
            "middle, and at a joint two shells lie back to back with a gap - "
            "so the shells are still separate where the bones have merged, "
            "and each one seeds its own bone. Lower it if bones are coming "
            "out joined; raise it if one bone is splitting into several"
        ),
        default=700.0, min=200.0, soft_max=1500.0,
    )
    muscle_bone_refine: bpy.props.FloatProperty(
        name="Split Small Bones",
        description=(
            "Look at each bone again against its own density, to separate the "
            "ones a single cortex level cannot. A tarsal has thick dense "
            "cortex and a phalanx has a thin one that part-volumes down "
            "toward the marrow beside it, so no one level seeds both - set it "
            "high enough for the tarsals and a whole toe comes out as one "
            "piece. This is how far down from each piece's own dense level to "
            "look: near 1 splits only where the difference is clear, lower "
            "splits more and risks a bone coming apart at a dense patch. 0 "
            "turns it off"
        ),
        default=0.95, min=0.0, max=1.0,
    )
    volume_cache_dir: bpy.props.StringProperty(
        name="Volume Cache",
        description=(
            "Where the converted volumes are kept. Blender cannot read DICOM "
            "directly, so a scan shown as a volume is first written out as a "
            "VDB file - your DICOM folders are never copied or written to. "
            "The files here can be deleted at any time; anything still needed "
            "is simply made again. Leave this empty to use a folder beside "
            "Blender's own temporary files"
        ),
        default="",
        subtype="DIR_PATH",
    )
    volume_window: bpy.props.EnumProperty(
        name="Window",
        description=(
            "Which range of the scan to show. A CT measures in Hounsfield "
            "units, the same numbers on every scanner, so these are the "
            "standard radiology windows. Everything outside the window is "
            "dropped, which is also what keeps the file small. On an MR there "
            "is no calibrated scale to look a window up by, so the ends are "
            "taken from the scan itself whatever is picked here"
        ),
        items=[
            ("AUTO", "Auto (from the data)",
             "Take the ends from the scan itself"),
            ("MID", "Middle Of The Data",
             "Ignore the darkest and brightest tenth. Works on any scan"),
            ("BRIGHT", "Brightest Only",
             "Only the brighter half, for picking out dense structures. "
             "Works on any scan"),
            ("BONE", "Bone (CT only)",
             "Level 300, width 1500 - bone against soft tissue"),
            ("SOFT", "Soft Tissue (CT only)",
             "Level 50, width 400 - organs and muscle, bone saturates"),
            ("LUNG", "Lung (CT only)",
             "Level -600, width 1500 - air and lung detail"),
            ("FULL", "Everything (CT only)",
             "-1000 to 2000 HU, nothing dropped"),
        ],
        default="AUTO",
    )
    volume_half_float: bpy.props.BoolProperty(
        name="Half Precision",
        description=(
            "Store the volume at half precision, which halves the file. The "
            "grid holds a window mapped onto 0 to 1, and half floats resolve "
            "that far more finely than the noise already in the scan, so "
            "there is nothing visible to lose. Turn it off only if you intend "
            "to read values back out for measurement"
        ),
        default=True,
    )
    volume_cut_enabled: bpy.props.BoolProperty(
        name="Cut Through",
        description=(
            "Show a single slice through the volume instead of the whole "
            "thing. This is a viewport setting: it appears in Solid shading, "
            "which is where it is cheap, and not in a render. The same slider "
            "also drives the cut in the volume's material, so a render made "
            "from Material Preview or Rendered shading is cut in the same "
            "place"
        ),
        default=True,
        update=_push_volume_cut,
    )
    volume_cut_axis: bpy.props.EnumProperty(
        name="Cut Axis",
        description=(
            "Which way to cut. Auto turns the cut to face however you are "
            "looking at it, which is usually what you want while moving "
            "around the scan - but a render has no single view to face, so an "
            "Auto cut shows in the viewport and a render comes out whole. "
            "Pick X, Y or Z and the render is cut in the same place"
        ),
        items=[
            ("AUTO", "Auto (follows the view)",
             "Turn the cut to face the viewport"),
            ("X", "X", "Cut across X"),
            ("Y", "Y", "Cut across Y"),
            ("Z", "Z", "Cut across Z"),
        ],
        default="AUTO",
        update=_push_volume_cut,
    )
    volume_cut_flip: bpy.props.BoolProperty(
        name="Flip Cut",
        description=(
            "Keep the other side instead. The plane stays where it is; which "
            "half is thrown away swaps over"
        ),
        default=False,
        update=_push_volume_cut,
    )
    volume_cut_depth: bpy.props.FloatProperty(
        name="Cut Depth",
        description=(
            "Where along the axis the cut sits, from one side of the volume "
            "to the other"
        ),
        default=0.5, min=0.0, max=1.0, subtype="FACTOR",
        # A named function, not a lambda: Blender compiles a lambda
        # update callback in its own context, where this module's
        # globals are not visible, and the call fails with a NameError
        # that Blender prints and swallows - so the slider silently
        # stops driving anything.
        update=_push_volume_cut,
    )
    volume_level: bpy.props.FloatProperty(
        name="Surface Level",
        description=(
            "Where within the window the visible surface sits. Everything "
            "below this fades out, everything above becomes solid. This is "
            "not the same as the Window: the Window decides which range of "
            "the scan was written to the file at all, while this picks the "
            "boundary inside it and takes effect immediately, without "
            "converting anything again"
        ),
        default=0.55, min=0.0, max=1.0, subtype="FACTOR",
        update=_push_volume_look,
    )
    volume_hardness: bpy.props.FloatProperty(
        name="Edge Hardness",
        description=(
            "How abruptly the volume goes from clear to solid at the Surface "
            "Level. At zero it is a soft fog, which shows how dense tissue "
            "is but has no defined shape. Turned up it behaves like a "
            "surface, so organs and bone read as objects with edges"
        ),
        default=0.7, min=0.0, max=1.0, subtype="FACTOR",
        update=_push_volume_look,
    )
    volume_replace: bpy.props.BoolProperty(
        name="Replace Previous",
        description=(
            "Re-use the volume already in the scene for this series instead "
            "of adding another one. With this off, changing the Window and "
            "importing again leaves the old volume sitting in the same place "
            "as the new one, and the two drawn on top of each other look "
            "like nothing changed"
        ),
        default=True,
    )
    volume_density: bpy.props.FloatProperty(
        name="Density",
        description=(
            "How solid the volume looks when it is rendered. Raise it to make "
            "faint tissue visible, lower it if the scan renders as a solid "
            "block"
        ),
        default=4.0, min=0.0, soft_max=200.0,
        update=_push_volume_look,
    )
    volume_sharp_display: bpy.props.BoolProperty(
        name="Full Volume Resolution",
        description=(
            "Render volumes at full screen resolution. Blender draws volumes "
            "at an eighth of screen resolution by default, which is what "
            "makes an imported scan look fuzzy - turning this on measured "
            "15 times sharper and was no slower. It changes a setting on the "
            "scene (Render > Volumes > Resolution), so it affects every "
            "volume in the file, not just the imported ones"
        ),
        default=True,
    )
    volume_surface_color: bpy.props.BoolProperty(
        name="Colour From The Scan",
        description=(
            "Colour the meshed surface by what the scan reads just beneath "
            "it, so dense bone and soft tissue are told apart instead of "
            "everything being the same white. Sampling at the surface itself "
            "would not do it - the surface is where the value equals the "
            "level, so it reads nearly the same everywhere. This applies "
            "when the surface is built, so change it before pressing Volume "
            "To Mesh; the depth below moves on an existing surface"
        ),
        default=True,
    )
    volume_color_depth: bpy.props.FloatProperty(
        name="Colour Depth (mm)",
        description=(
            "How far beneath the surface to read the scan. Measured on a "
            "chest CT, the spread of values is about 350 HU at the surface "
            "and 943 HU two millimetres in, which is the difference between "
            "a uniform colour and one that separates bone from tissue"
        ),
        default=2.0, min=0.0, soft_max=10.0,
        update=_push_volume_look,
    )
    volume_status: bpy.props.StringProperty(
        name="Volume Status",
        description="What the last volume conversion did",
        default="",
    )
    muscle_split_pieces: bpy.props.IntProperty(
        name="Pieces",
        description=(
            "How many parts to break the selected cloud into. Running the "
            "import's own pass again on one cloud finds nothing - it is the "
            "same work on the same data. What this can do instead is take the "
            "answer from you: you can see that a piece is two bones, and "
            "nothing in the scan says so. The most buried centres in the "
            "piece are grown out until there are this many. Fewer come back "
            "if the piece does not have that many centres"
        ),
        default=2, min=2, soft_max=10,
    )
    muscle_mri_bone: bpy.props.BoolProperty(
        name="Find Bone (MRI)",
        description=(
            "Pick bone out of an MRI as the dark core inside the limb. Bone "
            "has almost no signal in any MR sequence, and a Dixon water "
            "image suppresses the fatty marrow as well, so the whole shaft "
            "reads dark inside bright muscle. Air is dark too, but it "
            "reaches the edge of the picture. What separates a bone from a "
            "vessel or a pocket of gas is the marrow inside it, which is "
            "bright in the fat image - so this needs fat and water both"
        ),
        default=False,
    )
    muscle_mri_bone_mode: bpy.props.EnumProperty(
        name="Bone From",
        description="How to decide what counts as bone in an MRI",
        items=[
            ("DARK", "Dark Interior",
             "Everything inside the body with no signal in either image. "
             "Cortical bone returns nothing at all, so this is the one "
             "question the pictures can answer directly. It also takes in "
             "tendon, ligament, vessel and bowel gas, which look the same - "
             "it over-claims on purpose, since points are easy to delete and "
             "detail that was never segmented cannot be added back"),
            ("MARROW", "Marrow And Cortex",
             "Work outward from fatty marrow instead. Cleaner on the shaft "
             "of a long bone, but finds nothing where the marrow is not "
             "fatty - the pelvis, the sacrum, a joint"),
        ],
        default="DARK",
    )
    muscle_mri_dark_level: bpy.props.FloatProperty(
        name="Dark Level",
        description=(
            "How dark a voxel must be, in both images, to count as having no "
            "signal. Raise it to take in more of the bone, lower it if "
            "muscle boundaries start being claimed. Past about 0.30 the "
            "separate bones merge into one piece"
        ),
        default=0.18, min=0.02, max=0.60,
    )
    muscle_mri_marrow_fat: bpy.props.FloatProperty(
        name="Marrow Brightness",
        description=(
            "How bright the fat image must be for a voxel to count as "
            "marrow. Lower it if bones come out hollow or missing, raise it "
            "if too much fat is being considered"
        ),
        default=0.30, min=0.05, max=0.95,
    )
    muscle_mri_cortex_rim: bpy.props.FloatProperty(
        name="Cortex Rim",
        description=(
            "How much of a marrow blob's rim must have no signal at all for "
            "it to be called bone. Cortical bone is dark in both the water "
            "and the fat image; muscle, organ and skin are not, so this is "
            "what separates marrow from every other kind of fat. Measured on "
            "a whole body study, femur and tibia sat between 32% and 60% "
            "while all other fat sat below 27%. It is a floor, not the whole "
            "test: a compact bone such as the femoral head is admitted on a "
            "strong rim alone, and raising this tightens that route too. "
            "Lower it if bones are being missed"
        ),
        default=0.02, min=0.0, max=1.0,
    )
    muscle_mri_bone_min: bpy.props.FloatProperty(
        name="Min Bone (cm3)",
        description=(
            "Discard marrow smaller than this. A femur section runs to tens "
            "of cubic centimetres, while the noise this rejects is fractions "
            "of one"
        ),
        default=1.0, min=0.0, soft_max=50.0,
    )
    muscle_mri_bone_grow: bpy.props.IntProperty(
        name="Cortex Depth",
        description=(
            "How far to follow the signal void outward from the marrow to "
            "take in the cortex. Cortical bone returns no signal at all, so "
            "it can never be found directly - only claimed outward from the "
            "marrow it surrounds. Measured on a femur, 3 voxels roughly "
            "doubles the volume, 6 gives about 2.8x and 10 about 3.5x. It "
            "does not settle on its own: the void runs on into the fat "
            "planes between muscles, so too large a value starts taking "
            "those too"
        ),
        default=8, min=0, max=12,
    )
    muscle_allow_partial: bpy.props.BoolProperty(
        name="Work From Single Source",
        description=(
            "Run even when the station does not have all of fat, water and "
            "out-of-phase. Missing out-of-phase is computed from fat and "
            "water and costs almost nothing. Without both fat and water there "
            "is no fat fraction, so nothing can tell muscle from fat, and "
            "with a single series the boundaries come from where the image "
            "changes fastest instead of from the fascial line - which finds "
            "fewer structures and blunter edges. The result says which it "
            "used. Leave off unless the data is incomplete"
        ),
        default=False,
    )
    muscle_min_slices: bpy.props.FloatProperty(
        name="Thinnest Layer (slices)",
        description=(
            "How thin a layer has to be, counted in acquired slices, before "
            "it is treated as a leak rather than part of a structure. Where a "
            "slice grazes a boundary the boundary briefly stops blocking and "
            "one structure spills into its neighbour, leaving a flat sheet "
            "hanging off the side. Anything thinner than this is handed back "
            "to whatever sits above and below it instead. A spill lasts as "
            "long as the grazing, so some are two or three slices thick - "
            "raise it if sheets are still appearing, lower it to keep "
            "genuinely thin layers. 0 turns it off. It only looks where a "
            "structure meets other tissue: a thin sheet with open space "
            "around it is the same shape as the gently sloping part of any "
            "outer surface, and trimming those left ridges across the skin"
        ),
        default=3.0, min=0.0, soft_max=8.0,
    )
    remesh_detail: bpy.props.FloatProperty(
        name="Remesh Detail",
        description=(
            "How fine to make the remesh, as a fraction of the detail already "
            "in the mesh. 1 matches it and keeps about two thirds of the "
            "surface detail. 0.5 keeps about four fifths but makes roughly "
            "four times as many vertices. Remeshing always costs some detail, "
            "because it rebuilds the surface on a new grid - the mesh you "
            "already have is watertight without it"
        ),
        default=0.5, min=0.05, max=2.0,
    )
    muscle_progress_percent: bpy.props.FloatProperty(
        name="Segmentation Progress",
        default=0.0, min=0.0, max=100.0,
        description="How far the last segmented import has got",
    )
    muscle_running: bpy.props.BoolProperty(
        name="Segmentation Running",
        default=False,
        description="Whether a segmented import is working right now",
    )
    muscle_status: bpy.props.StringProperty(
        name="Muscle Status",
        default="",
        description="What the last run produced",
    )
    status: bpy.props.StringProperty(name="Status", default="Ready")



def _clouds(context):
    """The point clouds this action would run on."""
    chosen = [o for o in context.selected_objects if o.type == "POINTCLOUD"]
    active = context.active_object
    if not chosen and active is not None and active.type == "POINTCLOUD":
        chosen = [active]
    return chosen


def _have(operator_name: str) -> bool:
    """Whether an optional operator registered.

    Four of them are imported inside a try at startup, so a panel that draws
    one without checking raises on every redraw if it did not load.
    """
    return hasattr(bpy.types, operator_name)


def _unavailable(layout, what: str) -> None:
    box = layout.box()
    box.label(text=f"{what} unavailable", icon="ERROR")
    box.label(text="Reinstall the latest addon zip")


class DICOM_PT_import_panel(bpy.types.Panel):
    """Reading a study in, and turning one series into points."""

    bl_label = "DICOM Point Cloud"
    bl_idname = "DICOM_PT_import_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendCOM"

    def draw(self, context):
        layout = self.layout
        props = context.scene.dicom_import_props

        layout.prop(props, "source_path")
        layout.prop(props, "source_is_zip")
        layout.operator("dicom.scan_series", icon="FILE_REFRESH")

        try:
            from . import previews as _previews

            have_previews = _previews.has_previews()
        except Exception:
            have_previews = False
        if have_previews:
            # The icon browser rather than the dropdown: eighty series whose
            # names differ by a few characters cannot be told apart by
            # reading them.
            layout.template_icon_view(props, "series_uid", show_labels=True,
                                      scale=6.0, scale_popup=5.0)
        layout.prop(props, "series_uid")

        col = layout.column(align=True)
        col.prop(props, "threshold")
        col.prop(props, "threshold_max")
        col.prop(props, "stride")
        col.prop(props, "max_points")
        cap = col.row(align=True)
        cap.enabled = bool(props.safe_mode)
        cap.prop(props, "safe_cap_points")
        col.prop(props, "point_radius_scale")

        col = layout.column(align=True)
        col.prop(props, "place_in_patient_space")
        col.prop(props, "shading_correct")
        if props.shading_correct:
            col.prop(props, "shading_scale_mm")
        col.prop(props, "safe_mode")
        layout.prop(props, "color_mode")

        row = layout.row()
        row.enabled = has_series_selected(props)
        row.operator("dicom.import_point_cloud", icon="MESH_DATA")

        box = layout.box()
        box.label(text="Import By Type", icon="DUPLICATE")
        box.prop(props, "import_contrast")
        sub = box.row()
        sub.enabled = bool(str(props.source_path or "").strip())
        sub.operator("dicom.import_contrast_group", icon="IMPORT")
        box.label(text="One cloud per station, of the chosen type.")

        layout.label(text="Progress: {}%".format(int(props.progress_percent)))
        if props.status:
            layout.label(text=props.status)


class DICOM_PT_segmentation_panel(bpy.types.Panel):
    """Everything that divides a scan into separate pieces."""

    bl_label = "Segmentation Tools"
    bl_idname = "DICOM_PT_muscle_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendCOM"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        props = context.scene.dicom_import_props
        clouds = _clouds(context)

        col = layout.column(align=True)
        col.prop(props, "muscle_boundary_cut")
        col.prop(props, "muscle_boundary_fat")
        col.prop(props, "muscle_link_fraction")
        col.prop(props, "muscle_max_fat_fraction")
        col.prop(props, "muscle_min_volume")
        col.prop(props, "muscle_min_slices")

        layout.prop(props, "muscle_ct_mode")
        # Shown rather than hidden, so the levels that would apply are
        # readable before the mode is turned on.
        bone = layout.column(align=True)
        bone.enabled = bool(props.muscle_ct_mode)
        bone.prop(props, "muscle_bone_core")
        bone.prop(props, "muscle_bone_cortex")
        bone.prop(props, "muscle_bone_refine")
        layout.prop(props, "muscle_mri_bone")
        mri = layout.column(align=True)
        mri.enabled = bool(props.muscle_mri_bone) and not props.muscle_ct_mode
        mri.prop(props, "muscle_mri_bone_mode", text="")
        if props.muscle_mri_bone_mode == "DARK":
            mri.prop(props, "muscle_mri_dark_level")
            mri.prop(props, "muscle_mri_bone_min")
        else:
            mri.prop(props, "muscle_mri_marrow_fat")
            mri.prop(props, "muscle_mri_cortex_rim")
            mri.prop(props, "muscle_mri_bone_min")
            mri.prop(props, "muscle_mri_bone_grow")
        if props.muscle_mri_bone and props.muscle_ct_mode:
            layout.label(text="CT Scan finds bone already.", icon="INFO")
        layout.prop(props, "muscle_allow_partial")

        layout.label(text="Progress: {}%".format(
            int(props.muscle_progress_percent)))
        if props.muscle_running:
            layout.operator("dicom.cancel_segmentation",
                            text="Stop Segmentation", icon="CANCEL")
        else:
            row = layout.row()
            row.enabled = has_series_selected(props)
            row.operator("dicom.separate_muscles",
                         text="Import Segmented Features", icon="GROUP_VERTEX")
        if props.muscle_status:
            for line in str(props.muscle_status).split(" | "):
                layout.label(text=line)

        layout.separator()
        box = layout.box()
        box.label(text="Separate By Intensity", icon="MOD_PHYSICS")
        box.prop(props, "local_intensity_bands")
        if _have("DICOM_OT_segment_bones"):
            row = box.row()
            row.enabled = bool(clouds) and not props.segmentation_running
            row.operator("dicom.segment_bones", text="Segment Cloud",
                         icon="GROUP_BONE")
        else:
            _unavailable(box, "Segment Cloud")

        layout.separator()
        box = layout.box()
        box.label(text="Split Selected Cloud", icon="MOD_EXPLODE")
        box.prop(props, "muscle_split_pieces")
        if _have("DICOM_OT_split_selected_cloud"):
            row = box.row()
            row.enabled = bool(clouds)
            row.operator("dicom.split_selected_cloud",
                         text="Split Selected Cloud", icon="MOD_EXPLODE")
        else:
            _unavailable(box, "Split Selected Cloud")
        box.label(text="Breaks one cloud into that many")
        box.label(text="parts, from its own data.")

        layout.separator()
        box = layout.box()
        box.label(text="Create Filtered Point Cloud", icon="POINTCLOUD_DATA")
        box.prop(props, "pc_filter_remove_percent")
        box.prop(props, "pc_filter_invert")
        box.prop(props, "pc_filter_output_suffix")
        # Object mode is enough: the filter is a percentile over every point
        # in the cloud, so there is nothing for an edit-mode selection to
        # mean. The old panel was polled on Edit Mode, which is where this
        # restriction came from - the operator never had it.
        row = box.row()
        row.enabled = bool(clouds)
        row.operator("dicom.create_filtered_pointcloud", icon="DUPLICATE")
        if not clouds:
            box.label(text="Select a point cloud.")


class DICOM_PT_reconstruction_panel(bpy.types.Panel):
    """Resolution and detail, and everything that rebuilds geometry.

    One set of resolution settings reaches every stage that resamples -
    importing, upsampling and meshing. They used to be two identical copies
    applied at different stages, which read as a setting that did nothing
    whenever the other copy was the one being changed.
    """

    bl_label = "Reconstruction Settings"
    bl_idname = "DICOM_PT_reconstruction_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendCOM"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        props = context.scene.dicom_import_props
        clouds = _clouds(context)
        active = context.active_object
        busy = bool(props.mesh_conversion_running)

        col = layout.column(align=True)
        col.label(text="Resolution", icon="MOD_SUBSURF")
        col.prop(props, "shell_resolution_multiplier")
        col.prop(props, "shell_voxel_budget_mv")
        col.prop(props, "mesh_max_vertices_m")
        col.prop(props, "shell_isotropic")
        col.prop(props, "shell_clamp_overshoot")
        col.prop(props, "shell_filter")
        layout.prop(props, "import_enhance_enabled", icon="MOD_SMOOTH")
        layout.label(text="Applies to import, segmenting,")
        layout.label(text="upsampling and meshing.")

        box = layout.box()
        box.label(text="Increase Point Cloud Resolution", icon="MOD_SUBSURF")
        box.prop(props, "pc_upsample_mode")
        box.prop(props, "pc_upsample_max_points")
        box.prop(props, "pc_upsample_output_suffix")
        if _have("DICOM_OT_pointcloud_upsample"):
            row = box.row()
            row.enabled = bool(clouds) and not busy
            row.operator("dicom.pointcloud_upsample",
                         text="Increase Point Cloud Resolution",
                         icon="MOD_SUBSURF")
        else:
            _unavailable(box, "Increase Point Cloud Resolution")

        box = layout.box()
        box.label(text="Keep Only Outside Points", icon="MOD_SOLIDIFY")
        box.prop(props, "pc_shell_thickness")
        box.prop(props, "pc_shell_output_suffix")
        if _have("DICOM_OT_pointcloud_extract_surface"):
            row = box.row()
            row.enabled = bool(clouds) and not busy
            row.operator("dicom.pointcloud_extract_surface",
                         text="Keep Only Surface Points", icon="MOD_SOLIDIFY")
        else:
            _unavailable(box, "Keep Only Surface Points")

        diag = layout.row(align=True)
        diag.enabled = bool(clouds)
        diag.operator("dicom.inspect_pointcloud", icon="VIEWZOOM")
        copy = diag.row(align=True)
        copy.enabled = bool(getattr(props, "last_diagnostics", ""))
        copy.operator("dicom.copy_diagnostics", icon="CONSOLE")

        # Warnings are not repeated here. Every one of them is already an
        # operator report, so Blender puts it in the status bar and keeps it
        # in the Info editor - and the ones about the files themselves also
        # come up as a popup. Restating them in the panel cost a screen of
        # space to say what the log already says, and said it indefinitely
        # after the run it described.

        layout.separator()
        col = layout.column(align=True)
        col.label(text="Surface Mesh Detail", icon="MOD_SMOOTH")
        col.prop(props, "shell_surface_sigma")
        if props.shell_surface_sigma > 1.0:
            col.label(text="Above 1.0 rounds detail away", icon="ERROR")
        col.prop(props, "shell_gap_bridge")
        if props.shell_gap_bridge >= 4:
            # In raw voxels the reach of this is invisible; say it in voxels
            # of anatomy, because it is what welds separate structures.
            col.label(text="Bridges gaps ~{} voxels wide".format(
                2 * props.shell_gap_bridge), icon="ERROR")
        radius = col.row(align=True)
        radius.enabled = bool(props.shell_cover_points)
        radius.prop(props, "shell_cover_radius")
        col.prop(props, "shell_despeckle_min_voxels")
        col.prop(props, "shell_min_island_volume")
        col.prop(props, "mesh_smooth_strength")
        cavity = col.row(align=True)
        cavity.enabled = bool(props.shell_keep_cavities)
        cavity.prop(props, "shell_cavity_min_volume")
        col.prop(props, "shell_cover_points")
        col.prop(props, "shell_keep_cavities")
        col.prop(props, "mesh_hull_hide_source")

        layout.prop(props, "mesh_hull_prefix")
        layout.label(text="Conversion Progress: {}%".format(
            int(props.mesh_progress_percent)))
        if _have("DICOM_OT_pointcloud_to_hull_mesh"):
            if busy:
                layout.operator("dicom.cancel_mesh_conversion",
                                text="Stop Conversion", icon="CANCEL")
            else:
                row = layout.row()
                row.enabled = bool(clouds)
                row.operator("dicom.pointcloud_to_hull_mesh",
                             text="Create Surface Mesh From Selection",
                             icon="MOD_REMESH")
        else:
            _unavailable(layout, "Create Surface Mesh")
        if props.status:
            layout.label(text=props.status)

        layout.separator()
        box = layout.box()
        box.label(text="Quick Remesh", icon="MOD_REMESH")
        box.prop(props, "remesh_detail")
        row = box.row()
        row.enabled = active is not None and active.type == "MESH"
        row.operator("dicom.add_voxel_remesh", text="Add Voxel Remesh",
                     icon="MOD_REMESH")
        if active is None or active.type != "MESH":
            box.label(text="Select a mesh to remesh it.")
        else:
            # One unit is one millimetre here, so Remesh's own 0.1 default
            # would ask for a grid thousands of cells across and run out of
            # memory. This scales it to the object.
            longest = max((float(v) for v in active.dimensions), default=0.0)
            if longest > 0.0:
                box.label(text="Object is {:,.0f} units across.".format(longest))


class DICOM_PT_volume_panel(bpy.types.Panel):
    """The scan itself, rendered rather than sampled into points."""

    bl_label = "Volume Viewer"
    bl_idname = "DICOM_PT_volume_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendCOM"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        props = context.scene.dicom_import_props
        active = context.active_object

        col = layout.column(align=True)
        col.label(text="Converted from the scan:", icon="FILE_REFRESH")
        col.prop(props, "volume_window")
        col.prop(props, "volume_half_float")
        col.prop(props, "volume_replace")
        row = col.row()
        row.enabled = has_series_selected(props)
        row.operator("dicom.import_as_volume", text="Import As Volume",
                     icon="VOLUME_DATA")
        if props.volume_status:
            layout.label(text=props.volume_status, icon="CHECKMARK")

        layout.separator()
        col = layout.column(align=True)
        col.label(text="Cut", icon="MOD_BEVEL")
        col.prop(props, "volume_cut_enabled")
        sub = col.column(align=True)
        sub.enabled = bool(props.volume_cut_enabled)
        sub.prop(props, "volume_cut_axis")
        sub.prop(props, "volume_cut_depth", slider=True)
        sub.prop(props, "volume_cut_flip")
        if props.volume_cut_enabled and props.volume_cut_axis == "AUTO":
            note = layout.box()
            note.label(text="Auto cut: viewport only.", icon="INFO")
            note.label(text="Pick an axis to cut renders.")

        layout.separator()
        col = layout.column(align=True)
        col.label(text="Shape", icon="MOD_OPACITY")
        col.prop(props, "volume_level", slider=True)
        col.prop(props, "volume_hardness", slider=True)
        col.prop(props, "volume_density")

        layout.separator()
        col = layout.column(align=True)
        col.label(text="Quality", icon="SHADING_RENDERED")
        col.prop(props, "volume_sharp_display")
        eevee = getattr(context.scene, "eevee", None)
        tile = str(getattr(eevee, "volumetric_tile_size", "1")) if eevee else "1"
        if tile != "1":
            warn = col.box()
            warn.label(text=f"Volumes drawing at 1/{tile}.", icon="ERROR")
        col.operator("dicom.refresh_volume_look", text="Apply To Volumes",
                     icon="FILE_REFRESH")

        layout.separator()
        col = layout.column(align=True)
        col.label(text="Mesh View", icon="OUTLINER_OB_MESH")
        col.prop(props, "volume_surface_color")
        depth = col.row()
        depth.enabled = bool(props.volume_surface_color)
        depth.prop(props, "volume_color_depth")
        row = col.row()
        row.enabled = active is not None and active.type == "VOLUME"
        row.operator("dicom.volume_to_mesh", text="Volume To Mesh",
                     icon="MESH_DATA")
        if active is None or active.type != "VOLUME":
            col.label(text="Select a volume to mesh it.")
