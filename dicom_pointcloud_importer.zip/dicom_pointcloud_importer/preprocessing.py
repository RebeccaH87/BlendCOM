"""Volume preprocessing: Z-axis interpolation and Gaussian smoothing.

These functions operate on the raw 3D volume BEFORE point cloud generation
or isosurface extraction, addressing the root causes of stair-stepping:
- Anisotropic Z spacing (slices much thicker than pixel spacing)
- Hard slice boundaries (discontinuities between adjacent slices)

Both are thin wrappers over :mod:`resample`, which is the general
implementation: separable, chunked, and offering a proper interpolating filter
rather than the linear-only blend this module originally did in a Python loop
over output slices. For full control - all three axes at once, filter choice,
ringing suppression, voxel budgeting - call :mod:`resample` or
:func:`surface.enhance_volume` directly.
"""

from __future__ import annotations

import numpy as np

from . import resample as _resample


def interpolate_z_spacing(
    volume: np.ndarray,
    spacing: tuple[float, float, float],
    method: str = "cubic",
) -> tuple[np.ndarray, tuple[float, float, float]]:
    """Interpolate intermediate slices along Z to equalize voxel aspect ratio.

    If Z spacing is larger than the average XY spacing, resamples along Z so
    that the output Z spacing approximately equals the XY spacing.

    Args:
        volume: 3D array (Z, Y, X).
        spacing: Physical spacing (sx, sy, sz).
        method: Reconstruction filter - ``"cubic"`` (default), ``"lanczos"`` or
            ``"linear"``. Cubic reconstructs the gradient across slices, so the
            interpolated boundary tracks the anatomy instead of blending toward
            the midpoint.

    Returns:
        Tuple of (new_volume, new_spacing).
    """
    sx, sy, sz = spacing
    xy_spacing = (sx + sy) / 2.0

    if sz <= xy_spacing * 1.1:
        # Already approximately isotropic, nothing to do.
        return volume, spacing

    # How many output slices per input slice gap?
    ratio = sz / xy_spacing
    factor = max(2, int(round(ratio)))

    nz_in = volume.shape[0]
    nz_out = (nz_in - 1) * factor + 1

    new_volume = _resample.resample_volume(
        volume,
        out_shape=(nz_out, volume.shape[1], volume.shape[2]),
        method=method,
        clamp=True,
    ).astype(volume.dtype, copy=False)

    new_sz = sz * float(nz_in) / float(nz_out)
    return new_volume, (sx, sy, new_sz)


def gaussian_smooth_volume(
    volume: np.ndarray,
    sigma: float = 1.0,
) -> np.ndarray:
    """Apply 3D Gaussian smoothing using separable 1D convolutions.

    Pure numpy implementation (no scipy dependency). Uses edge-value boundary
    conditions so the volume border is not pulled toward zero.

    Args:
        volume: 3D array (Z, Y, X).
        sigma: Standard deviation of Gaussian kernel in voxel units.

    Returns:
        Smoothed volume (same shape and dtype as input).
    """
    if sigma < 0.1:
        return volume

    smoothed = _resample.gaussian_blur(volume, float(sigma))
    return smoothed.astype(volume.dtype, copy=False)


MAX_SHADING_GAIN = 1.8
"""Most the shading correction may brighten or darken anything.

A receive coil rolls off smoothly; measured across a limb station the real
range was 1.71 to 1 end to end. Past about this the estimate is no longer
measuring sensitivity."""


def _block_mean(volume: np.ndarray, factors) -> np.ndarray:
    """Average over blocks, one value per block. Trims any ragged edge."""
    out = np.asarray(volume, dtype=np.float32)
    for axis, factor in enumerate(factors):
        if factor <= 1:
            continue
        keep = (out.shape[axis] // factor) * factor
        if keep == 0:
            continue
        out = np.take(out, np.arange(keep), axis=axis)
        shape = list(out.shape)
        shape[axis : axis + 1] = [keep // factor, factor]
        out = out.reshape(shape).mean(axis=axis + 1)
    return np.ascontiguousarray(out, dtype=np.float32)


def shading_gain(
    volume: np.ndarray,
    spacing: tuple[float, float, float],
    tissue: np.ndarray | None = None,
    sigma_mm: float = 20.0,
    strength: float = 1.0,
) -> np.ndarray:
    """The per-voxel gain that flattens the coil's shading. See
    :func:`correct_shading`, which is this applied to one volume.

    Returned separately because a Dixon station has three channels through one
    coil, and they must be corrected by the *same* gain. Estimating one per
    channel would change the ratio between them, and the ratio is the fat
    fraction - the one measurement in the whole pipeline that the shading
    cannot touch, because it cancels there exactly.
    """
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")
    ones = np.ones((1, 1, 1), dtype=np.float32)
    if sigma_mm <= 0.0 or strength <= 0.0:
        return ones

    if tissue is None:
        tissue = vol > max(float(np.percentile(vol, 60.0)), 1e-6)
    weight = np.asarray(tissue, dtype=np.float32)
    if not weight.any():
        return ones

    coarse_mm = max(4.0, float(sigma_mm) / 4.0)
    factors = [max(1, int(round(coarse_mm / max(float(v), 1e-6))))
               for v in spacing]
    small_vol = _block_mean(vol * weight, factors)
    small_weight = _block_mean(weight, factors)
    sigma_small = [float(sigma_mm) / max(float(v) * f, 1e-6)
                   for v, f in zip(spacing, factors)]
    smoothed = (_resample.gaussian_blur(small_vol, sigma_small)
                / np.maximum(_resample.gaussian_blur(small_weight, sigma_small),
                             1e-6))
    shading = _resample.resample_volume(
        smoothed, out_shape=vol.shape, method="linear", clamp=False)

    middle = float(np.median(shading[np.asarray(tissue, dtype=bool)]))
    if middle <= 1e-6:
        return ones
    gain = middle / np.maximum(shading, 1e-6)
    if strength < 1.0:
        gain = 1.0 + (gain - 1.0) * float(strength)
    np.clip(gain, 1.0 / float(MAX_SHADING_GAIN), float(MAX_SHADING_GAIN),
            out=gain)
    return gain.astype(np.float32)


def correct_shading(
    volume: np.ndarray,
    spacing: tuple[float, float, float],
    tissue: np.ndarray | None = None,
    sigma_mm: float = 25.0,
    strength: float = 1.0,
) -> np.ndarray:
    """Flatten the smooth brightness gradient a receive coil leaves behind.

    A coil does not see the whole body equally: what it picks up is multiplied
    by a smooth sensitivity field, so the same tissue reads brighter near the
    coil than away from it. Measured on a limb station of a whole-body Dixon
    study, that field runs 1.71 to 1 across the tissue - the same muscle 71%
    brighter at one end than the other, which against a level of 0.5 moves it
    by 85% of the level.

    A single threshold against that is not a single threshold against the
    anatomy. The level the surface lands on drifts across the volume, and the
    surface ends up following contours of the shading rather than of the
    tissue - broad bands wandering across a surface that should be smooth.
    Blurring cannot remove them, because the shading is already smooth; it has
    to be divided out.

    The estimate is the image itself blurred far past any anatomy, taken over
    the tissue alone so surrounding air cannot drag it down. ``strength``
    scales how much of it is removed, because a coarse estimate also contains
    some real anatomy and taking all of it is not always wanted.

    Note that a Dixon fat fraction needs none of this: fat and water arrive
    through the same coil, so their ratio cancels the sensitivity exactly.
    This is for the paths that threshold brightness.
    """
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")
    if sigma_mm <= 0.0 or strength <= 0.0:
        return vol

    if tissue is None:
        # Anything with signal. The estimate only has to avoid being pulled
        # into the air, not to be a segmentation.
        tissue = vol > max(float(np.percentile(vol, 60.0)), 1e-6)
    weight = np.asarray(tissue, dtype=np.float32)
    if not weight.any():
        return vol

    # Estimated on a coarse grid. The shading is low-frequency by definition,
    # so nothing about it is lost by looking at it through 8mm voxels - and a
    # 25mm blur on a resampled volume is a kernel over a hundred voxels wide
    # on each axis, which is minutes of work for a field that is almost flat.
    coarse_mm = max(4.0, float(sigma_mm) / 4.0)
    factors = [max(1, int(round(coarse_mm / max(float(v), 1e-6))))
               for v in spacing]
    small_vol = _block_mean(vol * weight, factors)
    small_weight = _block_mean(weight, factors)
    sigma_small = [float(sigma_mm) / max(float(v) * f, 1e-6)
                   for v, f in zip(spacing, factors)]
    smoothed = (_resample.gaussian_blur(small_vol, sigma_small)
                / np.maximum(_resample.gaussian_blur(small_weight, sigma_small),
                             1e-6))
    shading = _resample.resample_volume(
        smoothed, out_shape=vol.shape, method="linear", clamp=False)

    # Normalised so the correction redistributes brightness rather than
    # rescaling the whole volume - a level that worked before still means
    # roughly the same thing afterwards.
    middle = float(np.median(shading[np.asarray(tissue, dtype=bool)]))
    if middle <= 1e-6:
        return vol
    gain = middle / np.maximum(shading, 1e-6)
    if strength < 1.0:
        gain = 1.0 + (gain - 1.0) * float(strength)
    # Bounded, because away from any tissue the estimate has nothing to stand
    # on and runs away. A coil's sensitivity varies smoothly and by a bounded
    # amount across a field of view; a correction of three times is not
    # sensitivity, it is the estimate failing, and applying it to air pushes
    # background across the threshold and invents a body.
    np.clip(gain, 1.0 / float(MAX_SHADING_GAIN), float(MAX_SHADING_GAIN),
            out=gain)
    return (vol * gain).astype(np.float32)
