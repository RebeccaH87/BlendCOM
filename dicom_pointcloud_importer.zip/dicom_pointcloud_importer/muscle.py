"""Separating individual muscles using the out-of-phase boundary.

Dixon out-of-phase cancels signal wherever fat and water share a voxel, so
every fat/water interface shows as a dark line - the "India ink" edge. Muscles
are wrapped in fascia containing fat, so those lines trace the gaps between
them. Measured on a real station, the line is 42% darker than the muscle it
separates (0.313 against 0.542), which is a strong signal rather than a
subtlety.

The work is all in *where* that signal survives. Two approaches were tried in
3D and both failed for the same reason:

    thresholding the line:  1 connected piece at every cut from 0.10 to 0.30,
                            even after discarding a fifth of the muscle
    seeded watershed:       erosion produced 875 fragments but only one over
                            5cm3, so the flood had a single seed and returned
                            a single 6,287cm3 region

The cause is the voxel shape. In-plane a voxel is 0.977mm and the fascia is
resolved; through-plane it is 2.60mm, thicker than the fascia itself, so a
plane of fat between two muscles is averaged into the muscle either side.
Measured at a cut of 0.35, a slice contains 7.2 separate muscle regions while
the whole volume contains 2 - muscles that are cleanly apart in every slice
merge between slices.

So separation is done in-plane, where the evidence exists, and the regions are
then linked across slices by overlap. That turns an unsolvable boundary problem
into a tractable correspondence one.
"""
from __future__ import annotations

import numpy as np

from . import voxelgrid as _vg


def fat_fraction(fat: np.ndarray, water: np.ndarray) -> np.ndarray:
    """Share of signal that is fat, per voxel, in 0..1.

    Both channels must be from the same station; Dixon reconstructions are
    inherently co-registered, which is what makes this meaningful per voxel.
    """
    fat = np.asarray(fat, dtype=np.float32)
    water = np.asarray(water, dtype=np.float32)
    total = fat + water
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(total > 1e-6, fat / np.maximum(total, 1e-6), 0.0)


def muscle_mask(fat: np.ndarray, water: np.ndarray,
                max_fat_fraction: float = 0.35,
                min_water: float = 0.18,
                min_signal: float = 0.12,
                max_signal: float = 0.0) -> np.ndarray:
    """Voxels that are muscle: water-dominated tissue with signal.

    Three conditions rather than one threshold, because each excludes
    something different - the total separates tissue from air, the fat
    fraction separates muscle from adipose, and the water level drops out the
    low-signal fringe where the fraction is unstable.

    ``max_signal`` adds a top to the window, and 0 leaves it off. It does
    nothing a fat fraction could not do on a Dixon station, but on a single
    series there is no fat fraction, and then it is the only thing that can
    separate a dim tissue from a brighter one lying over it - vertebral marrow
    from the subcutaneous fat around it, for instance.
    """
    fat = np.asarray(fat, dtype=np.float32)
    water = np.asarray(water, dtype=np.float32)
    total = fat + water
    keep = ((total > float(min_signal))
            & (fat_fraction(fat, water) < float(max_fat_fraction))
            & (water > float(min_water)))
    if float(max_signal) > float(min_water):
        keep &= total <= float(max_signal)
    return keep


def _label_slice(mask_slice: np.ndarray) -> tuple:
    """Connected components within one slice, using the 3D labeller."""
    labels, sizes = _vg.label_regions(mask_slice[None, :, :], connectivity=26)
    return labels[0], sizes


def _run_along(labels, axis: int):
    """How many voxels its own structure runs for, along one axis.

    The same count as :func:`_vertical_run` but on a chosen axis, so a thread
    can be recognised by being short across *both* in-plane directions.
    """
    n = labels.shape[axis]
    solid = labels > 0
    up = np.zeros(labels.shape, dtype=np.uint8)
    down = np.zeros(labels.shape, dtype=np.uint8)
    for i in range(1, n):
        here = [slice(None)] * 3
        here[axis] = i
        prev = [slice(None)] * 3
        prev[axis] = i - 1
        same = solid[tuple(here)] & (labels[tuple(here)] == labels[tuple(prev)])
        np.add(up[tuple(prev)], 1, out=up[tuple(here)], where=same,
               casting="unsafe")
        up[tuple(here)][up[tuple(prev)] == 255] = 255
    for i in range(n - 2, -1, -1):
        here = [slice(None)] * 3
        here[axis] = i
        nxt = [slice(None)] * 3
        nxt[axis] = i + 1
        same = solid[tuple(here)] & (labels[tuple(here)] == labels[tuple(nxt)])
        np.add(down[tuple(nxt)], 1, out=down[tuple(here)], where=same,
               casting="unsafe")
        down[tuple(here)][down[tuple(nxt)] == 255] = 255
    run = np.minimum(up.astype(np.int16) + down.astype(np.int16) + 1, 255)
    run[~solid] = 0
    return run


def _vertical_run(labels):
    """For every voxel, how many slices its own structure runs through there.

    Counted up and down from each voxel along the slice axis, so the value is
    the thickness of the structure at that column. Saturates at 255, which is
    far past anything that gets asked about and keeps this to one byte per
    voxel on volumes that are already using gigabytes.
    """
    nz = labels.shape[0]
    solid = labels > 0
    up = np.zeros(labels.shape, dtype=np.uint8)
    for z in range(1, nz):
        same = solid[z] & (labels[z] == labels[z - 1])
        np.add(up[z - 1], 1, out=up[z], where=same, casting="unsafe")
        up[z][up[z - 1] == 255] = 255
    down = np.zeros(labels.shape, dtype=np.uint8)
    for z in range(nz - 2, -1, -1):
        same = solid[z] & (labels[z] == labels[z + 1])
        np.add(down[z + 1], 1, out=down[z], where=same, casting="unsafe")
        down[z][down[z + 1] == 255] = 255
    run = np.minimum(up.astype(np.int16) + down.astype(np.int16) + 1, 255)
    run[~solid] = 0
    return run


def _near_another_label(labels, reach: int, mask=None):
    """Voxels within ``reach`` of a boundary with a *different* structure.

    Both cleanup steps exist to fix boundaries between structures: a leak from
    one into another, a thread drawn through the gap between two. Neither has
    anything to say about the outside of a feature, where the only neighbour
    is air - and both are anisotropic, one working along the slice axis and
    one across it, so turned loose on that outer surface they reshape it one
    axis at a time and leave a ridge every time the surface crosses a voxel.
    Stacked up a curved flank, those ridges are the contour banding.

    Restricting them to the boundaries they were written for leaves the
    outside alone.
    """
    contact = np.zeros(labels.shape, dtype=bool)
    solid = labels > 0
    tissue = solid if mask is None else np.asarray(mask, dtype=bool)
    for axis in (0, 1, 2):
        for shift in (1, -1):
            neighbour = np.roll(labels, shift, axis=axis)
            # Other tissue, whether it ended up with a label of its own or
            # not. Requiring a labelled neighbour missed a plate hanging into
            # ground the fill never reached, which is most of them. Air is
            # still not tissue, so the outer surface stays out of it.
            other = np.roll(tissue, shift, axis=axis) & (neighbour != labels)
            contact |= solid & other
    if reach <= 0 or not contact.any():
        return contact
    return _vg.binary_dilate(contact, radius=int(reach), connectivity=6)


def _prune_thin_layers(labels, mask, voxel_mm, acquired_mm, min_slices):
    """Re-decide the parts of a structure that are only a layer or two thick.

    A boundary between two structures is a thin dark line, and where a slice
    grazes a curved one - the skull at the top of the head, the fascia over
    the shoulder of a muscle - that line partial-volumes bright enough to stop
    blocking. The region floods through it for exactly as long as the grazing
    lasts, usually one acquired slice, and then the boundary re-forms. What is
    left behind is a flat plate of the neighbouring structure hanging off the
    side of this one, which is the shelf.

    A leak is always thin in the slice direction: it touches the structure it
    was given to for the one slice where the boundary failed, and nothing of
    that structure lies above or below it. So the thin part is detached and
    then offered to whatever it *does* sit on consistently, by growing the
    surviving labels into it along the slice axis only - the one direction the
    leak cannot travel. A plate of scalp handed to the brain for one slice is
    scalp above and below, so it goes back to the scalp rather than being
    thrown away. Anything with nothing above or below it is left unassigned,
    because there is no answer to give it.

    The threshold is counted in acquired slices, not millimetres: a leak lasts
    as long as the grazing that caused it, which is a whole number of acquired
    slices, so a fixed distance reaches it on one scan and not on another.
    Measured on a 2.6mm station, 1.3 slices left a 17.1cm2 plate standing and
    4 slices left none.

    Returns ``(labels, moved, dropped)``.
    """
    if min_slices <= 0.0 or voxel_mm <= 0.0:
        return labels, 0, 0
    step = max(float(acquired_mm), float(voxel_mm))
    needed = int(np.ceil(float(min_slices) * step / float(voxel_mm)))
    if needed <= 1:
        return labels, 0, 0

    thin = (_vertical_run(labels) < needed) & (labels > 0)
    # Only where a different structure is close enough to have leaked. On the
    # outside of a feature every column that grazes the surface is short, so
    # without this the whole near-horizontal part of the skin reads as thin
    # and gets carved column by column.
    thin &= _near_another_label(labels, needed, mask)
    if not thin.any():
        return labels, 0, 0

    out = labels.copy()
    out[thin] = 0
    waiting = thin.copy()
    # A leak is as deep as the graze that caused it, so the owner is a slice
    # or two away. Twice the threshold is enough to cross the thickest leak
    # the test admits, and stops a label travelling the length of the body.
    # Written as slices rather than whole-volume shifts. Building `above`,
    # `below` and the choice between them allocated three int32 copies of the
    # volume on every pass - 1.5GB each time round on a resampled station, and
    # the pass runs a dozen times. The slices do the same work against views.
    # Below is tried before above, as before; a voxel the two reach at once
    # has no better claim from either, and the fill has always broken those
    # ties by order.
    for _ in range(max(2, needed)):
        if not waiting.any():
            break
        grew = False
        for lower, upper in ((slice(1, None), slice(None, -1)),
                             (slice(None, -1), slice(1, None))):
            target, source = out[lower], out[upper]
            # A waiting voxel is zero because this function zeroed it, and it
            # came from a label, so it was inside the mask already. Testing
            # either again is two passes over a hundred million voxels to
            # re-establish something that cannot have changed.
            claim = waiting[lower] & (source > 0)
            if not claim.any():
                continue
            target[claim] = source[claim]
            waiting[lower] &= ~claim
            grew = True
        if not grew:
            break

    # What is left has nothing above or below it to belong to, and the choice
    # is to discard it or put it back. Thickness alone cannot decide: a leak
    # and a genuinely thin structure are the same shape. What separates them
    # is the structure they came from. A leak hangs off the side of something
    # much thicker, so it is a small part of its feature; a thin structure is
    # thin all over, so it is most of its own. Features that are mostly thin
    # are put back whole, the rest let go.
    if waiting.any():
        thin_by_label = np.bincount(labels[thin].reshape(-1))
        all_by_label = np.bincount(labels[labels > 0].reshape(-1),
                                   minlength=thin_by_label.size)
        thin_by_label = np.resize(thin_by_label, all_by_label.size)
        share = thin_by_label / np.maximum(all_by_label, 1)
        mostly_thin = share >= 0.5
        keep_back = waiting & mostly_thin[labels]
        if keep_back.any():
            out[keep_back] = labels[keep_back]
            waiting = waiting & ~keep_back

    # Only count what actually changed hands. A voxel put back where it
    # started has not moved, and reporting it as moved would overstate what
    # the rule did by the whole of its own caution.
    moved = int(((out != labels) & (out > 0)).sum())
    return out, moved, int(waiting.sum())


# How good a separation the available contrasts can support, worst to best.
TIER_GRADIENT = "gradient"
TIER_NO_FAT = "no-fat-fraction"
TIER_DERIVED_OPP = "derived-opposed-phase"
TIER_CT = "ct-hounsfield"
TIER_FULL = "full"

TIER_NOTES = {
    TIER_FULL: "fat, water and out-of-phase",
    TIER_DERIVED_OPP: "out-of-phase computed from fat and water",
    TIER_NO_FAT: "no fat fraction - boundaries only",
    TIER_GRADIENT: "single series - boundaries from image gradient",
    TIER_CT: "CT, read in Hounsfield units",
}

# The landmarks a CT is calibrated against. These are properties of the
# measurement, not of the scan, which is the whole point of Hounsfield units:
# the same numbers apply to every CT from every scanner.
CT_FAT_HU = -100.0
"""Pure fat. Subcutaneous and intermuscular fat sit near here."""

CT_MUSCLE_HU = 60.0
"""Skeletal muscle. Water is 0 and muscle is a little denser."""

CT_SOFT_LOW_HU = -220.0
"""Below this is air or lung, not tissue."""

CT_BONE_HU = 180.0
"""At and above this a voxel is bone. Cancellous bone starts around 200 and
cortical runs into the thousands; 180 catches the thin cortex of a small bone
without taking dense soft tissue with it."""

CT_CORTEX_HU = 700.0
"""Dense cortical bone. Each bone is a shell of this around a softer middle,
and at a joint two shells lie back to back with a gap between them - so the
shells are still separate where the bones themselves have merged, and each
one can seed its own bone."""

CT_BONE_DENSE_HU = 900.0
"""Fully cortical. Used as the top of the scale density is read against."""


def _ct_ramp(values, low, high):
    """0 below ``low``, 1 above ``high``, straight line between."""
    return np.clip((values - low) / max(high - low, 1e-6), 0.0, 1.0)


def split_by_cortex(mask, hounsfield, cortex_hu: float = CT_CORTEX_HU,
                    min_seed_cm3: float = 0.05, voxel_cm3: float = 1.0):
    """Separate bones by seeding from their cortical shells.

    Two earlier attempts are worth recording, because both look reasonable
    and both fail on a foot.

    Raising the bone threshold until the joints open hollows the bones out
    first: at 650 HU two feet gave 20 pieces but only 88cm3 of 480 survived,
    the cortical shells without their middles.

    Separating by depth - taking the deepest part of each object as its core -
    cuts a long bone at its narrowest point, which is mid-shaft, not a joint.
    Undoing the cuts that ran through solid bone helped but did not fix it:
    scored against what a foot bone can be, that left 14 pieces over 25mm
    thick and 15cm3, which are clumps of several tarsals rather than bones.

    Seeding from the cortex uses what the CT measured rather than inferring
    the shape. Same scan, same scoring: 5 clumps instead of 14, no slivers,
    and a median piece of 3.5cm3 against 9.9. Bones that genuinely touch
    through their cortex still merge - nothing here can see a boundary the
    scan did not record - but far fewer of them do.
    """
    solid = np.asarray(mask, dtype=bool)
    if not solid.any():
        return np.zeros(solid.shape, dtype=np.int32)

    shell = np.asarray(hounsfield) >= float(cortex_hu)
    labels, _count = _vg.label_regions(shell & solid, connectivity=6)
    labels = np.asarray(labels).astype(np.int32)

    # A seed has to be a piece of cortex, not a speck of noise at its level.
    counts = np.bincount(labels.reshape(-1))
    counts[0] = 0
    keep = (counts * float(voxel_cm3)) >= float(min_seed_cm3)
    remap = np.zeros(counts.size, dtype=np.int32)
    chosen = np.nonzero(keep)[0]
    remap[chosen] = np.arange(1, len(chosen) + 1)
    seeds = remap[labels]
    if not seeds.any():
        return np.zeros(solid.shape, dtype=np.int32)

    grown = _vg.propagate_labels(seeds, solid | (seeds > 0), connectivity=6)
    grown[~solid] = 0
    return grown


def refine_by_local_cortex(labels, hounsfield, voxel_cm3: float,
                           fraction: float = 0.90,
                           min_seed_cm3: float = 0.02):
    """Split the pieces a single cortex level could not, judging each by its own.

    A tarsal has thick dense cortex; a phalanx has a thin one, and thin cortex
    part-volumes down toward the marrow value beside it. So no single level
    seeds both: set it high enough to keep the tarsals apart and the phalanges
    never reach it, and a whole toe comes out as one piece. Measured on a CT
    of two feet at one global level: 71 pieces, of which only 7 were
    phalanx-shaped where 28 were expected.

    The answer is not a different global level, it is no global level. Once a
    piece has been found, the density *inside it* says what counts as cortex
    there, and the same seeding runs again within its own bounds.

    ``fraction`` is how far down from a piece's own dense level to look. Near
    1.0 only the very densest parts seed, so little is split; lower it to
    split more, at the risk of a bone coming apart at a dense patch.

    Returns relabelled ``labels``.
    """
    labels = np.asarray(labels)
    values = np.asarray(hounsfield)
    out = labels.copy()
    highest = int(labels.max())
    if highest < 1:
        return out
    next_id = highest

    # Each piece is a few thousand voxels in a volume of a hundred million, so
    # everything here happens inside its own bounding box. Doing it over the
    # whole volume per label was the difference between seconds and a quarter
    # of an hour.
    present = np.nonzero(labels)
    if not len(present[0]):
        return out
    order = np.argsort(labels[present], kind="stable")
    zz, yy, xx = (axis[order] for axis in present)
    sorted_values = labels[present][order]
    starts = np.searchsorted(sorted_values, np.arange(1, highest + 2))

    for value in range(1, highest + 1):
        low, high = int(starts[value - 1]), int(starts[value])
        if high - low == 0 or (high - low) * voxel_cm3 < 0.2:
            continue
        box = (slice(int(zz[low:high].min()), int(zz[low:high].max()) + 1),
               slice(int(yy[low:high].min()), int(yy[low:high].max()) + 1),
               slice(int(xx[low:high].min()), int(xx[low:high].max()) + 1))
        here = labels[box] == value
        window = values[box]
        level = float(np.percentile(window[here], 90.0)) * float(fraction)
        shell = here & (window >= level)
        if not shell.any():
            continue
        comp, _count = _vg.label_regions(shell, connectivity=6)
        comp = np.asarray(comp)
        counts = np.bincount(comp.reshape(-1))
        counts[0] = 0
        cores = [v for v in np.nonzero(counts)[0]
                 if counts[v] * voxel_cm3 >= float(min_seed_cm3)]
        if len(cores) < 2:
            continue
        seeds = np.zeros(here.shape, dtype=np.int32)
        for index, core in enumerate(cores):
            seeds[comp == core] = index + 1
        grown = _vg.propagate_labels(seeds, here | (seeds > 0), connectivity=6)
        grown[~here] = 0
        patch = out[box]
        patch[here & (grown == 1)] = value
        for index in range(2, len(cores) + 1):
            next_id += 1
            patch[here & (grown == index)] = next_id
        out[box] = patch
    return out


def split_into(mask, count: int, voxel_cm3: float = 1.0, values=None,
               min_core_cm3: float = 0.02, limit: int = 40):
    """Split one object into ``count`` pieces, deepest centres first.

    Used where a person has looked at a piece and knows how many bones are in
    it. Nothing in the data says "three"; the shape only says where the
    centres are, and which of them are most buried. So the cores are taken in
    order of how deep they sit, the ``count`` most buried are kept, and those
    are grown back out over the whole mask.

    Depth rather than density, because a piece that resisted the density pass
    has, by definition, no second dense centre - that is why it is still one
    piece. Its shape may still say otherwise.

    ``values`` is optional and only breaks ties: where two cores appear at the
    same depth, the denser one is preferred, which on a bone is the one more
    likely to be a separate centre of ossification rather than a notch.

    Returns labels 1..n with n <= count. Fewer than asked for means the piece
    does not have that many centres - a single bone has one, however many
    pieces are requested, and saying so is better than returning slivers.
    """
    solid = np.asarray(mask, dtype=bool)
    if not solid.any() or int(count) < 2:
        return np.where(solid, 1, 0).astype(np.int32)

    # How deep each voxel sits: how many erosions it survives.
    depth = np.zeros(solid.shape, dtype=np.int16)
    current = solid.copy()
    for step in range(1, int(limit) + 1):
        current = _vg.ball_erode(current, 1)
        if not current.any():
            break
        depth[current] = step

    # Walk down from the deepest level, collecting centres as they appear.
    found = []                       # (depth, density, mask of the core)
    claimed = np.zeros(solid.shape, dtype=bool)
    for level in range(int(depth.max()), 0, -1):
        here = depth >= level
        fresh = here & ~claimed
        if not fresh.any():
            continue
        comp, _n = _vg.label_regions(fresh, connectivity=6)
        comp = np.asarray(comp)
        counts = np.bincount(comp.reshape(-1))
        counts[0] = 0
        for value in np.nonzero(counts)[0]:
            # A core has to be a centre, not a speck. Without this the second
            # and third "deepest" cores are single voxels on the surface, and
            # asking for three pieces returns the bone plus two slivers.
            if counts[value] * float(voxel_cm3) < float(min_core_cm3):
                continue
            core = comp == value
            density = (float(np.mean(np.asarray(values)[core]))
                       if values is not None else 0.0)
            found.append((level, density, core))
        claimed |= here

    if len(found) < 2:
        return np.where(solid, 1, 0).astype(np.int32)

    found.sort(key=lambda item: (-item[0], -item[1]))
    seeds = np.zeros(solid.shape, dtype=np.int32)
    for index, (_level, _density, core) in enumerate(found[:int(count)],
                                                     start=1):
        seeds[core] = index

    grown = _vg.propagate_labels(seeds, solid | (seeds > 0), connectivity=6)
    grown[~solid] = 0
    return grown


MRI_MARROW_FAT = 0.30
"""How bright the fat image must be for a voxel to be marrow."""

MRI_BONE_MIN_CM3 = 1.0
MRI_CORTEX_RIM = 0.02
"""How much of a marrow blob's rim must be signal void for it to be bone."""

MRI_BONE_ELONGATION = 2.0
"""How many times longer than wide a *long* bone must be. See ``mri_bone``."""

MRI_COMPACT_RIM = 0.45
"""Void rim that lets a bone in without being longer than it is wide.

The pelvis and the femoral head are bone but are not shafts, so the shape
test alone would always refuse them. What they do have is a cortex: measured
at the hip, the femoral head came back at 55% void rim with a length to
width ratio of 1.0, while the mass of subcutaneous fat and fascia that
swallows that station sat at 26%.
"""

MRI_BONE_MAX_SHARE = 0.20
"""No bone is a fifth of the patient.

Without this the detector has a catastrophic failure mode rather than a
quiet one: at the hip the subcutaneous fat and fascia form a single region
of 6,719 cm3 - half the body in that station - whose length to width ratio
is 2.0, exactly on the shape cutoff. With the rim test turned down it is
accepted and the entire point cloud comes back as one bone.
"""

MRI_BRIDGE_CUT = 2
"""Radius, in voxels across the slice, of the opening that cuts fascia."""


def _plane_erode(mask, radius: int):
    """Erode within each slice only, leaving the slice axis alone."""
    out = mask
    for _ in range(int(radius)):
        out = (out
               & _vg.shift(out, (0, 1, 0), False)
               & _vg.shift(out, (0, -1, 0), False)
               & _vg.shift(out, (0, 0, 1), False)
               & _vg.shift(out, (0, 0, -1), False))
    return out


def _plane_dilate(mask, radius: int):
    """The matching dilation, so an opening restores the original edge."""
    out = mask
    for _ in range(int(radius)):
        out = (out
               | _vg.shift(out, (0, 1, 0), False)
               | _vg.shift(out, (0, -1, 0), False)
               | _vg.shift(out, (0, 0, 1), False)
               | _vg.shift(out, (0, 0, -1), False))
    return out


def _fill_slice_holes(mask):
    """Close voids that a slice encloses, leaving ones open to the side.

    Done slice by slice rather than in three dimensions on purpose. The
    marrow canal of a long bone runs the whole height of a station, so it is
    open at the top and bottom faces of the volume - flooded in 3D it joins
    the outside and never counts as enclosed. In the plane of the slice it is
    a ring around a hole, which is what it looks like to the eye.

    Only ever run on a region already accepted as a bone. Run over the whole
    fat image it does the opposite of what is wanted: the subcutaneous layer
    and the fascia jointly enclose small pockets of muscle, and filling those
    joins fat regions that were separate, which is the very separation the
    opening below depends on. Measured over a 20 station study, doing it up
    front cost five of the eight bones found.
    """
    out = np.array(mask, dtype=bool, copy=True)
    for z in range(out.shape[0]):
        plane = out[z]
        if not plane.any():
            continue
        free = ~plane
        labels, sizes = _vg.label_regions(free[None, :, :], connectivity=6)
        labels = labels[0]
        border = np.concatenate((labels[0, :], labels[-1, :],
                                 labels[:, 0], labels[:, -1]))
        open_to_side = {int(v) for v in np.unique(border) if v > 0}
        fillable = [v for v in range(1, len(sizes))
                    if v not in open_to_side]
        if not fillable:
            continue
        out[z] = plane | np.isin(labels, fillable)
    return out


MRI_DARK_LEVEL = 0.18
"""How dark counts as no signal, for the dark-interior reading of bone."""

MRI_DARK_MARGIN = 3
"""Voxels pulled in from the skin before anything is called interior."""


def mri_dark_interior(water, fat, spacing,
                      level: float = MRI_DARK_LEVEL,
                      min_volume_cm3: float = MRI_BONE_MIN_CM3,
                      margin: int = MRI_DARK_MARGIN):
    """Everything inside the patient with no signal in either image.

    A definition rather than an inference, and that is the point of it.
    ``mri_bone`` reasons from fatty marrow outward and so finds only bones
    that have fatty marrow and keep a recognisable shape - in practice the
    shafts of long bones. This asks the blunter question the pictures can
    actually answer: which voxels are dark in the water image *and* dark in
    the fat image, and lie inside the body rather than around it.

    That catches cortical bone, and also tendon, ligament, vessel and bowel
    gas, because those are signal-void too and nothing in the images tells
    them apart. It over-claims on purpose: taking points away afterwards is
    easy, and detail that was never segmented cannot be put back.

    What makes it work is that the subcutaneous fat is *bright* in the fat
    image, so it forms a closed ring between the dark inside and the dark air
    outside. Inside is decided from the body silhouette rather than by asking
    what connects to the edge of the picture. That matters: judged by
    connectivity the result has a cliff in it, because a slightly looser
    threshold lets the inside leak through the skin, join the air and be
    discarded whole - one station measured 1,915 cm3 at one threshold and
    7 cm3 at the next. Against the silhouette the same sweep is monotonic.

    ``margin`` pulls in from the skin so the dark partial-volume rim at the
    surface is not claimed as a cavity.

    Each piece is returned separately, largest first, so unwanted ones can be
    deleted individually.
    """
    water = np.asarray(water, dtype=np.float32)
    out = np.zeros(water.shape, dtype=np.int32)
    if fat is None:
        return out
    fat = np.asarray(fat, dtype=np.float32)

    spacing = np.asarray(spacing, dtype=np.float64).reshape(3)
    voxel_cm3 = float(np.prod(spacing)) / 1000.0

    inside = np.maximum(water, fat) > 0.10
    inside = _vg.binary_dilate(inside, radius=2, connectivity=6, fill=True)
    inside = _vg.binary_erode(inside, radius=2, connectivity=6)
    if margin > 0:
        inside = _vg.binary_erode(inside, radius=int(margin), connectivity=6)
    if not inside.any():
        return out

    # The fat image sits on a slightly higher floor than the water image, so
    # the same number would reject rather more of it.
    void = inside & (water < float(level)) & (fat < float(level) + 0.10)
    if not void.any():
        return out

    labels, sizes = _vg.label_regions(void, connectivity=6)
    found = 0
    for value in np.argsort(sizes[1:])[::-1] + 1:
        if int(sizes[value]) * voxel_cm3 < float(min_volume_cm3):
            break
        # Filled one piece at a time, never over the whole mask: what a
        # cortex encloses is its marrow, and that is part of the bone, but
        # filling everything at once would join pieces through the pockets
        # they jointly enclose.
        out[_fill_slice_holes(labels == value)] = found + 1
        found += 1
    return out


def mri_bone(water, fat, spacing,
             fat_level: float = MRI_MARROW_FAT,
             min_volume_cm3: float = MRI_BONE_MIN_CM3,
             rim_void: float = MRI_CORTEX_RIM,
             elongation: float = MRI_BONE_ELONGATION,
             compact_rim: float = MRI_COMPACT_RIM,
             max_share: float = MRI_BONE_MAX_SHARE,
             grow: int = 8):
    """Long bones from a Dixon MRI, found by the cortex around their marrow.

    An MRI has no calibrated scale, so there is no threshold that means bone
    the way +300 HU does on a CT. Worse, cortical bone has almost no mobile
    protons and so produces *no* signal at all: the densest tissue in the
    body is invisible. What can be found is the fatty marrow inside it, and
    then the cortex is the signal void wrapped around that.

    Three things have to be true of a region for this to call it bone, and
    each one is there because the measurement said the others were not
    enough. The numbers below come from a 20 station whole body Dixon study.

    *It must be fat bright.* Marrow is fat. On its own this says very little,
    because subcutaneous and visceral fat read exactly the same - the largest
    such blob in a station ran to 6,671 cm3.

    *Its rim must be signal void.* Cortex is dark in the water image and dark
    in the fat image both, and nothing else that bounds fat is. The rim is
    judged only where it lies inside the body, because air is signal void
    too and would otherwise let any subcutaneous sheet pass. Femur and tibia
    marrow came back at 32% to 60% void rim, every other fat mass at 0% to
    27%.

    *It must be longer than it is wide, or else plainly walled in.* On a
    coarse, noisy series the fat threshold shatters into dozens of small
    blobs that happen to sit beside something dark: three stations produced
    165 of them, 1 to 27 cm3 each. Real long bones ran 88% to 91% of the
    height of their station with a length to width ratio of 2.8 to 6.7,
    while every one of those fragments sat between 0.3 and 1.2. The axes are
    compared in millimetres, so this does not assume which way the patient
    was scanned.

    That test alone refuses the pelvis and the femoral head, which are bone
    and are not shafts, so a second route lets a compact region in on the
    strength of its cortex instead: at the hip the femoral head measured 55%
    void rim at a ratio of 1.0, against 26% for the fat and fascia around
    it. A candidate is bone if it is elongated *or* if its rim is void
    enough to leave no doubt.

    *And no bone is a fifth of the patient.* This one is a guard rather than
    a finding. At the hip the subcutaneous fat and fascia merge into one
    region of 6,719 cm3 - half that station's body - whose ratio is 2.0,
    sitting exactly on the shape cutoff; with the rim test turned down it
    passes every other test and the whole point cloud comes back as a single
    bone.

    Before any of that, an opening across the slice cuts the fascial planes.
    Fat is a connected network - subcutaneous fat runs between the muscles
    and into the marrow - so labelling fat bright voxels directly puts a
    whole limb in one blob and leaves no rim to test: at two stations the
    largest "blobs" were 958 and 957 cm3, one per leg. The opening severs
    anything thinner than its radius; each piece is then grown back by the
    same amount so its rim sits on the cortex again rather than inside the
    marrow.

    ``grow`` finally dilates the accepted marrow into the void around it, so
    the result is a bone rather than the cavity inside one.

    This finds long bones. Vertebrae, pelvis and skull are not long, and the
    elongation test will reject them. It also finds nothing where the marrow
    is not fatty - at a joint, or in a child.

    ``spacing`` is millimetres per voxel as ``(x, y, z)`` - the order the
    DICOM reader returns, which is the reverse of how the volume is indexed.

    Returns a label volume, one value per bone.
    """
    water = np.asarray(water, dtype=np.float32)
    out = np.zeros(water.shape, dtype=np.int32)
    if fat is None:
        return out
    fat = np.asarray(fat, dtype=np.float32)

    spacing = np.asarray(spacing, dtype=np.float64).reshape(3)
    voxel_cm3 = float(np.prod(spacing)) / 1000.0
    # ``spacing`` is (x, y, z) millimetres, the order the DICOM reader hands
    # back, while the volume is indexed [z, y, x]. Read one with the other's
    # order and the slice count gets multiplied by the in-plane pitch, which
    # makes a femur look wider than it is long.
    axis_mm = (float(spacing[2]), float(spacing[1]), float(spacing[0]))

    bright = fat >= float(fat_level)
    if not bright.any():
        return out

    # The silhouette of the body, holes closed so that cortex and marrow
    # count as inside it. Air has no signal either, so without this the rim
    # test passes on subcutaneous fat, whose outer rim reads just as void.
    inside = np.maximum(water, fat) > 0.10
    inside = _vg.binary_dilate(inside, radius=2, connectivity=6, fill=True)
    inside = _vg.binary_erode(inside, radius=2, connectivity=6)
    body_voxels = float(inside.sum())

    core = _plane_erode(bright, MRI_BRIDGE_CUT)
    if not core.any():
        return out

    labels, sizes = _vg.label_regions(core, connectivity=6)
    found = 0
    # Largest first, so the bone numbering is stable from run to run.
    for value in np.argsort(sizes[1:])[::-1] + 1:
        if int(sizes[value]) * voxel_cm3 < float(min_volume_cm3) * 0.25:
            # What is left has no chance of reaching the minimum once grown.
            break
        where = _plane_dilate(labels == value, MRI_BRIDGE_CUT) & bright
        if float(where.sum()) * voxel_cm3 < float(min_volume_cm3):
            continue

        shell = _vg.binary_dilate(where, radius=2, connectivity=6) & ~where
        shell &= inside
        if shell.sum() < 8:
            # Hardly any of its rim is inside the body, so there is nothing
            # to judge: a fat pad at the surface, not a bone.
            continue
        void = (water[shell] < 0.20) & (fat[shell] < 0.30)
        void_share = float(np.mean(void))
        if void_share < float(rim_void):
            # Fat, but nothing bony around it: subcutaneous, visceral, or
            # the fat between muscles.
            continue

        if float(where.sum()) > float(max_share) * body_voxels:
            # Bigger than any bone in a person. At the hip the fat and the
            # fascia merge into one region half the size of the station.
            continue

        index = np.argwhere(where)
        extent = sorted(
            float((index[:, axis].max() - index[:, axis].min() + 1)
                  * axis_mm[axis])
            for axis in (0, 1, 2))
        slim = (extent[1] > 0.0
                and extent[2] / extent[1] >= float(elongation))
        # Never looser than the rim the caller asked for - raising Cortex Rim
        # has to tighten this route too, not be bypassed by it.
        walled = void_share >= max(float(rim_void), float(compact_rim))
        if not slim and not walled:
            # As wide as it is long, and with no convincing cortex either: a
            # blob of fat next to something dark, not a bone.
            continue

        # Whatever the ring encloses is inside the bone, whether or not it
        # was bright enough to be claimed. Marrow is not uniformly fatty -
        # red marrow is water-rich, and the middle of the canal often sits
        # just under the brightness threshold - so without this the bone
        # comes out as an outline around its own cavity.
        where = _fill_slice_holes(where)
        if grow > 0:
            # Take in the cortex, but not the muscle beyond it: the shell is
            # only bone where there is no signal.
            thicker = _vg.binary_dilate(where, radius=int(grow),
                                        connectivity=6)
            quiet = inside & (water < 0.30) & (fat < 0.45)
            where = where | (thicker & quiet)

        # The same guard again, on the finished bone. Growing runs through
        # signal void, and the void does not stop at the cortex - it carries
        # on into the fat planes between the muscles. A candidate that was
        # small enough as marrow can come out of a deep grow as most of the
        # station: one measured 1,353 cm3 and spanned the whole field of
        # view, having started well inside the limit.
        if float(where.sum()) > float(max_share) * body_voxels:
            continue

        found += 1
        out[where] = found
    return out


def ct_classes(hounsfield):
    """Bone, muscle and fat as separate passes over the same CT.

    Leaving bone out of the tissue makes it a boundary, which is what telling
    two muscles apart needs and useless if the bones are what you are after.
    On a CT there is no need to choose: Hounsfield units say outright which
    class a voxel belongs to, so each class is segmented on its own and a bone
    can never merge with the muscle beside it - they are never in the same
    pass.

    Each entry is ``(name, mask, field, how)``. ``field`` runs high in the
    middle of a structure of that class and low at its edges. ``how`` is a
    number to cut that field at, ``None`` to take the setting from the panel,
    or ``"touching"`` to separate by depth instead - for a class whose objects
    meet rather than being parted by anything in the image.

    The cuts are low on purpose. Belonging to the class has already done most
    of the separating, and cutting hard on top of that only empties the
    interior and leaves the fill to guess - measured on a CT of two feet, bone
    at a 0.55 cut came back 96% guessed and at 0.02 it was 15%. Only muscle,
    which really is parted by fat planes inside its own class, takes the
    panel's Boundary Strength.

    Returns a list, bone first, so the labels come out grouped by class.
    """
    hu = np.asarray(hounsfield, dtype=np.float32)
    return [
        # Bones meet at joints, and the gap is often thinner than a voxel, so
        # they run together in the mask and no brightness cut parts them.
        # They are separated by seeding from the cortex instead -
        # see split_by_cortex.
        ("Bone", hu >= CT_BONE_HU,
         _ct_ramp(hu, CT_BONE_HU - 30.0, CT_BONE_DENSE_HU), "touching"),
        # Lean soft tissue, parted by the fat planes - the negative voxels -
        # so leanness is the field and the panel's Boundary Strength applies.
        ("Muscle", (hu >= -20.0) & (hu < CT_BONE_HU),
         _ct_ramp(hu, CT_FAT_HU * 0.4, CT_MUSCLE_HU + 10.0), None),
        # Fat, parted by whatever lean tissue runs through it: the mirror.
        ("Fat", (hu >= CT_SOFT_LOW_HU) & (hu < -20.0),
         1.0 - _ct_ramp(hu, CT_SOFT_LOW_HU, -20.0), 0.02),
    ]


def _rank_of(values, where, bins: int = 4096):
    """Where each value falls in the distribution of ``values[where]``, 0 to 1.

    Done on a histogram rather than a sort: a sort of a resampled volume is
    hundreds of millions of elements, and the rank only has to be good to a
    few thousandths for a threshold to land in the right place.
    """
    sample = np.asarray(values)[where]
    if sample.size == 0:
        return np.zeros(np.shape(values), dtype=np.float32)
    counts, edges = np.histogram(sample, bins=int(bins))
    running = np.cumsum(counts).astype(np.float64)
    running /= max(running[-1], 1.0)
    slot = np.clip(np.searchsorted(edges[1:-1], values, side="right"),
                   0, int(bins) - 1)
    return running[slot].astype(np.float32)


def derive_channels(available, spacing):
    """Make the three channels the segmenter needs out of what there is.

    The four Dixon reconstructions are not four measurements. They are two:
    in phase is water plus fat, out of phase is the difference. Measured
    against all four on three stations of a real study, the forward direction
    holds - water+fat predicts in phase at r=0.996, |water-fat| predicts out
    of phase at r=0.989 to 0.992. So a station missing its out-of-phase series
    is not a guess, it is arithmetic.

    The reverse does not hold, and is not attempted. These are magnitude
    images: |water - fat| has thrown the sign away, so in and out cannot say
    which of the two dominates a voxel. Measured on the same stations,
    (in+out)/2 predicts water at r=0.71 to 0.89 and |in-out|/2 predicts fat at
    r=0.48 to 0.59, with residuals of 77% to 85%. A fat fraction built on that
    would be worse than no fat fraction at all, so when fat and water are not
    both present the fat terms are switched off rather than invented - the
    out-of-phase line still separates structures, it just cannot tell muscle
    from fat any more.

    With one series and no out-of-phase there is no fascial line to work from.
    The boundary then comes from where the image changes fastest, which is a
    weaker signal but a real one, and it is the only thing left.

    Args:
        available: contrast name -> volume, normalised to 0..1. Keys may be
            any of FAT, WATER, OPP, IN, or ANY for an unclassified series.
        spacing: voxel spacing, for scaling the gradient on anisotropic scans.

    Returns:
        ``(fat, water, outphase, tier)``.
    """
    have = {k: np.asarray(v, dtype=np.float32) for k, v in available.items()
            if v is not None}
    if not have:
        raise ValueError("no series to segment")

    fat = have.get("FAT")
    water = have.get("WATER")
    outphase = have.get("OPP")

    if fat is not None and water is not None:
        if outphase is None:
            # The Dixon difference. Rescaled to the same 0..1 range as the
            # measured series, because everything downstream is a level.
            outphase = np.abs(water - fat)
            ceiling = float(np.percentile(outphase, 99.5))
            outphase = np.clip(outphase / max(ceiling, 1e-6), 0.0, 1.0)
            return fat, water, outphase, TIER_DERIVED_OPP
        return fat, water, outphase, TIER_FULL

    # Whatever single channel carries the anatomy. In phase first, since it is
    # every tissue with signal; otherwise whichever one series there is.
    signal = None
    for key in ("IN", "WATER", "FAT", "ANY", "OPP"):
        if key in have:
            signal = have[key]
            break

    # Fat left at zero makes the fat fraction zero everywhere, which switches
    # off the two terms that use it without needing a second code path.
    blank = np.zeros_like(signal)

    if outphase is not None and outphase is not signal:
        return blank, signal, outphase, TIER_NO_FAT

    # Nothing marks the boundaries, so they have to be found. Gradient
    # magnitude is high where the image changes and low inside a structure,
    # which is upside down from out-of-phase, hence the subtraction - the
    # Boundary Strength control keeps its meaning either way.
    edge = _vg.gradient_magnitude(signal, spacing)
    # Ranked, not scaled. Scaled by a percentile the field piles up near the
    # top - measured at p10=0.43, p50=0.86, p75=0.93 inside tissue on a lumbar
    # T2 - so the bottom half of the control does nothing and every useful
    # setting is crowded into the last fifth. Ranking spreads it evenly, and
    # then Boundary Strength is the share of tissue treated as boundary
    # rather than a level on a scale that changes with every scan.
    lit = signal > 0.05
    if not lit.any():
        lit = np.ones_like(signal, dtype=bool)
    smooth = 1.0 - _rank_of(edge, lit)
    return blank, signal, smooth.astype(np.float32), TIER_GRADIENT


THREAD_WIDTH = 2
"""Widest a run may be, in voxels, and still count as a thread.

Two across in both in-plane directions and tens of slices long is not
anatomy at this resolution; three begins to catch real detail."""


def _remove_threads(labels, mask):
    """Drop the needles: voxels only one or two wide within their own feature.

    The fill-back hands every leftover voxel to whichever label reaches it
    first, and in the dark tissue along a boundary - where no label has a
    claim worth the name - that produces threads one or two voxels across
    running the height of the station. Measured on a head station: the
    out-of-phase under them averaged 0.256 against 0.764 inside the feature
    they were attached to, so they are not the structure, they are the gap
    beside it.

    An opening in plane removes them, and only in plane: a structure may
    legitimately be a slice or two thick, but one two voxels across in both
    in-plane directions and tens of slices long is a thread, not anatomy.
    Measured cost on that station, 0.5% of the feature for all of the
    needles.

    Returns ``(labels, removed_voxels)``.
    """
    solid = labels > 0
    # Only what is actually narrow, measured. This was an opening - erode in
    # plane, dilate back - which removes the threads but also rounds every
    # in-plane corner of a broad surface, slice by slice and independently,
    # so consecutive slices end up with slightly different outlines. Stacked
    # up a curved flank those differences are a ridge per voxel crossed,
    # which is the contour banding. Removing the narrow voxels and nothing
    # else leaves a broad surface exactly where it was.
    narrow = (solid & (_run_along(labels, 1) <= THREAD_WIDTH)
              & (_run_along(labels, 2) <= THREAD_WIDTH))
    removed = int(narrow.sum())
    if removed:
        labels = np.where(narrow, 0, labels)
    return labels, removed


def _empty_stats(mask, volume_cm3, effective_cut, clamped) -> dict:
    """The stats a run reports when it found nothing, with every key present.

    Callers read these by name, and a dict that is the right shape only on the
    paths that happened to be tested is a crash waiting for whichever setting
    reaches the other one.
    """
    return {
        "regions": 0,
        "muscles": 0,
        "boundary_cut": float(effective_cut),
        "boundary_cut_clamped": bool(clamped),
        "muscle_cm3": float(mask.sum() * volume_cm3),
        "largest_cm3": 0.0,
        "single_slice_dropped": 0,
        "threads_cm3": 0.0,
        "thin_layer_moved_cm3": 0.0,
        "thin_layer_dropped_cm3": 0.0,
        "unassigned_fraction": 1.0 if mask.any() else 0.0,
        "filled_fraction": 0.0,
    }


def separate_muscles(fat, water, outphase, spacing,
                     boundary_cut: float = 0.60,
                     min_area_cm2: float = 1.0,
                     link_fraction: float = 0.55,
                     min_volume_cm3: float = 5.0,
                     boundary_fat_fraction: float = 0.22,
                     max_fat_fraction: float = 0.35,
                     min_signal: float = 0.18,
                     max_signal: float = 0.0,
                     min_thickness_slices: float = 3.0,
                     acquired_slice_mm: float = 0.0,
                     clamp_cut: bool = True,
                     mask: np.ndarray | None = None,
                     progress_cb=None):
    """Label individual muscles. Returns ``(labels, stats)``.

    ``labels`` is 0 outside muscle and a positive integer per muscle.
    """
    def report(percent, message):
        if progress_cb is not None:
            progress_cb(float(percent), str(message))

    report(1.0, "Deciding what counts as tissue")
    fat = np.asarray(fat, dtype=np.float32)
    water = np.asarray(water, dtype=np.float32)
    outphase = np.asarray(outphase, dtype=np.float32)
    if mask is None:
        mask = muscle_mask(fat, water,
                           max_fat_fraction=float(max_fat_fraction),
                           min_water=float(min_signal),
                           max_signal=float(max_signal))
    mask = np.asarray(mask, dtype=bool)

    sx, sy, sz = (float(v) for v in spacing)
    area_cm2 = (sx * sy) / 100.0
    volume_cm3 = (sx * sy * sz) / 1000.0
    # The cut is capped against the muscle's own brightness. Asked for 0.80 on
    # a station whose muscle averages 0.499 out-of-phase, the interior came out
    # nearly empty, the separation collapsed, and the fill-back handed the
    # whole chest to two regions - so the control reversed on itself past a
    # point. Capping at the 75th percentile keeps it monotonic: more always
    # means more cutting, never less.
    # Not needed when the boundary field is a rank: a rank is spread evenly by
    # construction, so a cut of c always leaves 1-c of the tissue as interior
    # and can never empty it. Clamping one would cap the control at about 0.25
    # and undo the point of ranking it.
    if clamp_cut:
        inside = (outphase[mask] if mask.any()
                  else np.asarray([0.5], dtype=np.float32))
        ceiling = float(np.percentile(inside, 75.0))
        effective_cut = min(float(boundary_cut), ceiling)
    else:
        effective_cut = float(boundary_cut)
    clamped = effective_cut < float(boundary_cut) - 1e-6

    # A fat plane thinner than a voxel raises the fat fraction without reaching
    # the level that excludes the voxel from muscle, so the boundary is visible
    # in the fat channel while the mask walks straight through it. Measured on
    # a real station, adding this took the largest region from 19.3% of all
    # muscle to 16.6%.
    fraction = fat_fraction(fat, water)
    # Inclusive, so tissue of uniform brightness is not wiped out by a cut
    # that lands exactly on its own value - which is what the cap produces
    # when the signal has little spread.
    interior = (mask
                & (outphase >= effective_cut)
                & (fraction < float(boundary_fat_fraction)))

    report(8.0, "Finding the inside of each structure")
    # --- per slice, where the fascia is actually resolved -------------------
    slice_labels = np.zeros(mask.shape, dtype=np.int32)
    regions = []                       # (slice, label, area in voxels)
    next_id = 1
    n_slices = int(mask.shape[0])
    for z in range(n_slices):
        if z % 8 == 0:
            report(10.0 + 40.0 * z / max(1, n_slices),
                   f"Separating structures in slice {z + 1} of {n_slices}")
        plane = interior[z]
        if not plane.any():
            continue
        labels, sizes = _label_slice(plane)
        keep = (sizes * area_cm2) >= float(min_area_cm2)
        keep[0] = False
        if not keep.any():
            continue
        remap = np.zeros(sizes.size, dtype=np.int32)
        chosen = np.nonzero(keep)[0]
        remap[chosen] = np.arange(next_id, next_id + len(chosen))
        slice_labels[z] = remap[labels]
        for offset, original in enumerate(chosen):
            regions.append((z, next_id + offset, int(sizes[original])))
        next_id += len(chosen)

    total_regions = next_id - 1
    if total_regions == 0:
        # Settings strict enough to leave no interior at all are reachable -
        # a low fat plane on a limb does it - and this used to return a stats
        # dict missing seven of its keys, so the run failed on the way out
        # with a KeyError instead of saying it had found nothing.
        empty = _empty_stats(mask, volume_cm3, effective_cut, clamped)
        return np.zeros(mask.shape, dtype=np.int32), empty

    # --- link regions that overlap between neighbouring slices -------------
    # Linked on mutual best overlap, not merely any overlap: two different
    # muscles lying side by side both overlap their neighbour above, and
    # joining on that alone merges the whole body back into one piece.
    areas = np.zeros(total_regions + 1, dtype=np.int64)
    for _z, label, size in regions:
        areas[label] = size

    edges = []
    for z in range(mask.shape[0] - 1):
        if z % 8 == 0:
            report(50.0 + 20.0 * z / max(1, n_slices),
                   f"Joining slice {z + 1} to the one above it")
        here, above = slice_labels[z], slice_labels[z + 1]
        both = (here > 0) & (above > 0)
        if not both.any():
            continue
        pairs, counts = np.unique(
            np.stack((here[both], above[both])), axis=1, return_counts=True
        )
        if pairs.size == 0:
            continue
        lower, upper = pairs[0], pairs[1]
        # Best partner in each direction.
        best_up, best_down = {}, {}
        for index in range(len(counts)):
            a, b, overlap = int(lower[index]), int(upper[index]), int(counts[index])
            if overlap > best_up.get(a, (0, 0))[1]:
                best_up[a] = (b, overlap)
            if overlap > best_down.get(b, (0, 0))[1]:
                best_down[b] = (a, overlap)
        for a, (b, overlap) in best_up.items():
            if best_down.get(b, (None,))[0] != a:
                continue
            # Compared against the LARGER of the two, not the smaller. Using
            # the smaller meant a small region lying inside a big mass always
            # linked, and those links chained up the stack until 79% of all
            # muscle came back as one 4,991cm3 region. Requiring the overlap to
            # be substantial for both ends is what keeps a thin strap muscle
            # from being absorbed into the mass beside it.
            larger = max(areas[a], areas[b])
            if larger > 0 and overlap >= float(link_fraction) * larger:
                edges.append((a, b))

    parent = _vg._components_of_edges(
        np.asarray(edges, dtype=np.int64).reshape(-1, 2), total_regions + 1
    )
    _roots, compact = np.unique(parent, return_inverse=True)
    region_to_muscle = compact.astype(np.int32)

    labels = np.where(slice_labels > 0, region_to_muscle[slice_labels], 0)

    # --- drop the slivers, renumber, then fill the boundary voxels back ----
    counts = np.bincount(labels.reshape(-1))
    counts[0] = 0
    keep = (counts * volume_cm3) >= float(min_volume_cm3)
    remap = np.zeros(counts.size, dtype=np.int32)
    chosen = np.nonzero(keep)[0]
    remap[chosen] = np.arange(1, len(chosen) + 1)
    labels = remap[labels]

    # The voxels on the fascial line were excluded to make the cut and are
    # still tissue, so they go back to whichever structure reaches them.
    #
    # Confining this to each slice was tried, on the theory that a label
    # flooding upwards was what produced flat one-slice shelves. Measured on a
    # real station it changed nothing about the shelves and left 17.5% of the
    # tissue unassigned against 0.2%, so it was a cost with no benefit.
    report(72.0, "Giving the boundary voxels back")
    seeded = labels > 0
    labels = _vg.propagate_labels(labels, mask | seeded, connectivity=6)
    labels[~mask] = 0
    # Worth reporting: when the interior comes out sparse, most of the result
    # is the fill choosing a nearest structure rather than the segmentation
    # finding a boundary, and the feature edges are guesses.
    filled = int(((labels > 0) & ~seeded).sum())

    # A structure that exists in a single slice and nowhere else is not a
    # three-dimensional thing - at this slice thickness it is one flat sheet,
    # and those were turning up attached to whichever neighbour happened to
    # touch them. Dropped rather than reassigned, because there is nothing to
    # reassign them to.
    report(88.0, "Dropping anything that is only one slice thick")
    thin = 0
    for value in range(1, int(labels.max()) + 1):
        present = labels == value
        if not present.any():
            continue
        slices_used = int(np.count_nonzero(present.any(axis=(1, 2))))
        if slices_used < 2:
            labels[present] = 0
            thin += 1

    # Last, because the fill-back is itself a source of leaks: it hands every
    # leftover voxel to the nearest structure, and a plate of tissue with no
    # structure of its own near it goes to whoever is closest.
    report(92.0, "Repairing layers that leaked across a boundary")
    labels, moved, dropped = _prune_thin_layers(
        labels, mask, sz, float(acquired_slice_mm),
        float(min_thickness_slices))
    # After the thin-layer repair, not before. That step grows labels along
    # the slice axis to hand a leaked plate back to what it sits on, and the
    # same growth run up a one-voxel gap builds a thread - so removing threads
    # first leaves the ones it is about to make. Measured on a head station:
    # 1.4cm3 of needles survived when this ran first, none when it ran last.
    report(96.0, "Removing threads left in the gaps between structures")
    labels, threads = _remove_threads(labels, mask)

    report(100.0, "Segmentation complete")

    final = np.bincount(labels.reshape(-1))
    final[0] = 0
    return labels, {
        "single_slice_dropped": int(thin),
        "threads_cm3": float(threads * volume_cm3),
        "thin_layer_moved_cm3": float(moved * volume_cm3),
        "thin_layer_dropped_cm3": float(dropped * volume_cm3),
        "boundary_cut": float(effective_cut),
        "boundary_cut_clamped": bool(clamped),
        "regions": int(total_regions),
        "muscles": int((final > 0).sum()),
        "muscle_cm3": float(mask.sum() * volume_cm3),
        "largest_cm3": float(final.max() * volume_cm3) if final.size > 1 else 0.0,
        "unassigned_fraction": float(
            (mask & (labels == 0)).sum() / max(1, mask.sum())
        ),
        "filled_fraction": float(
            filled / max(1, int((labels > 0).sum()))
        ),
    }
