"""Thumbnails of each series, for picking one by sight instead of by name.

A study here runs to 87 series whose descriptions differ by a few characters -
"FAT: Ax 3D LAVA Flex BH 1" twenty times over, one per station - so the name
tells you the contrast and nothing about what part of the body it covers.
Choosing by eye is the only way that scales.

Blender's preview collections are the mechanism: a preview's pixels can be set
directly, so nothing has to be written to disk and no image encoder is needed.
Everything here degrades to "no previews" rather than raising, because a
missing thumbnail must never stop a series being selectable.
"""
from __future__ import annotations

_COLLECTION = None
_ICONS: dict[str, int] = {}


def _collection():
    """The addon's preview collection, created on first use."""
    global _COLLECTION
    if _COLLECTION is not None:
        return _COLLECTION
    try:
        import bpy.utils.previews

        _COLLECTION = bpy.utils.previews.new()
    except Exception:
        _COLLECTION = None
    return _COLLECTION


def icon_for(uid: str) -> int:
    """Icon id for a series, or 0 when there is no preview."""
    return int(_ICONS.get(str(uid), 0))


def has_previews() -> bool:
    return bool(_ICONS)


def clear() -> None:
    _ICONS.clear()
    collection = _collection()
    if collection is not None:
        try:
            collection.clear()
        except Exception:
            pass


def build(source_path: str, source_is_zip: bool, series, size: int = 96,
          progress_cb=None):
    """Build a preview per series. Returns ``{uid: encoded thumbnail}``.

    The encoded form is handed back so the caller can store it with the series
    and have it survive saving the file.
    """
    from .io_dicom import load_series_thumbnail

    collection = _collection()
    if collection is None:
        return {}
    clear()
    report = progress_cb or (lambda done, total, label="": None)

    stored = {}
    total = len(series)
    for index, info in enumerate(series, start=1):
        report(index, total, getattr(info, "label", ""))
        try:
            grey = load_series_thumbnail(source_path, source_is_zip, info.uid,
                                         size=size)
        except Exception:
            grey = None
        if grey is None:
            continue
        if _install(index, info.uid, grey):
            stored[str(info.uid)] = encode_thumbnail(grey)
    return stored


def unregister() -> None:
    """Release the collection; Blender leaks previews that outlive the addon."""
    global _COLLECTION
    _ICONS.clear()
    if _COLLECTION is not None:
        try:
            import bpy.utils.previews

            bpy.utils.previews.remove(_COLLECTION)
        except Exception:
            pass
        _COLLECTION = None


def encode_thumbnail(grey) -> str:
    """A thumbnail as text, small enough to live in the .blend file.

    Stored with the series rather than in an external cache so that reopening a
    file shows the previews without the source folder being present, let alone
    rescanned. One byte per pixel at 96x96 is 9KB before base64, so a study of
    141 series costs a couple of megabytes - cheap against reading every DICOM
    header again.
    """
    import base64

    import numpy as np

    if grey is None:
        return ""
    data = np.asarray(grey, dtype=np.float32)
    if data.ndim != 2 or data.size == 0:
        return ""
    height, width = data.shape
    quantised = np.clip(data * 255.0, 0.0, 255.0).astype(np.uint8)
    payload = base64.b64encode(quantised.tobytes()).decode("ascii")
    return f"{width}x{height}:{payload}"


def decode_thumbnail(text: str):
    """The array ``encode_thumbnail`` stored, or ``None``."""
    import base64

    import numpy as np

    raw = str(text or "")
    if ":" not in raw:
        return None
    header, _sep, payload = raw.partition(":")
    try:
        width, _x, height = header.partition("x")
        width, height = int(width), int(height)
        data = np.frombuffer(base64.b64decode(payload), dtype=np.uint8)
        if data.size != width * height:
            return None
        return (data.reshape(height, width).astype(np.float32) / 255.0)
    except Exception:
        return None


def _install(index: int, uid: str, grey) -> bool:
    """Put one greyscale array into the preview collection."""
    collection = _collection()
    if collection is None or grey is None:
        return False
    try:
        import numpy as np

        name = f"dicom_series_{index:04d}"
        preview = collection.new(name)
        height, width = grey.shape
        preview.image_size = (int(width), int(height))
        # Blender wants RGBA bottom-up; the slice is top-down.
        flipped = np.asarray(grey, dtype=np.float32)[::-1, :]
        rgba = np.repeat(flipped.reshape(-1, 1), 4, axis=1)
        rgba[:, 3] = 1.0
        preview.image_pixels_float = rgba.reshape(-1).tolist()
        _ICONS[str(uid)] = int(preview.icon_id)
        return True
    except Exception:
        return False


def restore(series_items) -> int:
    """Rebuild previews from thumbnails stored on the series, without any IO.

    Called when a file is opened: the series list survives in the .blend but a
    preview collection does not, so without this a saved file shows a series
    dropdown with no images until the source is rescanned.
    """
    clear()
    made = 0
    for index, item in enumerate(series_items, start=1):
        uid = str(getattr(item, "uid", "") or "")
        if not uid:
            continue
        grey = decode_thumbnail(getattr(item, "thumbnail", ""))
        if grey is None:
            continue
        if _install(index, uid, grey):
            made += 1
    return made
