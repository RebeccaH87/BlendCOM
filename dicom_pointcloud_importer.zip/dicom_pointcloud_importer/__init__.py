from __future__ import annotations

from pathlib import Path
import sys

bl_info = {
    "name": "DICOM Point Cloud Importer",
    "author": "GitHub Copilot",
    "version": (0, 96, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > DICOM",
    "description": "Import DICOM as point clouds, raise their resolution, and mesh only the outside surface",
    "warning": "",
    "doc_url": "",
    "category": "Import-Export",
}


def _bootstrap_vendor_path() -> None:
    vendor = Path(__file__).resolve().parent / "vendor"
    if vendor.exists():
        vendor_str = str(vendor)
        if vendor_str not in sys.path:
            sys.path.insert(0, vendor_str)


_bootstrap_vendor_path()

import bpy
try:
    from bpy.app.handlers import persistent
except Exception:  # a stand-in bpy, as the tests provide, has no handlers
    def persistent(function):
        return function


from .operators import DICOM_OT_volume_to_mesh, DICOM_OT_import_as_volume, DICOM_OT_refresh_volume_look, DICOM_OT_drop_volume, DICOM_FH_drop, DICOM_OT_add_voxel_remesh, DICOM_OT_split_selected_cloud, DICOM_OT_separate_muscles, DICOM_OT_cancel_mesh_conversion, DICOM_OT_cancel_segmentation, DICOM_OT_copy_diagnostics, DICOM_OT_create_filtered_pointcloud, DICOM_OT_import_contrast_group, DICOM_OT_import_point_cloud, DICOM_OT_inspect_pointcloud, DICOM_OT_scan_series
from .panel import (
    DICOMImportProperties,
    DICOMSeriesItem,
    DICOM_PT_import_panel,
    DICOM_PT_segmentation_panel,
    DICOM_PT_reconstruction_panel,
    DICOM_PT_volume_panel,
)

try:
    from .operators import DICOM_OT_segment_bones  # type: ignore
except Exception:
    DICOM_OT_segment_bones = None

try:
    from .operators import DICOM_OT_pointcloud_to_hull_mesh  # type: ignore
except Exception:
    DICOM_OT_pointcloud_to_hull_mesh = None

try:
    from .operators import DICOM_OT_pointcloud_extract_surface  # type: ignore
except Exception:
    DICOM_OT_pointcloud_extract_surface = None

try:
    from .operators import DICOM_OT_pointcloud_upsample  # type: ignore
except Exception:
    DICOM_OT_pointcloud_upsample = None


CLASSES = [
    DICOMSeriesItem,
    DICOMImportProperties,
    DICOM_OT_scan_series,
    DICOM_OT_add_voxel_remesh,
    DICOM_OT_split_selected_cloud,
    DICOM_OT_cancel_mesh_conversion,
    DICOM_OT_cancel_segmentation,
    DICOM_OT_copy_diagnostics,
    DICOM_OT_inspect_pointcloud,
    DICOM_OT_create_filtered_pointcloud,
    DICOM_OT_import_point_cloud,
    DICOM_OT_import_contrast_group,
    DICOM_OT_separate_muscles,
    DICOM_OT_import_as_volume,
    DICOM_OT_refresh_volume_look,
    DICOM_OT_drop_volume,
    DICOM_OT_volume_to_mesh,
]

from .operators import HAS_FILE_HANDLER

if HAS_FILE_HANDLER:
    # Only registerable where Blender has the base class; without it the
    # addon simply has no drag-and-drop.
    CLASSES.append(DICOM_FH_drop)

if DICOM_OT_pointcloud_to_hull_mesh is not None:
    CLASSES.append(DICOM_OT_pointcloud_to_hull_mesh)

if DICOM_OT_pointcloud_extract_surface is not None:
    CLASSES.append(DICOM_OT_pointcloud_extract_surface)

if DICOM_OT_pointcloud_upsample is not None:
    CLASSES.append(DICOM_OT_pointcloud_upsample)

if DICOM_OT_segment_bones is not None:
    CLASSES.append(DICOM_OT_segment_bones)

CLASSES.append(DICOM_PT_import_panel)
CLASSES.append(DICOM_PT_segmentation_panel)
CLASSES.append(DICOM_PT_reconstruction_panel)
CLASSES.append(DICOM_PT_volume_panel)


@persistent
def _restore_series_previews(_file_path):
    """Rebuild the preview images after a file is opened.

    The series list is saved in the .blend but a preview collection is not -
    it lives in the running Blender, so a reopened file showed a series
    dropdown with no images until the source was scanned again. The thumbnails
    were saved with the series, so this is a decode rather than any file IO.
    """
    try:
        from . import previews

        for scene in bpy.data.scenes:
            props = getattr(scene, "dicom_import_props", None)
            if props is not None and len(props.series_items):
                previews.restore(props.series_items)
                break
    except Exception as exc:
        print(f"[DICOM] could not restore previews: {exc}")


def register():
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is not None and _restore_series_previews not in handlers.load_post:
        handlers.load_post.append(_restore_series_previews)

    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.dicom_import_props = bpy.props.PointerProperty(type=DICOMImportProperties)


def unregister():
    # A pending surface rebuild outlives the addon otherwise, and fires into
    # a module that is no longer there.
    try:
        from .operators import _apply_pending_levels

        if bpy.app.timers.is_registered(_apply_pending_levels):
            bpy.app.timers.unregister(_apply_pending_levels)
    except Exception:
        pass

    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is not None and _restore_series_previews in handlers.load_post:
        handlers.load_post.remove(_restore_series_previews)

    # Preview collections outlive the addon unless released, and Blender warns
    # about the leak on reload.
    try:
        from . import previews as _previews

        _previews.unregister()
    except Exception:
        pass

    del bpy.types.Scene.dicom_import_props

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
