"""Minimal NIfTI-1 reader and writer.

Enough to hand a volume to an external segmentation tool and read its labels
back, without taking a dependency on nibabel - the addon vendors pydicom at
12MB and anything heavier has to live outside Blender's Python.

The only part that is subtle is the affine. DICOM places voxels in LPS
millimetres; NIfTI uses RAS. Getting that conversion wrong does not fail
loudly - it returns a label map that is mirrored, and a mirrored spine looks
entirely plausible until it is overlaid on the cloud it came from.
"""
from __future__ import annotations

import struct

import numpy as np

NIFTI1_HEADER_SIZE = 348
_DTYPE_CODES = {
    np.dtype(np.uint8): 2,
    np.dtype(np.int16): 4,
    np.dtype(np.int32): 8,
    np.dtype(np.float32): 16,
    np.dtype(np.float64): 64,
    np.dtype(np.uint16): 512,
    np.dtype(np.uint32): 768,
}
_CODE_DTYPES = {code: dtype for dtype, code in _DTYPE_CODES.items()}


def affine_from_dicom(origin, orientation, spacing) -> np.ndarray:
    """Voxel index (x, y, z) -> RAS millimetres, from DICOM geometry.

    ``origin`` is ImagePositionPatient of the first slice, ``orientation`` the
    ``(row, column, slice)`` direction cosines this addon already derives, and
    ``spacing`` is ``(x, y, z)`` in millimetres.

    DICOM's patient coordinates are LPS: +x to the patient's left, +y
    posterior, +z superior. NIfTI is RAS, so the first two axes flip.
    """
    row, col, normal = (np.asarray(v, dtype=np.float64) for v in orientation)
    length = np.linalg.norm(normal)
    normal = normal / length if length > 1e-9 else np.cross(row, col)
    sx, sy, sz = (float(v) for v in spacing)

    affine = np.eye(4, dtype=np.float64)
    affine[:3, 0] = row * sx
    affine[:3, 1] = col * sy
    affine[:3, 2] = normal * sz
    affine[:3, 3] = np.asarray(origin, dtype=np.float64)
    # LPS -> RAS.
    affine[0, :] *= -1.0
    affine[1, :] *= -1.0
    return affine


def _quaternion_from_affine(affine):
    """NIfTI quaternion terms for a right-handed affine, plus qfac."""
    rotation = affine[:3, :3].astype(np.float64)
    scale = np.linalg.norm(rotation, axis=0)
    scale[scale < 1e-12] = 1.0
    basis = rotation / scale
    qfac = 1.0
    if np.linalg.det(basis) < 0:
        basis[:, 2] *= -1.0
        qfac = -1.0

    trace = basis[0, 0] + basis[1, 1] + basis[2, 2]
    if trace > 0:
        w = 0.5 * np.sqrt(1.0 + trace)
        factor = 0.25 / w
        b = factor * (basis[2, 1] - basis[1, 2])
        c = factor * (basis[0, 2] - basis[2, 0])
        d = factor * (basis[1, 0] - basis[0, 1])
    else:
        axis = int(np.argmax([basis[0, 0], basis[1, 1], basis[2, 2]]))
        if axis == 0:
            s = 2.0 * np.sqrt(1.0 + basis[0, 0] - basis[1, 1] - basis[2, 2])
            w = (basis[2, 1] - basis[1, 2]) / s
            b, c, d = 0.25 * s, (basis[0, 1] + basis[1, 0]) / s, (basis[0, 2] + basis[2, 0]) / s
        elif axis == 1:
            s = 2.0 * np.sqrt(1.0 + basis[1, 1] - basis[0, 0] - basis[2, 2])
            w = (basis[0, 2] - basis[2, 0]) / s
            b, c, d = (basis[0, 1] + basis[1, 0]) / s, 0.25 * s, (basis[1, 2] + basis[2, 1]) / s
        else:
            s = 2.0 * np.sqrt(1.0 + basis[2, 2] - basis[0, 0] - basis[1, 1])
            w = (basis[1, 0] - basis[0, 1]) / s
            b, c, d = (basis[0, 2] + basis[2, 0]) / s, (basis[1, 2] + basis[2, 1]) / s, 0.25 * s
    if w < 0:
        b, c, d = -b, -c, -d
    return float(b), float(c), float(d), float(qfac), scale


def write_nifti(path, volume: np.ndarray, affine: np.ndarray) -> None:
    """Write ``volume`` indexed ``[x, y, z]`` with the given voxel-to-RAS affine."""
    data = np.asarray(volume)
    if data.ndim != 3:
        raise ValueError("volume must be 3D")
    dtype = data.dtype
    if dtype not in _DTYPE_CODES:
        data = data.astype(np.float32)
        dtype = data.dtype
    affine = np.asarray(affine, dtype=np.float64)

    b, c, d, qfac, scale = _quaternion_from_affine(affine)
    header = bytearray(NIFTI1_HEADER_SIZE)
    struct.pack_into("<i", header, 0, NIFTI1_HEADER_SIZE)
    struct.pack_into("<8h", header, 40, 3, *data.shape, 1, 1, 1, 1)
    struct.pack_into("<h", header, 70, _DTYPE_CODES[dtype])
    struct.pack_into("<h", header, 72, dtype.itemsize * 8)
    # pixdim[0] is qfac; the three spacings follow.
    struct.pack_into("<8f", header, 76, qfac, *[float(v) for v in scale], 0, 0, 0, 0)
    struct.pack_into("<f", header, 108, float(NIFTI1_HEADER_SIZE + 4))   # vox_offset
    struct.pack_into("<f", header, 112, 1.0)                            # scl_slope
    struct.pack_into("<B", header, 123, 2 | (1 << 3))                   # mm, sec
    struct.pack_into("<h", header, 252, 1)                              # qform NIFTI_XFORM_SCANNER_ANAT
    struct.pack_into("<h", header, 254, 1)                              # sform
    struct.pack_into("<3f", header, 256, b, c, d)
    struct.pack_into("<3f", header, 268, *[float(v) for v in affine[:3, 3]])
    struct.pack_into("<4f", header, 280, *[float(v) for v in affine[0, :]])
    struct.pack_into("<4f", header, 296, *[float(v) for v in affine[1, :]])
    struct.pack_into("<4f", header, 312, *[float(v) for v in affine[2, :]])
    header[344:348] = b"n+1\x00"

    payload = np.ascontiguousarray(data.transpose(2, 1, 0)).tobytes()
    blob = bytes(header) + b"\x00\x00\x00\x00" + payload
    path = str(path)
    if path.endswith(".gz"):
        import gzip

        with gzip.open(path, "wb") as handle:
            handle.write(blob)
    else:
        with open(path, "wb") as handle:
            handle.write(blob)


def read_nifti(path):
    """Return ``(volume indexed [x, y, z], voxel-to-RAS affine)``."""
    path = str(path)
    if path.endswith(".gz"):
        import gzip

        with gzip.open(path, "rb") as handle:
            blob = handle.read()
    else:
        with open(path, "rb") as handle:
            blob = handle.read()
    if len(blob) < NIFTI1_HEADER_SIZE:
        raise ValueError("file is too short to be NIfTI")

    size = struct.unpack_from("<i", blob, 0)[0]
    if size != NIFTI1_HEADER_SIZE:
        raise ValueError("not a little-endian NIfTI-1 file")
    dims = struct.unpack_from("<8h", blob, 40)
    if dims[0] < 3:
        raise ValueError("expected at least 3 dimensions")
    shape = (int(dims[1]), int(dims[2]), int(dims[3]))
    code = struct.unpack_from("<h", blob, 70)[0]
    if code not in _CODE_DTYPES:
        raise ValueError(f"unsupported NIfTI datatype {code}")
    dtype = _CODE_DTYPES[code]
    offset = int(struct.unpack_from("<f", blob, 108)[0]) or NIFTI1_HEADER_SIZE + 4

    count = shape[0] * shape[1] * shape[2]
    data = np.frombuffer(blob, dtype=dtype, count=count, offset=offset)
    volume = data.reshape(shape[2], shape[1], shape[0]).transpose(2, 1, 0)

    affine = np.eye(4, dtype=np.float64)
    if struct.unpack_from("<h", blob, 254)[0] > 0:        # sform wins when set
        affine[0, :] = struct.unpack_from("<4f", blob, 280)
        affine[1, :] = struct.unpack_from("<4f", blob, 296)
        affine[2, :] = struct.unpack_from("<4f", blob, 312)
    else:
        pixdim = struct.unpack_from("<8f", blob, 76)
        qfac = -1.0 if pixdim[0] < 0 else 1.0
        b, c, d = struct.unpack_from("<3f", blob, 256)
        a = float(np.sqrt(max(0.0, 1.0 - (b * b + c * c + d * d))))
        rotation = np.array([
            [a * a + b * b - c * c - d * d, 2 * (b * c - a * d), 2 * (b * d + a * c)],
            [2 * (b * c + a * d), a * a + c * c - b * b - d * d, 2 * (c * d - a * b)],
            [2 * (b * d - a * c), 2 * (c * d + a * b), a * a + d * d - b * b - c * c],
        ])
        scale = np.array([pixdim[1], pixdim[2], pixdim[3] * qfac], dtype=np.float64)
        affine[:3, :3] = rotation * scale
        affine[:3, 3] = struct.unpack_from("<3f", blob, 268)
    return np.ascontiguousarray(volume), affine


def voxel_centres_to_world(shape, affine) -> np.ndarray:
    """World (RAS mm) position of every voxel centre, as ``(N, 3)``."""
    nx, ny, nz = (int(v) for v in shape)
    xs, ys, zs = np.meshgrid(np.arange(nx), np.arange(ny), np.arange(nz), indexing="ij")
    idx = np.stack((xs.ravel(), ys.ravel(), zs.ravel(),
                    np.ones(xs.size)), axis=0).astype(np.float64)
    return (np.asarray(affine, dtype=np.float64) @ idx)[:3].T
