"""High-accuracy scalar-field resampling in pure numpy.

This is the module that actually buys resolution the scan does not have. It
resamples a scalar field (a DICOM volume, or an occupancy indicator built from a
point cloud) onto a finer lattice using a proper reconstruction filter, so the
extracted surface can be positioned between original samples instead of snapping
to them.

Why a reconstruction filter and not midpoint insertion:

* Nearest / midpoint duplication adds samples but no information - the surface
  still snaps to the original lattice, so stair-stepping survives at the new
  resolution.
* Trilinear is C0 only. Its second derivative is discontinuous at every cell
  boundary, which shows up as faceting on smooth anatomy.
* **Catmull-Rom cubic** (the default) is C1 and interpolating: it reproduces the
  original samples exactly and reconstructs the gradient across them, so a
  0.5-level-set lands where the underlying boundary actually is. This is the
  right default for medical data.
* **Lanczos-3** has a sharper frequency response and preserves fine trabecular
  texture better, at the cost of stronger ringing.

Both cubic and Lanczos overshoot at hard bone/air edges, which appears as a
bright halo just inside the cortex and a dark rim just outside. ``clamp``
(on by default) limits every output sample to the range spanned by its two
nearest input samples. Overshoot is removed, while the filter's gradient
reconstruction inside that range - the part that actually improves accuracy -
is kept. This is the standard monotone-cubic trick and it matters here: without
it, thresholding a cubically-upsampled CT produces phantom shells around dense
bone.

Resampling is separable: one axis at a time, so cost is O(taps) per axis rather
than O(taps^3), and axes are processed smallest-output-first to keep peak memory
down.
"""

from __future__ import annotations

import numpy as np


FILTERS = ("linear", "cubic", "lanczos")

# Rows processed per block when gathering taps. Each tap materialises a
# (rows, n_out) temporary, so this bounds peak memory during a pass.
_ROW_BLOCK_ELEMENTS = 1 << 21


def _catmull_rom_weights(t: np.ndarray) -> np.ndarray:
    """Catmull-Rom (a = -0.5) weights for taps at offsets -1, 0, 1, 2."""
    t = t.astype(np.float64)
    t2 = t * t
    t3 = t2 * t
    return np.stack(
        (
            -0.5 * t3 + t2 - 0.5 * t,
            1.5 * t3 - 2.5 * t2 + 1.0,
            -1.5 * t3 + 2.0 * t2 + 0.5 * t,
            0.5 * t3 - 0.5 * t2,
        ),
        axis=1,
    )


def _sinc(x: np.ndarray) -> np.ndarray:
    return np.sinc(x)


def _lanczos_weights(t: np.ndarray, lobes: int = 3) -> np.ndarray:
    """Lanczos weights for taps at offsets -(lobes-1) .. lobes."""
    t = t.astype(np.float64)
    offsets = np.arange(-(lobes - 1), lobes + 1, dtype=np.float64)
    x = t[:, None] - offsets[None, :]
    w = _sinc(x) * _sinc(x / float(lobes))
    w[np.abs(x) >= float(lobes)] = 0.0
    total = w.sum(axis=1, keepdims=True)
    total[np.abs(total) < 1e-12] = 1.0
    return w / total


def _linear_weights(t: np.ndarray) -> np.ndarray:
    t = t.astype(np.float64)
    return np.stack((1.0 - t, t), axis=1)


def _tap_table(n_in: int, n_out: int, method: str):
    """Build the per-output-sample tap indices and weights for one axis.

    Uses centre-aligned mapping so input and output grids cover the same
    world-space box: ``src = (i + 0.5) * n_in / n_out - 0.5``. Taps are clamped
    to the array, which is equivalent to edge extension.

    Returns:
        ``(taps, weights, left, right)`` where ``taps`` and ``weights`` are
        ``(n_out, k)`` and ``left``/``right`` are the two nearest input indices
        used by the overshoot clamp.
    """
    if n_in < 1:
        raise ValueError("input axis length must be >= 1")
    scale = float(n_in) / float(n_out)
    src = (np.arange(n_out, dtype=np.float64) + 0.5) * scale - 0.5

    base = np.floor(src).astype(np.int64)
    frac = src - base

    if method == "linear" or n_in < 3:
        weights = _linear_weights(frac)
        offsets = np.array([0, 1], dtype=np.int64)
    elif method == "cubic":
        weights = _catmull_rom_weights(frac)
        offsets = np.array([-1, 0, 1, 2], dtype=np.int64)
    elif method == "lanczos":
        if n_in < 6:
            weights = _catmull_rom_weights(frac)
            offsets = np.array([-1, 0, 1, 2], dtype=np.int64)
        else:
            weights = _lanczos_weights(frac, lobes=3)
            offsets = np.arange(-2, 4, dtype=np.int64)
    else:
        raise ValueError(f"unknown filter {method!r}; expected one of {FILTERS}")

    taps = np.clip(base[:, None] + offsets[None, :], 0, n_in - 1)
    left = np.clip(base, 0, n_in - 1)
    right = np.clip(base + 1, 0, n_in - 1)
    return taps, weights.astype(np.float32), left, right


def _resample_axis(volume: np.ndarray, axis: int, n_out: int, method: str, clamp: bool) -> np.ndarray:
    n_in = volume.shape[axis]
    if n_out == n_in:
        # Interpolating kernels reproduce the input exactly at identity scale,
        # so there is nothing to gain from running the filter.
        return volume

    taps, weights, left, right = _tap_table(n_in, n_out, method)

    moved = np.moveaxis(volume, axis, -1)
    moved_shape = moved.shape
    flat = np.ascontiguousarray(moved).reshape(-1, n_in)
    rows = flat.shape[0]

    out = np.empty((rows, n_out), dtype=np.float32)
    block = max(1, _ROW_BLOCK_ELEMENTS // max(1, n_out))

    for start in range(0, rows, block):
        stop = min(rows, start + block)
        chunk = flat[start:stop]
        acc = np.zeros((stop - start, n_out), dtype=np.float32)
        for k in range(taps.shape[1]):
            acc += chunk[:, taps[:, k]] * weights[:, k]
        if clamp and taps.shape[1] > 2:
            lo = chunk[:, left]
            hi = chunk[:, right]
            np.clip(acc, np.minimum(lo, hi), np.maximum(lo, hi), out=acc)
        out[start:stop] = acc

    out = out.reshape(moved_shape[:-1] + (n_out,))
    return np.moveaxis(out, -1, axis)


def target_shape_for_factors(shape, factors):
    """Output shape (nz, ny, nx) for per-axis factors given as (fx, fy, fz)."""
    nz, ny, nx = (int(v) for v in shape)
    fx, fy, fz = (max(1e-6, float(v)) for v in factors)
    return (
        max(1, int(round(nz * fz))),
        max(1, int(round(ny * fy))),
        max(1, int(round(nx * fx))),
    )


def resample_volume(
    volume: np.ndarray,
    factors=None,
    out_shape=None,
    method: str = "cubic",
    clamp: bool = True,
    voxel_budget: int | None = None,
) -> np.ndarray:
    """Resample a 3D scalar field onto a different sample count.

    Args:
        volume: 3D array indexed ``[z, y, x]``.
        factors: Per-axis multipliers as ``(fx, fy, fz)``. Values above 1
            increase resolution. Ignored when ``out_shape`` is given.
        out_shape: Explicit output shape ``(nz, ny, nx)``.
        method: ``"linear"``, ``"cubic"`` (Catmull-Rom, default) or
            ``"lanczos"`` (3-lobe).
        clamp: Limit each output sample to the range of its two nearest input
            samples, removing ringing at hard edges. Strongly recommended for
            CT, where the bone/air step would otherwise produce halos.
        voxel_budget: Optional cap on output voxels; raises ``MemoryError``.

    Returns:
        float32 array of shape ``out_shape``.
    """
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")
    if method not in FILTERS:
        raise ValueError(f"unknown filter {method!r}; expected one of {FILTERS}")

    if out_shape is None:
        if factors is None:
            raise ValueError("provide either factors or out_shape")
        out_shape = target_shape_for_factors(vol.shape, factors)
    out_shape = tuple(max(1, int(v)) for v in out_shape)

    if voxel_budget is not None:
        from .voxelgrid import check_voxel_budget

        check_voxel_budget(out_shape, int(voxel_budget), what="Resampled volume")

    work = vol.astype(np.float32, copy=False)
    if work.shape == out_shape:
        return work.copy()

    # Shrink first, grow last: peak memory is driven by the largest intermediate.
    order = sorted(range(3), key=lambda ax: out_shape[ax] / max(1, work.shape[ax]))
    for axis in order:
        if work.shape[axis] != out_shape[axis]:
            work = _resample_axis(work, axis, out_shape[axis], method, clamp)

    return np.ascontiguousarray(work, dtype=np.float32)


def isotropic_factors(spacing, target_spacing: float | None = None, extra: float = 1.0):
    """Per-axis factors that make voxels cubic, then scale them all by ``extra``.

    CT and MRI are routinely anisotropic - 0.5 mm in plane, 2-3 mm between
    slices. Upsampling every axis by the same amount preserves that anisotropy
    and with it the stair-stepping along Z. This computes per-axis factors that
    drive all three spacings to a common value first.

    Args:
        spacing: Source spacing ``(sx, sy, sz)``.
        target_spacing: Desired isotropic spacing. Defaults to the smallest
            source spacing, i.e. no axis is ever blurred to match a coarser one.
        extra: Additional uniform multiplier applied on top (1.0 = isotropy
            only, 2.0 = isotropy then twice as fine again).

    Returns:
        ``(fx, fy, fz)`` factors and the resulting isotropic spacing.
    """
    sx, sy, sz = (max(1e-9, float(v)) for v in spacing)
    if target_spacing is None or float(target_spacing) <= 0.0:
        target = min(sx, sy, sz)
    else:
        target = float(target_spacing)
    target = target / max(1e-6, float(extra))
    return (sx / target, sy / target, sz / target), target


def budget_limited_factors(shape, factors, voxel_budget: int):
    """Scale ``factors`` down uniformly until the output fits in the budget.

    Returns ``(factors, was_reduced)``. Aspect ratio between axes is preserved,
    so an anisotropy correction is never silently undone - only its magnitude
    is reduced.
    """
    nz, ny, nx = (int(v) for v in shape)
    fx, fy, fz = (max(1e-6, float(v)) for v in factors)
    out = target_shape_for_factors((nz, ny, nx), (fx, fy, fz))
    if out[0] * out[1] * out[2] <= int(voxel_budget):
        return (fx, fy, fz), False

    # Rounding each axis up to a whole sample count can push the product back
    # over the budget, so shrink until it actually fits.
    scaled = (fx, fy, fz)
    for _ in range(64):
        total = out[0] * out[1] * out[2]
        if total <= int(voxel_budget):
            break
        ratio = min(0.999, (float(voxel_budget) / float(total)) ** (1.0 / 3.0))
        scaled = (
            max(1e-6, scaled[0] * ratio),
            max(1e-6, scaled[1] * ratio),
            max(1e-6, scaled[2] * ratio),
        )
        out = target_shape_for_factors((nz, ny, nx), scaled)

    return scaled, True


def gaussian_blur(volume: np.ndarray, sigma_voxels, truncate: float = 3.0) -> np.ndarray:
    """Separable Gaussian blur with per-axis sigma in voxel units.

    Args:
        volume: 3D array indexed ``[z, y, x]``.
        sigma_voxels: Scalar, or ``(sigma_z, sigma_y, sigma_x)``.
        truncate: Kernel radius in standard deviations.

    Returns:
        float32 array, same shape. Edges use edge-value extension so the
        boundary is not pulled toward zero.
    """
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")

    if np.isscalar(sigma_voxels):
        sigmas = (float(sigma_voxels),) * 3
    else:
        sigmas = tuple(float(v) for v in sigma_voxels)

    out = vol
    for axis, sigma in enumerate(sigmas):
        if sigma < 0.05:
            continue
        radius = max(1, int(np.ceil(sigma * float(truncate))))
        offsets = np.arange(-radius, radius + 1, dtype=np.float64)
        kernel = np.exp(-0.5 * (offsets / sigma) ** 2)
        kernel /= kernel.sum()
        out = _convolve_axis(out, kernel.astype(np.float32), axis)
    return out


def _convolve_axis(volume: np.ndarray, kernel: np.ndarray, axis: int) -> np.ndarray:
    moved = np.moveaxis(volume, axis, -1)
    moved_shape = moved.shape
    n = moved_shape[-1]
    flat = np.ascontiguousarray(moved).reshape(-1, n)
    radius = kernel.size // 2

    padded = np.pad(flat, ((0, 0), (radius, radius)), mode="edge")
    out = np.zeros_like(flat)
    for i, w in enumerate(kernel):
        if w == 0.0:
            continue
        out += padded[:, i : i + n] * w

    out = out.reshape(moved_shape)
    return np.moveaxis(out, -1, axis)
