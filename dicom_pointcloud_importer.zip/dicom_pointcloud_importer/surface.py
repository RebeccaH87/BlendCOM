"""Outside-only surface reconstruction and resolution enhancement.

Two problems are solved here, and they share one machine.

**Resolution.** The scan has whatever resolution it has, and no amount of point
duplication changes that. What *can* be recovered is sub-sample surface
position: the boundary between bone and air does not sit on a lattice point, it
sits somewhere between them, and where exactly is encoded in the intensity
gradient (volume path) or, failing that, in the occupancy pattern (point-cloud
path). So the pipeline reconstructs a continuous scalar field, resamples it onto
a finer - and optionally isotropic - lattice with a proper interpolating filter,
and reads the surface off as a level set. Vertices then land at interpolated
crossings rather than snapping to voxel corners. See ``resample`` for why the
filter choice matters.

**Outside-only geometry.** The requirement is that only points *not surrounded
on all sides* count as geometry: densely packed interior points are bulk
density, not surface. A viewpoint-based test (hidden-point removal, ray casting
from outside) cannot express this, because it would also hide the wall of an
enclosed void - and an empty marrow cavity is exactly the case that has to
survive. So the test is topological instead:

1. Snap the cloud onto its native lattice to get dense occupancy.
2. Bridge sampling gaps with a morphological close, so a missing sample does
   not read as a hole.
3. Flood the *empty* space starting from outside the scanned region. Empty space
   that is reached is ambient air; empty space that is not reached is an
   enclosed void.
4. Triage the enclosed voids by size: tiny ones are sampling noise and get
   filled; large ones are real cavities and are kept.
5. Keep solid voxels with at least one non-solid neighbour. Ambient air and
   kept cavities both count as non-solid, so the outer skin *and* every cavity
   wall survive, while genuinely enclosed interior voxels drop out.

That single rule - "solid, with a non-solid neighbour" - is the literal reading
of the requirement, and because step 3 distinguishes cavity air from ambient
air, a hollowed-out region shows up in the mesh as its own closed surface
whether or not it is visible from outside.
"""

from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field
import math

import numpy as np

from . import resample as _resample
from . import voxelgrid as _vg
from .isosurface import extract_isosurface
from .voxelgrid import GridSpec


ISOVALUE = 0.5
"""Level set of the smoothed occupancy indicator taken as the surface.

0.5 is the unbiased choice for a binary indicator: with no other information,
the maximum-likelihood boundary sits halfway between the outermost occupied
sample and the first empty one.
"""

UPSAMPLE_MODES = ("SHELL", "SOLID")


def _noop_progress(percent: float, message: str = "") -> None:
    return None


@dataclass
class ShellSettings:
    """Controls for both the resolution and the outside-only stages."""

    resolution_multiplier: float = 2.0
    """How much finer than the source lattice to reconstruct. 1.0 = same
    sample count (still gains sub-voxel surface placement); 2.0 = twice as fine
    per axis. Cost scales with the cube of this, bounded by ``voxel_budget``."""

    isotropic: bool = True
    """Equalise voxel aspect ratio before applying the multiplier. CT/MRI slice
    spacing is often 3-6x the in-plane spacing, and that anisotropy *is* the
    stair-stepping; upsampling all axes equally preserves it."""

    filter_method: str = "cubic"
    """``"linear"``, ``"cubic"`` (Catmull-Rom, default) or ``"lanczos"``."""

    clamp_overshoot: bool = True
    """Suppress filter ringing at hard bone/air edges. Leave on for CT."""

    surface_sigma: float = 0.4
    """Gaussian blur applied to the indicator before resampling, in source
    voxels. Removes voxel faceting.

    0.4 rather than 0.6, because a blur erases a feature narrower than itself
    and the threshold is sharp: a lone voxel at full strength comes out of a
    0.2 blur at 1.000, a 0.4 blur at 0.777, and a 0.6 blur at 0.293 - below the
    isovalue, so it is gone. At 0.6 only 212 of a segmented band's 1,194 pieces
    still had any material left, which is what made such a cloud reconstruct as
    a handful of lumps. Above ~0.9 it also starts closing narrow cavities."""

    trust_points: bool = True
    """Treat every voxel holding points as material, whatever its density.

    There is no reason to turn this off; it exists so the claim stays testable.

    True is simply what the data says: a point is a sample of material. The
    density level is calibrated to the bulk interior, so it cuts inside
    anything narrower than the kernel and deletes the thinnest structures
    outright - 5,470 of one segmented band's 28,713 occupied voxels."""

    sever_bridges: bool = True
    """Refuse to fuse pieces the source occupancy keeps separate."""

    cover_points: bool = False
    """Guarantee every input point ends up inside the surface.

    Grows a ball of :attr:`cover_radius` source voxels around every occupied
    voxel and contours the union of those balls - the same shape a skin
    modifier on the points would give, except that it is built as one scalar
    field, so overlapping balls merge instead of intersecting and there is no
    interior geometry to remesh away.

    The ordinary path makes no such promise, and cannot: it reconstructs the
    surface the points *imply*, so a point sitting in a thin or sparse region
    can legitimately fall outside it, and the speckle and island filters remove
    small pieces by design. This mode is for when coverage matters more than
    the surface being the most plausible one - and it turns those two filters
    off, because leaving them on would silently break the guarantee.
    """

    cover_radius: float = 1.0
    """Ball radius for :attr:`cover_points`, in source voxels.

    1.0 reaches each point's immediate neighbours, which is enough to close the
    gaps between adjacent samples without inflating the body. Larger values
    thicken everything and start bridging genuinely separate structures."""

    gap_bridge_voxels: int = 0
    """Whether the gaps in a sparse cloud are real, and how hard to close them.

    At 0 they are taken as real: pieces the source keeps separate are never
    joined. Right for a segmented intensity band, where the absent samples
    belong to other bands and the sparseness is the structure.

    Above 0 they are taken as missing samples: the density kernel widens by 0.9
    source voxels per step, bridging gaps of roughly twice that, and pieces are
    allowed to merge. Right for an under-sampled solid - a sphere from a tenth
    of its lattice comes out at 7.07 RMS held apart and 0.43 bridged - and for
    any cloud whose slice spacing is coarser than the lattice it settled on,
    where consecutive slices are separate pieces and holding them apart leaves
    each one surfaced as its own pancake, at 4.8 vertices per input point
    against the one or two that is normal.

    What this does *not* control is whether a point counts as material, which
    is always true. Tying the two together was a mistake: it made a sparse
    cloud vanish at the very setting meant to make it solid.

    It is a setting rather than something measured because the two cases are
    the same cloud geometrically. Three tests were tried and all three failed
    to separate them; see :func:`sever_invented_bridges`. Only the person who
    made the cloud knows which it is.
    """



    """Morphological closing radius, in source-lattice voxels. This is the knob
    that separates "a sample is missing here" from "there is really nothing
    here". 0 disables it and every sampling hole becomes a cavity."""

    despeckle_min_voxels: int = 8
    """Drop solid blobs smaller than this many source voxels (noise specks)."""

    keep_cavities: bool = True
    """When False, every enclosed void is filled and only the outer skin is
    produced."""

    cavity_min_volume: float = 8.0
    """Smallest enclosed void kept as a real cavity, in cubic scene units (mm
    for DICOM-derived clouds). Smaller voids are treated as sampling noise and
    filled. Raise this if noise pockets are showing up as internal bubbles;
    lower it to catch small voids."""

    max_cavity_fraction: float = 4.0
    """Reject an enclosed void larger than this multiple of the solid volume -
    it means the input was already a hollow shell, so the void is its interior
    rather than a cavity. Kept generous on purpose: a marrow cavity is
    routinely comparable in volume to the bone around it, so a tight value here
    would discard exactly the feature we are trying to keep. A re-shelled cloud
    exceeds 10x. 0 disables the guard."""

    shell_thickness: int = 1
    """Depth of the kept surface band, in source voxels, for point-filtering
    operations. 1 is the strict "not surrounded on all sides" reading."""

    voxel_budget: int = _vg.DEFAULT_VOXEL_BUDGET
    """Hard cap on reconstruction grid size. Factors are scaled down uniformly
    rather than failing, so anisotropy correction degrades in magnitude but is
    never silently dropped."""


    max_vertices: int = 6_000_000
    """Cap on the finished mesh's vertex count. 0 disables it.

    Enforced by *reducing the resolution to fit*, not by refusing the result. A
    check applied at the end of the pipeline is the worst possible place for it:
    the reconstruction, the cavity classification and the isosurface extraction
    have all already run, and the answer is thrown away. Measured on a real
    segmented cloud, that produced 6,270,594 vertices against a 6,000,000
    cap - over by 4.5%, and nothing to show for the whole run.

    The prediction works because surface-nets emits one vertex per boundary
    *cell*, and boundary cells are a surface, so their count scales with the
    square of the resolution factor rather than the cube."""

    min_island_volume: float = 20.0
    """Drop loose surface pieces smaller than this, in cubic scene units.

    Applied to the *finished* field rather than the source occupancy, because
    that is where the specks come from. Blurring and resampling a marginal
    one-voxel-thick structure breaks it apart: measured on a head phantom, a run
    that produced 2 mesh pieces ungated produced 50 once dim material was gated
    down to threads, 44 of them beads too small to be anything - and topology
    enforcement, which slams a vanishing component to full strength, doubled
    that to 103. Speckle removal on the input cannot see any of it, since none
    of it exists yet.

    Sweeping it on that phantom: 0 left 103 pieces (97 of them beads); 20 cubic
    units left 8 pieces and cost 2.9% of the vertices; 50 left 3 and cost 3.6%.
    The specks are a large share of the *pieces* and a negligible share of the
    *geometry*, which is why a conservative default works. The default keeps
    anything at least roughly a 2.7-unit cube, well under any real bone.

    0 disables the filter. Kept cavities are unaffected - a cavity is a hole in
    a component, not a component of its own."""

    diagnostics: bool = True
    """Measure whether the gap-bridging and smoothing settings are destroying
    structure - merging separate bones, or working from a cloud too sparse for
    the interior test - and report it in ``stats["warnings"]``. Costs one extra
    labelling pass when gap bridging is on."""

    def cavity_min_voxels(self, grid: GridSpec) -> int:
        """Convert the physical cavity floor into a voxel count on ``grid``."""
        if not self.keep_cavities:
            # Nothing is ever large enough, so every void gets filled.
            return grid.voxel_count + 1
        volume = max(1e-12, grid.voxel_volume)
        return max(1, int(np.ceil(max(0.0, float(self.cavity_min_volume)) / volume)))

    def effective_shell_thickness(self) -> int:
        """Closing pushes the surface outward, so the kept band widens to match."""
        return max(1, int(self.shell_thickness)) + max(0, int(self.gap_bridge_voxels))


@dataclass
class SolidPrep:
    """The classified occupancy grid, before any resolution change."""

    solid: np.ndarray
    cavity: np.ndarray
    outside: np.ndarray
    value_grid: np.ndarray | None
    density: np.ndarray | None
    bridge_cut: np.ndarray | None
    grid: GridSpec
    stats: dict = dataclass_field(default_factory=dict)


@dataclass
class Occupancy:
    """A built occupancy grid plus the evidence behind it.

    Shared between brightness tiers so they land on one grid: were each tier to
    re-estimate its own spacing, the calibration would settle somewhere
    different for a sparse tier than a dense one and the resulting meshes would
    not line up.
    """

    occupancy: np.ndarray
    value_grid: np.ndarray | None
    counts: np.ndarray
    value_sum: np.ndarray | None
    grid: GridSpec
    spacing: tuple
    stats: dict = dataclass_field(default_factory=dict)


@dataclass
class ShellField:
    """A reconstructed continuous field whose ``ISOVALUE`` level set is the surface."""

    field: np.ndarray
    grid: GridSpec
    intensity: np.ndarray | None
    prep: SolidPrep
    stats: dict = dataclass_field(default_factory=dict)


# --------------------------------------------------------------------------
# Stage 1: occupancy + cavity classification
# --------------------------------------------------------------------------


SPARSE_ISOLATED_FRACTION = 0.15
"""Above this share of standalone voxels, the interior test is unreliable."""


def diagnose(stats: dict, settings: "ShellSettings") -> list:
    """Turn reconstruction measurements into actionable warnings.

    The two ways this pipeline silently produces a smooth blob instead of
    anatomy, both caught here:

    * The cloud was randomly decimated (usually by the import point cap), so
      most voxels stand alone and nothing reads as interior. The fix is more
      points, not more gap bridging - but more gap bridging is the intuitive
      thing to reach for, which leads directly to the second failure.
    * Gap bridging or smoothing is wide enough to weld separate structures
      together. Once two bones share a surface, no later setting recovers them.
    """
    warnings = []

    # A wrong spacing estimate is the most destructive thing that can happen
    # here: it silently rescales the whole reconstruction. Check that the grid
    # can actually resolve the object before anything else.
    extent = stats.get("world_extent")
    spacing = stats.get("source_spacing")
    if extent and spacing:
        longest = max(float(v) for v in extent)
        coarsest = max(float(v) for v in spacing)
        samples = longest / max(1e-9, coarsest)
        if samples < 64.0:
            warnings.append(
                "Sample spacing came out at {:.3f} units for an object {:.0f} units across - "
                "only {:.0f} samples on the longest axis. The reconstruction cannot resolve "
                "anatomy at that scale and will look like a smooth blob. Check the cloud's "
                "scale, or set the spacing manually.".format(coarsest, longest, samples)
            )

    if str(stats.get("spacing_source", "")) == "nearest-neighbour":
        warnings.append(
            "This cloud is not on a regular lattice, so spacing was measured from "
            "nearest-neighbour distance ({:.3f} units). That is an estimate; if the mesh "
            "looks wrong, mesh the original imported cloud rather than one that has been "
            "interpolated or had a transform applied.".format(
                max(float(v) for v in (stats.get("source_spacing") or (1.0,)))
            )
        )

    solidify = int(stats.get("solidify_close_radius", 0) or 0)
    if solidify:
        spacing = stats.get("source_spacing") or (1.0,)
        warnings.append(
            "The cloud does not fill its own lattice - a segmentation output or an "
            "interpolated cloud - so holes up to {:.2f} units across were closed to stop "
            "the interior meshing as a sponge (interior fill is now {:.0%}). Voids "
            "narrower than that are filled; the spacing and all surface detail are "
            "kept.".format(2.0 * solidify * float(min(spacing)),
                           float(stats.get("interior_fill", 0.0)))
        )

    if float(stats.get("spacing_coarsened", 1.0) or 1.0) > 1.02:
        warnings.append(
            "The occupancy grid did not fit the voxel budget, so spacing was coarsened "
            "{:.2f}x. Raise Voxel Budget to reconstruct at the cloud's real spacing.".format(
                float(stats["spacing_coarsened"])
            )
        )

    isolated = float(stats.get("isolated_fraction", 0.0) or 0.0)
    if isolated > SPARSE_ISOLATED_FRACTION:
        warnings.append(
            "Cloud is too sparse for the interior test: {:.0f}% of its voxels have no "
            "neighbour. Re-import with a higher Max Points / Safe Cap or a lower Stride "
            "rather than raising Bridge Sampling Gaps.".format(isolated * 100.0)
        )

    before = int(stats.get("components_before_close", 0) or 0)
    after = int(stats.get("components_after_close", 0) or 0)
    if before and after and after < before:
        radius = int(stats.get("solidify_close_radius", 0) or 0)
        spacing = stats.get("source_spacing") or (1.0,)
        warnings.append(
            "Fill Holes welded {:,d} separate pieces into {:,d}, because filling a hole "
            "and bridging a gap are the same operation - it spans up to {:.2f} units "
            "either way. Lower it if pieces that should be separate are joined by thin "
            "connectors; large pieces standing alone are fine.".format(
                before, after, 2.0 * radius * float(min(spacing))
            )
        )

    sigma_distance = float(stats.get("smoothing_distance", 0.0) or 0.0)
    if float(getattr(settings, "surface_sigma", 0.0)) > 1.0:
        warnings.append(
            "Surface Smoothing is {:.2f} voxels ({:.1f} units); above ~1.0 it rounds "
            "detail away and can close narrow separations.".format(
                float(settings.surface_sigma), sigma_distance
            )
        )

    cap = int(stats.get("max_vertices", 0) or 0)
    if cap and stats.get("vertex_budget_reduced"):
        warnings.append(
            "Resolution was reduced to fit the {:,}-vertex limit; the mesh came out at "
            "{:,}. Raise Max Vertices for more detail, if the memory is there. Note "
            "that running Increase Point Cloud Resolution first cannot help while this "
            "limit binds: it is the limit, not the cloud, that is setting how fine the "
            "mesh can be. Measured on one station, densifying 13.8x changed the mesh by "
            "1.03x under a 6,000,000-vertex limit, and by 2.09x once the limit was "
            "raised.".format(
                cap, int(stats.get("measured_vertices", 0) or 0)
            )
        )

    if stats.get("budget_reduced"):
        warnings.append(
            "Voxel budget forced the resolution down. Raise Voxel Budget to get the "
            "requested detail."
        )

    return warnings


def build_occupancy(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    lattice_spacing=None,
    progress_cb=None,
) -> Occupancy:
    """Snap a cloud onto a calibrated lattice, keeping the per-voxel evidence.

    Split out from :func:`prepare_solid` so that brightness tiers can be
    classified against one shared grid rather than each building its own.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    pts = np.asarray(points, dtype=np.float32)
    if pts.ndim != 2 or pts.shape[1] != 3:
        raise ValueError("points must be an (N, 3) array")
    if pts.shape[0] < 4:
        raise ValueError("need at least 4 points")

    report(2.0, "Estimating source lattice")
    if lattice_spacing is not None:
        spacing, spacing_source = tuple(lattice_spacing), "explicit"
    else:
        spacing, spacing_source = _vg.estimate_lattice_spacing(pts, with_source=True)

    # Margin must clear the closing radius and leave room for the isosurface
    # extractor, which drops faces in the outermost cell layer.
    pad = max(3, int(cfg.gap_bridge_voxels) + 3)

    report(6.0, "Building occupancy grid")
    solidify_stats = {}
    (
        occupancy,
        value_grid,
        grid,
        interior_fill,
        solidify_radius,
        counts,
        value_sum,
    ) = _vg.solid_occupancy_from_points(
        pts,
        spacing,
        pad_voxels=pad,
        values=intensities,
        voxel_budget=cfg.voxel_budget,
        # No morphological closing: the density level set below subsumes it,
        # and doing both meant the density was estimated from an already-filled
        # occupancy, so it chose too narrow a kernel and the surface came back
        # as a sponge.
        close_radius=0,
        with_evidence=True,
        stats=solidify_stats,
    )

    world_extent = tuple(float(v) for v in (pts.max(axis=0) - pts.min(axis=0)))
    stats = {
        "interior_fill": float(interior_fill),
        "solidify_close_radius": int(solidify_radius),
        "components_before_close": int(
            solidify_stats.get("components_before_close", 0) or 0
        ),
        "components_after_close": int(
            solidify_stats.get("components_after_close", 0) or 0
        ),
        "source_spacing": tuple(float(v) for v in grid.spacing),
        "requested_spacing": tuple(float(v) for v in spacing),
        "spacing_source": str(spacing_source),
        "spacing_coarsened": float(grid.coarsened),
        "world_extent": world_extent,
        "source_shape": tuple(int(v) for v in grid.shape),
        "occupied_voxels": int(np.count_nonzero(occupancy)),
        "input_points": int(pts.shape[0]),
    }
    return Occupancy(
        occupancy=occupancy,
        value_grid=value_grid,
        counts=counts,
        value_sum=value_sum,
        grid=grid,
        spacing=tuple(float(v) for v in spacing),
        stats=stats,
    )


TIER_LABELS = {
    2: ("dark", "bright"),
    3: ("dark", "mid", "bright"),
    4: ("dark", "mid", "upper", "bright"),
}

LEVEL_LABELS = {
    2: ("outer", "inner"),
    3: ("outer", "mid", "inner"),
    4: ("outer", "mid", "deep", "inner"),
}
"""Names for nested intensity surfaces. Unlike brightness bands, which
partition the material, these enclose one another: the lowest level is the outer
skin and each higher one sits inside it."""


def merge_warnings(*groups) -> list:
    """Concatenate warning lists in order, dropping repeats.

    ``build_shell_field`` re-runs :func:`diagnose` on its fuller stats, and
    assigning that result straight over ``stats["warnings"]`` silently threw
    away everything recorded by the stages that diagnose cannot re-derive - the
    intensity fallback and the island filter both vanished this way. Merging
    keeps them, and the de-duplication stops the re-run from doubling every
    warning ``prepare_solid`` had already produced.
    """
    merged = []
    seen = set()
    for group in groups:
        for warning in group or []:
            text = str(warning)
            if text not in seen:
                seen.add(text)
                merged.append(text)
    return merged


def diagnose_islands(stats: dict) -> list:
    """Warnings about the loose-piece filter.

    Separate from :func:`diagnose` because the filter runs on the finished
    field, long after ``prepare_solid`` has already produced its diagnostics.
    """
    warnings = []
    dropped = int(stats.get("islands_dropped", 0) or 0)
    if dropped:
        warnings.append(
            "Dropped {:,d} loose piece(s) smaller than {:.1f} cubic units (largest "
            "{:.1f}). Lower Min Island Volume to keep small separate structures.".format(
                dropped,
                float(stats.get("islands_min_volume", 0.0)),
                float(stats.get("islands_largest_dropped", 0.0)),
            )
        )
    # A cloud built from several acquisitions is not on any lattice, and no
    # single spacing describes it. Each station carries its own sub-voxel
    # offset, so the union of their coordinates is dense where each one alone
    # is regular - measured on a whole-body study, 2,853 distinct x values
    # where one station has 253. The estimator then has to pick something, and
    # whatever it picks is wrong for part of the cloud: on that study the slice
    # axis came out at the in-plane spacing, every slice sat alone in its own
    # row, and the body broke into 25,064 islands.
    #
    # This cannot be repaired by estimating better. Measuring each axis on its
    # own terms was tried: it corrected the slice axis from 1.953 to 4.883
    # against a true 5.2, and at the same time halved the in-plane spacing,
    # leaving more islands than before. The cloud does not have one spacing. It
    # has to be reconstructed a station at a time.
    total = int(stats.get("islands_total", 0) or 0)
    if (str(stats.get("spacing_source", "")) in ("mixed", "nearest-neighbour")
            and (total > 200 or dropped > 100)):
        warnings.append(
            "This cloud does not sit on one sampling lattice - it broke into {:,d} "
            "separate pieces and {:,d} were dropped. That is what a cloud assembled "
            "from several scans looks like: each carries its own sub-voxel offset, "
            "so no single spacing fits all of it and the reconstruction cannot join "
            "slices it cannot line up. Convert each scan separately and join the "
            "meshes afterwards - on a whole-body study that took the same material "
            "from 1,389 pieces to under 50 per station, with none dropped.".format(
                total, dropped
            )
        )

    if stats.get("islands_all_below_threshold"):
        warnings.append(
            "Every piece of this mesh is below Min Island Volume, so nothing was "
            "dropped. Lower it, or the whole mesh would have been erased."
        )
    return warnings


def density_sigma_for_fill(fill: float) -> float:
    """Kernel width, in source voxels, for estimating point density.

    A sparser cloud needs a wider kernel, because the density has to be read off
    the points that are actually there. Measured against a sphere of known
    radius, the width that minimised surface error ran from about 1 voxel on a
    full lattice to 2 on a tenth of one - which is what ``fill ** (-1/3)``
    describes, the spacing between points growing as the cube root of how few
    of them there are.
    """
    safe = max(0.02, min(1.0, float(fill)))
    return float(min(3.0, max(0.6, 1.0 / (safe ** (1.0 / 3.0)))))


def density_field(occupancy, sigma, spacing=None):
    """Point density, scaled so the material's edge sits at ``ISOVALUE``.

    Contouring this instead of a morphologically solidified binary mask is what
    removes the boxy artefacts. Morphology works on whole voxels with a
    structuring element that has a shape of its own - a cube, in the shipped
    case, reaching 73% further along its diagonals than its axes - so it prints
    that shape onto the surface, and on a ragged sparse boundary it turns every
    protruding point into a blob. A density level set has neither an element nor
    a voxel edge: it is a smooth scalar whose crossing is interpolated, so the
    surface lands between samples.

    Measured on a sphere reconstructed from a tenth of its lattice, the radial
    error fell from 6.68 RMS (21.1 at worst) to 0.65 (2.4).

    The cost is at the small end. A density estimate is only as sharp as its
    kernel, so a feature narrower than about twice ``sigma`` has a lower peak
    density than the bulk and the level cuts inside it: a two-voxel blob at
    sigma 1 peaks at 0.74 against the bulk's 1.0, and keeps 7 of its 33 voxels.
    Large pieces standing alone are unaffected; specks shrink, which is usually
    what is wanted of a speck.
    """
    from . import resample as _rs

    occupancy = np.asarray(occupancy, dtype=bool)
    # The kernel is a physical distance, so on an anisotropic grid it has to be
    # a different number of voxels per axis. Passing one scalar blurred three
    # times as far along the slice axis of a 0.8 x 0.8 x 2.4 grid, which filled
    # cavities whole.
    if spacing is None:
        sigma_voxels = float(sigma)
    else:
        step = np.asarray([max(1e-9, float(v)) for v in spacing], dtype=np.float64)
        finest = float(step.min())
        # gaussian_blur indexes [z, y, x]; spacing is (x, y, z).
        sigma_voxels = tuple(
            float(sigma) * finest / step[axis] for axis in (2, 1, 0)
        )
    field = _rs.gaussian_blur(occupancy.astype(np.float32), sigma_voxels)
    interior = _vg.binary_erode(occupancy, radius=3, connectivity=6,
                                border_solid=False)
    inside = field[interior] if interior.any() else field[occupancy]
    if inside.size == 0:
        return field, float(ISOVALUE)
    # Half the density found well inside the material - the midpoint between
    # solid and empty, which is where the boundary is.
    level = 0.5 * float(np.median(inside))
    if level <= 1e-6:
        return field, float(ISOVALUE)
    return (field * (ISOVALUE / level)).astype(np.float32), float(ISOVALUE)


def _nearest_upsample_mask(mask: np.ndarray, out_shape) -> np.ndarray:
    """Nearest-neighbour resampling of a boolean mask onto ``out_shape``.

    Nearest neighbour rather than anything interpolating, because the mask says
    which voxels must be empty; a value blended halfway back towards solid is
    exactly the failure this repairs.
    """
    mask = np.asarray(mask, dtype=bool)
    if tuple(mask.shape) == tuple(out_shape):
        return mask
    picks = []
    for axis in range(3):
        n_out = int(out_shape[axis])
        n_in = int(mask.shape[axis])
        idx = (np.arange(n_out, dtype=np.float64) + 0.5) * n_in / max(1, n_out)
        picks.append(np.clip(idx.astype(np.int64), 0, n_in - 1))
    return mask[np.ix_(picks[0], picks[1], picks[2])]


def sever_invented_bridges(density, source_occupancy, isovalue=None,
                           reach_voxels=3):
    """Stop the density kernel from fusing pieces the source keeps apart.

    The kernel has to be wide enough to give a smooth level set - a narrow one
    puts the voxel faceting straight back, measured at 24% of faces lying flat
    on a coordinate plane against 7% at sigma 1.6. But a wide kernel also lets
    two nearby pieces pool their density in the gap between them and emerge as
    one lump. On a segmented band of a real lumbar scan that turned 1,194
    separate flecks into 259.

    Those are not competing requirements, because they concern different
    voxels. Smoothness is about the field *at* the material; fusing happens in
    the empty space *between* two pieces. So the kernel stays wide, and the
    watershed line between two source components is cut - but only through
    voxels that hold no points of their own. Real material is never removed;
    only an invented bridge is. On that band this restores all 1,194 pieces
    while keeping 48,396 voxels against the source's 28,713, so the result is
    genuinely denser rather than the source handed back.

    Three cheaper tests for "is this cloud genuinely scattered or merely
    under-sampled" were tried first and all three failed: the interior fill
    fraction (a segmented band and an under-sampled solid both read 23%), the
    index of dispersion (confounded by the object's own boundary - a fully
    solid sphere scores 41.7), and a randomisation null reshuffling the cloud
    inside its own hull (the band scored 1.15, the under-sampled sphere 1.12).
    The information is not in the cloud's geometry. This function never needs
    it: it does not decide which case it is in, it only preserves separations
    the source already has.
    """
    level = float(ISOVALUE if isovalue is None else isovalue)
    source_occupancy = np.asarray(source_occupancy, dtype=bool)
    density = np.asarray(density)
    grown = density >= level
    if not (grown & ~source_occupancy).any():
        return density, None

    labels, sizes = _vg.label_regions(source_occupancy, connectivity=26)
    if sizes.size <= 2:          # background plus at most one piece
        return density, None

    # Labels are propagated through the empty space around the material, not
    # only through what is already solid. Drawing the watershed only inside the
    # solid leaves the gap between two pieces unlabelled and therefore uncut -
    # and that gap is exactly where the later blur and resampling filter lift
    # the midpoint above the level and build the bridge. Cutting empty space
    # removes nothing; it keeps it empty through the smoothing that follows.
    reach = _vg.binary_dilate(grown | source_occupancy, radius=reach_voxels,
                              connectivity=26)
    filled = _vg.propagate_labels(labels, reach, connectivity=6)

    # The watershed has to block every direction the component counter walks.
    # Testing face neighbours only leaves the two sides touching diagonally,
    # which left 375 of 1,194 pieces standing instead of all of them.
    boundary = np.zeros(filled.shape, dtype=bool)
    for dz in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dz == 0 and dy == 0 and dx == 0:
                    continue
                src = [slice(None)] * 3
                dst = [slice(None)] * 3
                for axis, delta in enumerate((dz, dy, dx)):
                    n = filled.shape[axis]
                    if delta > 0:
                        src[axis] = slice(0, n - delta)
                        dst[axis] = slice(delta, n)
                    elif delta < 0:
                        src[axis] = slice(-delta, n)
                        dst[axis] = slice(0, n + delta)
                here = filled[tuple(src)]
                there = filled[tuple(dst)]
                differ = (here != there) & (here > 0) & (there > 0)
                if not differ.any():
                    continue
                boundary[tuple(src)] |= differ
                boundary[tuple(dst)] |= differ

    # Widened by one voxel before the source is excluded. A one-voxel trench
    # is not enough on its own: the surface blur that runs later lifts the
    # voxels flanking it back above the level, and the bridge simply steps
    # around the cut. Widening it left 161 pieces standing; this closes it.
    boundary = _vg.binary_dilate(boundary, radius=1, connectivity=26)
    cut = boundary & ~source_occupancy
    if not cut.any():
        return density, None
    density = np.array(density, dtype=np.float32, copy=True)
    # Zero, not a hair under the level. The field is resampled to a finer grid
    # with a smoothing filter before it is contoured, and a cut that only just
    # clears the level is interpolated straight back.
    density[cut] = 0.0
    return density, cut


def prepare_solid(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    lattice_spacing=None,
    progress_cb=None,
    shared: Occupancy | None = None,
) -> SolidPrep:
    """Snap a cloud to its lattice and classify air, cavities and noise.

    Args:
        points: ``(N, 3)`` world XYZ.
        intensities: Optional per-point scalar, carried through for colouring.
        settings: See :class:`ShellSettings`.
        lattice_spacing: Override the auto-detected source spacing.
        progress_cb: ``callable(percent, message)``.
        shared: A grid already built by :func:`build_occupancy`, to classify a
            second band against without rebuilding it.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    if shared is None:
        shared = build_occupancy(
            points,
            intensities=intensities,
            settings=cfg,
            lattice_spacing=lattice_spacing,
            progress_cb=report,
        )

    occupancy = shared.occupancy
    value_grid = shared.value_grid
    counts = shared.counts
    value_sum = shared.value_sum
    grid = shared.grid
    spacing = shared.spacing
    stats = dict(shared.stats)

    report(12.0, "Estimating point density")
    # "Fill Holes" widens the density kernel instead of running a
    # morphological close. It reaches about as far - a Gaussian at sigma s
    # bridges a gap of roughly 2s, as a close of radius r bridges 2r - but it
    # has no structuring element, so it cannot print one onto the surface.
    # That is what the boxy lumps were: a cube reaching 3.46 voxels diagonally
    # against 2 axially, stamped over every protruding point.
    sigma_density = density_sigma_for_fill(
        float(stats.get("interior_fill", 1.0) or 1.0)
    )
    sigma_density = min(6.0, sigma_density + 0.9 * max(0, int(cfg.gap_bridge_voxels)))
    density, _level = density_field(occupancy, sigma_density, grid.spacing)
    stats["density_sigma"] = float(sigma_density)
    # A voxel holding points is material. The density level is calibrated to
    # the bulk interior, so it cuts inside anything narrower than the kernel
    # and dropped 5,470 of this band's 28,713 occupied voxels - deleting the
    # smallest flecks outright. Whether a small piece is worth keeping is the
    # island and speckle filters' decision, made on size, not a side effect of
    # how the level happened to be calibrated.
    density = np.asarray(density, dtype=np.float32)
    if bool(cfg.trust_points):
        # A voxel holding points is material, full stop - always, not only at
        # some Fill Holes setting. This was briefly tied to that switch on the
        # theory that it was what cost an under-sampled solid its smoothness.
        # It is not: measured across both phantoms, turning it off moved a
        # sparse sphere from 7.069 RMS to 7.186 and from 0.536 to 0.550, which
        # is noise, while on a real segmented cloud it deleted most of the
        # material. Severing is what that switch actually needs to control. Without this the level - calibrated to the bulk
        # interior - cuts inside anything narrower than the kernel and deletes
        # the smallest flecks outright, 5,470 of one band's 28,713 voxels.
        #
        # It is tied to Fill Holes because the alternative cannot be inferred.
        # A segmented intensity band and an under-sampled solid are the same
        # cloud geometrically - three separate tests failed to tell them apart,
        # see sever_invented_bridges - and they want opposite answers: the band
        # wants its flecks kept, the under-sampled solid wants them smoothed
        # into a body. Forcing the points on costs the second case dearly (a
        # sphere from a tenth of its lattice went from 0.65 RMS to 7.51), so
        # the user says which they have, and raising Fill Holes says "the gaps
        # are missing samples, not structure".
        density[occupancy] = 1.0
    # Severing answers the same question as the clamp above and follows the
    # same switch. Keeping pieces apart is right when the gaps are real; on a
    # genuinely under-sampled solid it is actively wrong, because there every
    # gap is a missing sample and refusing to bridge them leaves the sponge
    # the density estimate exists to remove (a sphere from a tenth of its
    # lattice: 0.65 RMS bridging freely, 5.96 with the pieces held apart).
    # Severing keeps apart whatever the source occupancy keeps apart - which
    # is right when the gaps are real, and exactly wrong when they are missing
    # samples, because then consecutive slices are separate components and
    # holding them apart is what leaves each one surfaced as its own pancake.
    # It is the behaviour Fill Holes has to govern.
    if bool(cfg.cover_points):
        # Every point becomes a ball, and the balls are unioned by being
        # written into one field rather than placed as overlapping geometry -
        # so there is no interior surface to remesh away afterwards.
        radius = max(1, int(math.ceil(float(cfg.cover_radius))))
        occupancy = _vg.ball_dilate(occupancy, radius)
        density = np.asarray(density, dtype=np.float32)
        density[occupancy] = 1.0
        stats["cover_radius_voxels"] = int(radius)

    if bool(cfg.sever_bridges) and int(cfg.gap_bridge_voxels) <= 0:
        density, bridge_cut = sever_invented_bridges(density, occupancy)
    else:
        bridge_cut = None
    stats["severed_bridge_voxels"] = (
        0 if bridge_cut is None else int(np.count_nonzero(bridge_cut))
    )
    # The solid mask now comes from the density crossing rather than from
    # morphology, so it inherits the same smooth, interpolated boundary.
    occupancy = density >= ISOVALUE
    stats["occupied_voxels"] = int(np.count_nonzero(occupancy))
    # The gate is off whenever an intensity level set is doing the deciding.
    # Two mechanisms choosing what counts as material is one too many: on a real
    # lumbar series the gate removed 5,026,078 voxels - 55% of everything it
    # judged faint - before the level had even been applied, and the level would
    # then have made its own, better-founded decision about the same voxels.
    # In tiered mode ``detail_threshold`` is additionally the band edge, so
    # letting it gate as well would be one number doing two jobs at once.
    if int(cfg.despeckle_min_voxels) > 1 and not bool(cfg.cover_points):
        report(18.0, "Removing isolated speckle")
        cleaned = _vg.remove_small_components(occupancy, int(cfg.despeckle_min_voxels), connectivity=26)
        stats["despeckled_voxels"] = int(np.count_nonzero(occupancy) - np.count_nonzero(cleaned))
        occupancy = cleaned


    # Sparsity is measured before any closing, while the occupancy still
    # reflects what the cloud actually contains.
    if cfg.diagnostics:
        stats["isolated_fraction"] = _vg.isolated_fraction(occupancy, connectivity=6)

    # There is no second closing here. Filling holes and bridging gaps are the
    # same operation, so running it twice - once to solidify the interior and
    # again to bridge sampling gaps - closed gaps up to the *sum* of the two
    # radii. At the shipped defaults that was 6 voxels, which welded separate
    # structures together with thin connectors and made every feature look
    # three voxels coarser than the points it came from.

    report(45.0, "Separating air from cavities")
    classified = _vg.classify_cavities(
        occupancy,
        min_cavity_voxels=cfg.cavity_min_voxels(grid),
        connectivity=6,
        max_cavity_fraction=float(cfg.max_cavity_fraction),
    )

    solid_mask = classified.solid
    if bridge_cut is not None:
        # Cavity classification fills any void air cannot reach, and a severed
        # bridge is exactly that shape: a thin trench between two pieces, too
        # narrow for a 6-connected flood to pass. Left alone it read as an
        # enclosed cavity and was filled straight back in, which put 1,194
        # pieces back down to 248. A cut bridge is not a cavity and is never
        # material.
        solid_mask = solid_mask & ~bridge_cut

    voxel_volume = grid.voxel_volume
    stats.update(
        {
            "solid_voxels": int(np.count_nonzero(solid_mask)),
            "cavity_count": len(classified.cavity_sizes),
            "cavity_voxels": int(np.count_nonzero(classified.cavity)),
            "cavity_volumes": [float(n) * voxel_volume for n in classified.cavity_sizes],
            "noise_pockets_filled": int(classified.filled_voxels),
            "cavities_rejected": int(classified.discarded_cavities),
            "cavity_min_voxels": int(cfg.cavity_min_voxels(grid)),
        }
    )

    # One vertex per boundary cell is what the extractor emits, so this is the
    # basis for predicting the finished vertex count before paying for it.
    stats["source_surface_voxels"] = int(
        np.count_nonzero(_vg.boundary_mask(solid_mask, connectivity=6))
    )

    stats["smoothing_distance"] = float(cfg.surface_sigma) * float(min(spacing))
    stats["warnings"] = diagnose(stats, cfg)

    report(60.0, "Occupancy classified")
    return SolidPrep(
        density=density,
        bridge_cut=bridge_cut,
        solid=solid_mask,
        cavity=classified.cavity,
        outside=classified.outside,
        value_grid=value_grid,
        grid=grid,
        stats=stats,
    )


# --------------------------------------------------------------------------
# Stage 2: resolution enhancement
# --------------------------------------------------------------------------


WORKING_ARRAYS_OCCUPANCY = 3
"""Same-size arrays live at peak when contouring occupancy."""


def plan_resolution(grid: GridSpec, settings: ShellSettings):
    """Work out the reconstruction factors and resulting grid size.

    Returns ``(factors, out_shape, reduced)``. ``reduced`` is True when the
    voxel budget forced the multiplier down. Cheap enough to call from UI code
    to show the user what a setting will cost.
    """
    multiplier = max(0.05, float(settings.resolution_multiplier))
    if settings.isotropic:
        factors, _target = _resample.isotropic_factors(grid.spacing, extra=multiplier)
    else:
        factors = (multiplier, multiplier, multiplier)

    # The budget is expressed in voxels, but what actually runs out is memory,
    # and the two modes hold a different number of same-size arrays. Counting
    # voxels alone let a grid that occupancy mode handled in 4.1 GB be accepted
    # for intensity mode, which needed 9.6 GB of it and ran out - the setting
    # passed its own check and then failed. So the budget is scaled by how many
    # arrays the mode really needs.
    factors, reduced = _resample.budget_limited_factors(
        grid.shape, factors, int(settings.voxel_budget)
    )

    out_shape = _resample.target_shape_for_factors(grid.shape, factors)
    return factors, out_shape, reduced


def count_surface_cells(field: np.ndarray, isovalue: float = None) -> int:
    """Exactly how many vertices the extractor will emit from ``field``.

    Surface-nets places one vertex per *cell* whose eight corner samples are not
    all on the same side of the level, so this mirrors that test rather than
    approximating it. Two cheaper versions were measured and both undercounted
    on real data: a source-grid estimate scaled by area came out 35% low
    (3,753,253 against 5,802,863), and a six-face neighbour test on the fine
    grid came out 33% low (2,817,445 against 4,215,168) because it misses cells
    that only a diagonal corner crosses - which on a rough surface is a third of
    them.
    """
    level = ISOVALUE if isovalue is None else float(isovalue)
    above = field >= level
    if above.shape[0] < 2 or above.shape[1] < 2 or above.shape[2] < 2:
        return 0
    corner_sum = (
        above[:-1, :-1, :-1].astype(np.uint8)
        + above[1:, :-1, :-1]
        + above[:-1, 1:, :-1]
        + above[1:, 1:, :-1]
        + above[:-1, :-1, 1:]
        + above[1:, :-1, 1:]
        + above[:-1, 1:, 1:]
        + above[1:, 1:, 1:]
    )
    return int(np.count_nonzero((corner_sum > 0) & (corner_sum < 8)))


def build_shell_field(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    lattice_spacing=None,
    prep: SolidPrep | None = None,
    progress_cb=None,
    need_intensity: bool = True,
) -> ShellField:
    """Reconstruct a continuous surface field at enhanced resolution.

    The occupancy indicator (1 inside, 0 outside, 0 in kept cavities) is blurred
    slightly, then resampled onto the finer lattice with an interpolating
    filter. Its ``ISOVALUE`` level set is the surface.

    A companion intensity field is produced by normalised convolution - the
    blurred intensity-times-coverage divided by the blurred coverage - so
    sampling it near the boundary is not dragged toward zero by empty voxels.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    if prep is None:
        prep = prepare_solid(
            points,
            intensities=intensities,
            settings=cfg,
            lattice_spacing=lattice_spacing,
            progress_cb=lambda p, m="": report(p * 0.6, m),
        )

    factors, out_shape, reduced = plan_resolution(prep.grid, cfg)

    report(62.0, "Smoothing occupancy indicator")
    # The density field already is a smooth scalar whose crossing sits at
    # ISOVALUE, so it is contoured directly. The binary fallback is only for a
    # prep built by hand, as some tests do.
    if getattr(prep, "density", None) is not None:
        indicator = np.array(prep.density, dtype=np.float32, copy=True)
        # Where the two disagree, the mask wins - in both directions. They only
        # disagree where a later step edited the mask: filling a cavity,
        # dropping a speck, removing an island. Clamping one way only left the
        # filled cavity still reading as empty density, so keep_cavities=False
        # kept emitting the inner surface it had just been told to remove.
        # Fully 0 and 1, not a hair either side of the level. The field is
        # blurred and then resampled before it is contoured, and a marginal
        # value does not survive being interpolated against its neighbours: at
        # ISOVALUE * 1.01 only 91 of a band's 1,194 pieces still had any
        # material left on the fine grid. The rest dissolved, which is what
        # made a segmented cloud upsample into a handful of lumps.
        indicator[~prep.solid & (indicator >= ISOVALUE)] = 0.0
        indicator[prep.solid & (indicator < ISOVALUE)] = 1.0
    else:
        indicator = prep.solid.astype(np.float32)
    sigma = max(0.0, float(cfg.surface_sigma))
    if sigma >= 0.05:
        indicator = _resample.gaussian_blur(indicator, sigma)

        # Topology enforcement used to sit here: after blurring, any solid
        # component whose every voxel had fallen below the isovalue was slammed
        # back to 1.0, and any cavity whose every voxel had risen above it was
        # slammed to 0.0. It was removed because the density level set made it
        # unreachable. Materiality is now decided before the blur - a component
        # exists in prep.solid only if its density already cleared the level -
        # and a level crossing in a smooth field does not evaporate under a
        # 0.6-voxel blur. Measured across a single point, a 7-point and a
        # 19-point speck, a one-voxel-thick fin, a one-voxel void and a thin
        # slot, it fired on nothing and changed no vertex either way.
        #
        # What it protected against is still real, but it now happens earlier
        # and cannot be undone here: a feature narrower than about twice the
        # density kernel never reaches the level in the first place. That is
        # documented on density_field, and the remedy is a finer kernel, not a
        # rescue after the fact.

    # Carrying intensity through costs a blur and two full-size resamples of
    # the reconstruction grid - 10% of a mesh conversion measured on a real
    # station - and only upsample_pointcloud ever reads the result. Meshing
    # builds a hull and never looks at it.
    intensity_coarse = None
    intensity_coverage = None
    if need_intensity and prep.value_grid is not None:
        coverage = prep.solid.astype(np.float32)
        weighted = prep.value_grid.astype(np.float32) * coverage
        if sigma >= 0.05:
            weighted = _resample.gaussian_blur(weighted, sigma)
        intensity_coarse = weighted

    vertex_cap = int(getattr(cfg, "max_vertices", 0) or 0)
    vertex_limited = False
    measured_vertices = 0
    for attempt in range(4):
        report(70.0, f"Resampling to {out_shape[2]}x{out_shape[1]}x{out_shape[0]}")
        fine = _resample.resample_volume(
            indicator,
            out_shape=out_shape,
            method=str(cfg.filter_method),
            clamp=bool(cfg.clamp_overshoot),
            voxel_budget=int(cfg.voxel_budget),
        )
        # The cut is reapplied here, on the grid that is contoured. Making it
        # once on the source grid is not enough: the surface blur and then the
        # resampling filter both interpolate across a one-voxel trench and put
        # the bridge back, which left 84 of 1,194 pieces standing.
        cut_mask = getattr(prep, "bridge_cut", None)
        if cut_mask is not None:
            fine[_nearest_upsample_mask(cut_mask, fine.shape)] = 0.0

        measured_vertices = (
            count_surface_cells(fine) if vertex_cap > 0 else 0
        )
        if vertex_cap <= 0 or measured_vertices <= vertex_cap:
            break
        # Vertices live on a surface, so they scale with the square of the
        # factor. Aim slightly under the cap so rounding to whole samples does
        # not land back above it.
        shrink = max(0.4, min(0.95, 0.97 * (vertex_cap / measured_vertices) ** 0.5))
        factors = tuple(max(0.05, f * shrink) for f in factors)
        next_shape = _resample.target_shape_for_factors(prep.grid.shape, factors)
        if next_shape == out_shape:
            break
        out_shape = next_shape
        vertex_limited = True

    # Use the shape actually produced, so world alignment is exact even when
    # rounding moved the sample count.
    actual = (
        fine.shape[2] / float(prep.grid.shape[2]),
        fine.shape[1] / float(prep.grid.shape[1]),
        fine.shape[0] / float(prep.grid.shape[0]),
    )
    fine_grid = prep.grid.rescaled(actual, fine.shape)

    intensity_fine = None
    if intensity_coarse is not None:
        report(84.0, "Resampling intensity")
        numerator = _resample.resample_volume(
            intensity_coarse,
            out_shape=out_shape,
            method=str(cfg.filter_method),
            clamp=bool(cfg.clamp_overshoot),
        )
        # Normalised convolution: divide by coverage so boundary samples are not
        # biased toward zero by the empty voxels in their support.
        if intensity_coverage is not None:
            denominator = _resample.resample_volume(
                intensity_coverage,
                out_shape=out_shape,
                method=str(cfg.filter_method),
                clamp=bool(cfg.clamp_overshoot),
            )
        else:
            denominator = fine
        # Divided into the numerator's own buffer. ``out=np.zeros_like(...)``
        # allocated a further array the size of the reconstruction grid, which
        # at a high multiplier is over a gigabyte for nothing.
        np.divide(numerator, denominator, out=numerator, where=denominator > 1e-3)
        numerator[denominator <= 1e-3] = 0.0
        intensity_fine = numerator
        np.clip(intensity_fine, 0.0, 1.0, out=intensity_fine)
        del denominator

    stats = dict(prep.stats)
    stats.update(
        {
            "factors": tuple(float(v) for v in actual),
            "fine_shape": tuple(int(v) for v in fine.shape),
            "fine_spacing": tuple(float(v) for v in fine_grid.spacing),
            "fine_voxels": int(fine.size),
            "budget_reduced": bool(reduced),
            "max_vertices": vertex_cap,
            "measured_vertices": int(measured_vertices),
            "vertex_budget_reduced": bool(vertex_limited),
            "working_arrays": WORKING_ARRAYS_OCCUPANCY,
            "estimated_peak_gb": float(
                fine.size * 4 * WORKING_ARRAYS_OCCUPANCY / (1024.0 ** 3)
            ),
            "filter": str(cfg.filter_method),
        }
    )
    # Re-run now that budget_reduced is known, so its warning is included.
    stats["warnings"] = merge_warnings(stats.get("warnings"), diagnose(stats, cfg))

    report(92.0, "Field ready")
    if float(cfg.min_island_volume) > 0.0 and not bool(cfg.cover_points):
        report(88.0, "Dropping loose specks")
        fine, island_stats = _drop_small_islands(
            fine, fine_grid, float(cfg.min_island_volume)
        )
        stats.update(island_stats)
        # diagnose() has already run inside prepare_solid, before any of this
        # was measured, so these warnings are appended here rather than there.
        stats["warnings"] = merge_warnings(stats.get("warnings"), diagnose_islands({**stats, **island_stats}))

    return ShellField(field=fine, grid=fine_grid, intensity=intensity_fine, prep=prep, stats=stats)


INTENSITY_SCAN_LEVELS = (
    0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50, 0.60, 0.70, 0.80,
)
"""Candidate levels for the automatic scan, weighted toward the low end.

Dark-seam separation happens there - the useful range on a soft-tissue scan is
compressed into the first fifth of the intensity range, while the bright end is
sparse and only matters for dense material like enamel.
"""


SCAN_STRIDE_VOXEL_LIMIT = 16_000_000
"""Above this many source voxels the scan subsamples, accepting some error."""


def _drop_small_islands(field: np.ndarray, grid: GridSpec, min_volume: float):
    """Erase connected pieces of ``field >= ISOVALUE`` below ``min_volume``.

    Works on the field rather than the extracted mesh: the voxel labelling is
    already written and linear in the grid, whereas a mesh-graph pass would mean
    a Python union-find over every face.
    """
    solid = field >= ISOVALUE
    if not solid.any():
        return field, {}

    labels, sizes = _vg.label_regions(solid, connectivity=26)
    if sizes.size <= 2:
        # One component (plus the implicit background label) - nothing loose.
        return field, {"islands_total": max(0, int(sizes.size) - 1), "islands_dropped": 0}

    voxel_volume = max(1e-12, grid.voxel_volume)
    volumes = sizes.astype(np.float64) * voxel_volume
    doomed = volumes < float(min_volume)
    doomed[0] = False  # label 0 is background

    keep_count = int(np.count_nonzero(~doomed)) - 1
    if not np.any(doomed) or keep_count <= 0:
        # Refuse to erase everything: if every piece is under the threshold the
        # threshold is wrong for this cloud, and returning an empty mesh would
        # look like a crash rather than a setting to turn down.
        return field, {
            "islands_total": int(sizes.size) - 1,
            "islands_dropped": 0,
            "islands_all_below_threshold": bool(np.any(doomed) and keep_count <= 0),
        }

    # ``doomed[0]`` is False, so a doomed label already implies a solid voxel -
    # the extra ``solid &`` was a second full pass over the reconstruction grid
    # for nothing. Written in place as well: ``field`` is the caller's own
    # working buffer, and copying it allocated another 380MB at this size.
    lost = doomed[labels]
    out = field
    out[lost] = min(0.0, ISOVALUE - 1.0)
    return out, {
        "islands_total": int(sizes.size) - 1,
        "islands_dropped": int(np.count_nonzero(doomed)),
        "islands_dropped_voxels": int(np.count_nonzero(lost)),
        "islands_min_volume": float(min_volume),
        "islands_largest_dropped": float(volumes[doomed].max()) if np.any(doomed) else 0.0,
    }


# --------------------------------------------------------------------------
# Stage 3: outputs
# --------------------------------------------------------------------------


def shell_mesh_from_field(shell: ShellField, progress_cb=None):
    """Extract the outside-only mesh from a reconstructed field.

    Returns ``(vertices, faces, stats)``. Vertices are world-space float32.
    """
    report = progress_cb or _noop_progress
    report(0.0, "Extracting surface")

    verts, faces = extract_isosurface(
        shell.field,
        isovalue=ISOVALUE,
        spacing=shell.grid.spacing,
        origin=shell.grid.origin,
        progress_cb=lambda p: report(float(p), "Extracting surface"),
    )

    stats = dict(shell.stats)
    stats.update({"vertices": int(len(verts)), "faces": int(len(faces))})
    return verts, faces, stats


def pointcloud_to_shell_mesh(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    progress_cb=None,
):
    """Point cloud -> outside-only mesh, at enhanced resolution.

    Returns ``(vertices, faces, stats)``.
    """
    report = progress_cb or _noop_progress
    shell = build_shell_field(
        points,
        intensities=intensities,
        settings=settings,
        progress_cb=lambda p, m="": report(p * 0.9, m),
        need_intensity=False,
    )
    verts, faces, stats = shell_mesh_from_field(
        shell,
        progress_cb=lambda p, m="": report(90.0 + p * 0.1, m),
    )
    report(100.0, "Mesh ready")
    # One surface per slice is a silent failure, and this is what it looks
    # like from outside: a reconstruction normally emits one or two vertices
    # per input point, because the points on the inside do not get a surface.
    # When the slice spacing is coarser than the lattice the reconstruction
    # settled on, the slices never join and every one of them is contoured
    # separately, top and bottom - measured at 12.3 vertices per point against
    # 1.5 for the same phantom sampled regularly. The mesh looks striped, and
    # the vertex budget is spent on the stripes.
    point_count = int(np.asarray(points).shape[0])
    if point_count and len(verts):
        per_point = float(len(verts)) / float(point_count)
        stats["vertices_per_point"] = per_point
        if per_point > 4.0:
            stats["warnings"] = merge_warnings(
                stats.get("warnings"),
                [
                    "This mesh has {:.1f} vertices per input point, where one or "
                    "two is normal. That means the slices are being surfaced "
                    "separately instead of joining into a solid - the usual cause "
                    "is a cloud whose slice spacing is coarser than the rest of "
                    "it, such as several stations of differing resolution in one "
                    "object. Raise Fill Holes to 1 or 2 to bridge between slices, "
                    "or reconstruct the stations separately.".format(per_point)
                ],
            )

    return verts, faces, stats


def select_surface_points(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    progress_cb=None,
):
    """Indices of the input points that are not surrounded on all sides.

    Interior points - the ones packed together as bulk density - are dropped.
    Points lining a kept cavity are retained, because a cavity wall is an
    exposed surface.

    Returns ``(keep_indices, stats)``.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    prep = prepare_solid(
        points,
        intensities=intensities,
        settings=cfg,
        progress_cb=lambda p, m="": report(p * 0.85, m),
    )

    report(88.0, "Marking exposed voxels")
    thickness = cfg.effective_shell_thickness()
    band = _vg.shell_mask(prep.solid, thickness=thickness, connectivity=6)

    report(94.0, "Filtering points")
    idx = _vg.world_to_voxel_index(np.asarray(points, dtype=np.float32), prep.grid)
    keep = band[idx[:, 0], idx[:, 1], idx[:, 2]]
    keep_indices = np.flatnonzero(keep).astype(np.int64)

    stats = dict(prep.stats)
    stats.update(
        {
            "shell_thickness": int(thickness),
            "kept_points": int(keep_indices.size),
            "removed_points": int(len(points) - keep_indices.size),
        }
    )
    report(100.0, "Surface points selected")
    return keep_indices, stats


def upsample_pointcloud(
    points: np.ndarray,
    intensities: np.ndarray | None = None,
    settings: ShellSettings | None = None,
    mode: str = "SHELL",
    max_points: int = 0,
    progress_cb=None,
):
    """Produce a denser point cloud than the source scan supports.

    ``mode="SHELL"`` emits the reconstructed isosurface vertices. These sit on
    interpolated field crossings, so they are sub-voxel accurate and lie exactly
    on the surface - a better sampling of the anatomy than any subdivision of
    the original lattice points, and the right input for a subsequent meshing
    pass.

    ``mode="SOLID"`` emits the centres of every fine voxel inside the surface,
    for a volumetric cloud.

    Args:
        max_points: Optional cap; the cloud is uniformly decimated if exceeded.

    Returns ``(points, intensities, stats)``.
    """
    if mode not in UPSAMPLE_MODES:
        raise ValueError(f"mode must be one of {UPSAMPLE_MODES}")

    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    shell = build_shell_field(
        points,
        intensities=intensities,
        settings=cfg,
        progress_cb=lambda p, m="": report(p * 0.85, m),
    )

    if mode == "SHELL":
        report(88.0, "Sampling reconstructed surface")
        new_points, _faces = extract_isosurface(
            shell.field,
            isovalue=ISOVALUE,
            spacing=shell.grid.spacing,
            origin=shell.grid.origin,
        )
        new_points = np.asarray(new_points, dtype=np.float32)
    else:
        report(88.0, "Collecting interior voxels")
        inside = np.argwhere(shell.field >= ISOVALUE)
        new_points = shell.grid.voxel_centers_world(inside)

    if new_points.shape[0] == 0:
        raise ValueError("reconstruction produced no points; lower the cavity or despeckle thresholds")

    if max_points and new_points.shape[0] > int(max_points):
        rng = np.random.default_rng(42)
        keep = rng.choice(new_points.shape[0], size=int(max_points), replace=False)
        keep.sort()
        new_points = new_points[keep]

    report(96.0, "Transferring intensity")
    if shell.intensity is not None:
        new_values = _vg.sample_trilinear(shell.intensity, new_points, shell.grid)
    else:
        new_values = np.ones(new_points.shape[0], dtype=np.float32)

    stats = dict(shell.stats)
    stats.update(
        {
            "output_points": int(new_points.shape[0]),
            "upsample_mode": str(mode),
            "density_gain": float(new_points.shape[0]) / max(1.0, float(len(points))),
        }
    )
    report(100.0, "Upsample complete")
    # Trilinear sampling of a resampled grid can land a hair outside the source
    # range - 1.0000001 for a value that was 1.0 - and anything reading these as
    # normalised intensities is entitled to assume they are.
    new_values = np.clip(new_values, 0.0, 1.0)
    return new_points, new_values.astype(np.float32), stats


# --------------------------------------------------------------------------
# Volume path - highest accuracy, used at import time
# --------------------------------------------------------------------------


def enhance_volume(
    volume: np.ndarray,
    spacing,
    settings: ShellSettings | None = None,
    origin=(0.0, 0.0, 0.0),
    progress_cb=None,
):
    """Resample a DICOM volume onto a finer, optionally isotropic lattice.

    This is the most accurate way to gain resolution, because it interpolates
    the measured intensity field: partial-volume effects mean a voxel sitting
    halfway across the bone boundary really does read halfway between bone and
    soft-tissue values, so an interpolating filter recovers where the boundary
    is rather than guessing. Do this before thresholding, not after.

    Returns ``(volume, grid, stats)``. The returned :class:`GridSpec` carries
    both the new spacing and the *shifted origin* - resampling moves cell
    centres, so reusing the source origin with the new spacing would offset the
    result by up to half a source voxel per axis.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")

    grid = GridSpec(
        origin=tuple(float(v) for v in origin),
        spacing=tuple(float(v) for v in spacing),
        shape=tuple(int(v) for v in vol.shape),
    )
    _factors, out_shape, reduced = plan_resolution(grid, cfg)

    if out_shape == tuple(int(v) for v in vol.shape):
        return vol, grid, {"resampled": False, "filter": str(cfg.filter_method)}

    report(10.0, f"Resampling volume to {out_shape[2]}x{out_shape[1]}x{out_shape[0]}")
    fine = _resample.resample_volume(
        vol,
        out_shape=out_shape,
        method=str(cfg.filter_method),
        clamp=bool(cfg.clamp_overshoot),
        voxel_budget=int(cfg.voxel_budget),
    )

    achieved = (
        fine.shape[2] / float(vol.shape[2]),
        fine.shape[1] / float(vol.shape[1]),
        fine.shape[0] / float(vol.shape[0]),
    )
    fine_grid = grid.rescaled(achieved, fine.shape)

    stats = {
        "resampled": True,
        "source_shape": tuple(int(v) for v in vol.shape),
        "fine_shape": tuple(int(v) for v in fine.shape),
        "source_spacing": tuple(float(v) for v in grid.spacing),
        "fine_spacing": tuple(float(v) for v in fine_grid.spacing),
        "budget_reduced": bool(reduced),
        "filter": str(cfg.filter_method),
    }
    report(100.0, "Volume resampled")
    return fine, fine_grid, stats


def volume_to_shell_mesh(
    volume: np.ndarray,
    spacing,
    isovalue: float,
    origin=(0.0, 0.0, 0.0),
    settings: ShellSettings | None = None,
    progress_cb=None,
):
    """Volume -> outside-only mesh with cavity handling, at enhanced resolution.

    The intensity field itself is contoured, so surface placement uses the
    measured gradient. Cavity triage is applied by overwriting only the voxels
    whose classification we are overriding - noise pockets are pushed above the
    isovalue so they stop producing a surface, speckle is pushed below it -
    which leaves intensity-driven accuracy intact everywhere else.

    Returns ``(vertices, faces, stats)``.
    """
    cfg = settings or ShellSettings()
    report = progress_cb or _noop_progress

    fine, grid, resample_stats = enhance_volume(
        volume,
        spacing,
        settings=cfg,
        origin=origin,
        progress_cb=lambda p, m="": report(p * 0.4, m),
    )

    iso = float(isovalue)
    solid = fine >= iso

    report(45.0, "Classifying occupancy")
    if int(cfg.despeckle_min_voxels) > 1:
        solid = _vg.remove_small_components(solid, int(cfg.despeckle_min_voxels), connectivity=26)
    if int(cfg.gap_bridge_voxels) > 0:
        solid = _vg.binary_close(solid, radius=int(cfg.gap_bridge_voxels), connectivity=26)

    report(60.0, "Separating air from cavities")
    classified = _vg.classify_cavities(
        solid,
        min_cavity_voxels=cfg.cavity_min_voxels(grid),
        connectivity=6,
        max_cavity_fraction=float(cfg.max_cavity_fraction),
    )

    report(75.0, "Applying cavity decisions")
    contour = fine.copy()
    promote = classified.solid & (contour < iso)
    demote = (~classified.solid) & (contour >= iso)
    if np.any(promote):
        inside_values = contour[classified.solid & (contour >= iso)]
        fill_value = float(np.median(inside_values)) if inside_values.size else iso + 1.0
        contour[promote] = max(fill_value, iso + abs(iso) * 1e-3 + 1e-3)
    if np.any(demote):
        outside_values = contour[(~classified.solid) & (contour < iso)]
        void_value = float(np.median(outside_values)) if outside_values.size else iso - 1.0
        contour[demote] = min(void_value, iso - abs(iso) * 1e-3 - 1e-3)

    report(85.0, "Extracting surface")
    verts, faces = extract_isosurface(
        contour,
        isovalue=iso,
        spacing=grid.spacing,
        origin=grid.origin,
        progress_cb=lambda p: report(85.0 + float(p) * 0.15, "Extracting surface"),
    )

    voxel_volume = grid.voxel_volume
    stats = dict(resample_stats)
    stats.update(
        {
            "isovalue": iso,
            "solid_voxels": int(np.count_nonzero(classified.solid)),
            "cavity_count": len(classified.cavity_sizes),
            "cavity_volumes": [float(n) * voxel_volume for n in classified.cavity_sizes],
            "noise_pockets_filled": int(classified.filled_voxels),
            "cavities_rejected": int(classified.discarded_cavities),
            "vertices": int(len(verts)),
            "faces": int(len(faces)),
        }
    )
    report(100.0, "Mesh ready")
    return verts, faces, stats
