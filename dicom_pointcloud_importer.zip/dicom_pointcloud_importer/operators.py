from __future__ import annotations

import bpy
import bmesh
import numpy as np
from mathutils import kdtree
from pathlib import Path
import re
import threading
import time


ACTIVE_SEGMENTATION_OPERATOR = None
ACTIVE_MESH_CONVERSION_OPERATOR = None
ACTIVE_POINTCLOUD_WORKER = None


def _shell_settings_from_props(props):
    """Build a surface.ShellSettings from the scene properties."""
    from .surface import ShellSettings

    return ShellSettings(
        resolution_multiplier=float(props.shell_resolution_multiplier),
        isotropic=bool(props.shell_isotropic),
        filter_method=str(props.shell_filter).lower(),
        cover_points=bool(props.shell_cover_points),
        cover_radius=float(props.shell_cover_radius),
        clamp_overshoot=bool(props.shell_clamp_overshoot),
        surface_sigma=float(props.shell_surface_sigma),
        gap_bridge_voxels=int(props.shell_gap_bridge),
        despeckle_min_voxels=int(props.shell_despeckle_min_voxels),
        keep_cavities=bool(props.shell_keep_cavities),
        cavity_min_volume=float(props.shell_cavity_min_volume),
        shell_thickness=int(props.pc_shell_thickness),
        min_island_volume=max(0.0, float(props.shell_min_island_volume)),
        max_vertices=max(1, int(getattr(props, "mesh_max_vertices_m", 6))) * 1_000_000,
        voxel_budget=max(1, int(props.shell_voxel_budget_mv)) * 1_000_000,
    )


def _import_settings_from_props(props):
    """Build a surface.ShellSettings for the import-time volume resample."""
    from .surface import ShellSettings

    return ShellSettings(
        # The same numbers the mesher uses. They were two identical groups
        # applied at two stages, which read as one setting that did not work
        # whenever the other copy was the one being changed.
        resolution_multiplier=float(props.shell_resolution_multiplier),
        isotropic=bool(props.shell_isotropic),
        filter_method=str(props.shell_filter).lower(),
        clamp_overshoot=bool(props.shell_clamp_overshoot),
        voxel_budget=max(1, int(props.shell_voxel_budget_mv)) * 1_000_000,
    )


def _build_mesh_fast(mesh, verts, faces):
    """Fill ``mesh`` from numpy arrays without going through ``from_pydata``.

    ``from_pydata`` takes Python sequences, so feeding it a large mesh means
    first materialising a tuple per vertex and a list per face, then letting it
    walk those again. On a multi-million-vertex reconstruction that is minutes
    of single-threaded work and gigabytes of interpreter objects - it froze
    Blender outright on a four-tier lumbar run that had already reached 100%.

    ``foreach_set`` takes a flat buffer straight from numpy instead. Every face
    the isosurface extractor produces is a quad, so the loop layout is uniform
    and can be generated with ``arange``.
    """
    verts = np.ascontiguousarray(verts, dtype=np.float32)
    faces = np.ascontiguousarray(faces, dtype=np.int32)
    if faces.ndim != 2:
        raise ValueError("faces must be a 2D array of uniform-size polygons")

    n_verts = int(verts.shape[0])
    n_faces = int(faces.shape[0])
    per_face = int(faces.shape[1])

    mesh.vertices.add(n_verts)
    mesh.vertices.foreach_set("co", verts.reshape(-1))

    mesh.loops.add(n_faces * per_face)
    mesh.loops.foreach_set("vertex_index", faces.reshape(-1))

    mesh.polygons.add(n_faces)
    mesh.polygons.foreach_set(
        "loop_start", np.arange(0, n_faces * per_face, per_face, dtype=np.int32)
    )
    mesh.polygons.foreach_set(
        "loop_total", np.full(n_faces, per_face, dtype=np.int32)
    )
    # Edges are not stored by the loop layout, so they have to be derived; the
    # smoother needs them for adjacency in any case.
    mesh.update(calc_edges=True)

    # Written straight into the mesh arrays, this has had none of the checks
    # from_pydata would have run. Blender's modifiers trust what is in the
    # mesh, so anything malformed that reached this point is not an error
    # message later, it is a crash inside the modifier. Cheap next to the
    # reconstruction, and it returns True only if it had to correct something.
    validate = getattr(mesh, "validate", None)
    if validate is None:
        return False
    corrected = bool(validate(verbose=False, clean_customdata=False))
    if corrected:
        mesh.update(calc_edges=True)
    return corrected


def _store_diagnostics(context, text: str) -> None:
    """Keep the last diagnostics where the panel's copy button can reach them."""
    try:
        context.scene.dicom_import_props.last_diagnostics = str(text)
    except Exception:
        pass


def _store_batch_diagnostics(context, blocks, summary: str = "") -> None:
    """Keep the diagnostics of *every* cloud in a multi-cloud run.

    Storing only the last one is no use for the case this is most needed in.
    Converting a whole-body study means converting one cloud per station, and
    the question is always which stations failed and why - but the successful
    station that happened to run last would overwrite the answer, leaving the
    user with a healthy-looking report and no idea what went wrong.
    """
    parts = [summary] if summary else []
    parts.extend(str(block) for block in blocks if block)
    _store_diagnostics(context, "\n\n".join(parts))


def _no_geometry_hint(stats: dict) -> str:
    """The single most likely reason this run produced nothing."""
    if not stats:
        return "No measurements were recorded - the run failed before reconstruction."

    shape = stats.get("source_shape") or ()
    extent = stats.get("world_extent") or ()
    if shape and extent and min(shape) > 0:
        longest = max(extent) if extent else 0.0
        samples = max(shape)
        if longest > 0 and samples < 24:
            return (
                "The working grid is only {} samples across for an object {:.0f} units "
                "wide, so the lattice spacing was misread - set it manually.".format(
                    samples, longest
                )
            )

    above = stats.get("intensity_above_level_fraction")
    if above is not None and float(above) < 0.01:
        return (
            "Intensity Level keeps only {:.2%} of the material - lower it.".format(
                float(above)
            )
        )
    if stats.get("intensity_level_clamped"):
        return "Intensity Level is outside the material's range - lower it."
    if int(stats.get("solid_voxels", 1) or 0) == 0:
        return "No voxel survived classification - lower Despeckle Min Voxels."
    if int(stats.get("islands_dropped", 0) or 0) and not stats.get("vertices"):
        return "Min Island Volume removed every piece - lower it."
    return "See the numbers below for which stage emptied out."


def _format_shell_diagnostics(stats: dict, source_name: str = "") -> str:
    """Everything measured during a reconstruction, as text.

    Exists because "nothing happened" is the one outcome a user cannot act on.
    An empty result used to increment a skip counter and say nothing, so a run
    that produced no geometry looked identical to a run that was never started.
    These are the numbers that distinguish the possible causes - a misread
    lattice spacing, a level above every voxel, an over-aggressive filter - so
    they are printed together rather than left to be guessed at.
    """
    if not stats:
        return "No diagnostics recorded."

    def fmt(value):
        if isinstance(value, (tuple, list)):
            return "(" + ", ".join(
                f"{v:.4g}" if isinstance(v, float) else str(v) for v in value
            ) + ")"
        if isinstance(value, float):
            return f"{value:.4g}"
        if isinstance(value, int):
            return f"{value:,}"
        return str(value)

    lines = []
    if source_name:
        lines.append(f"Source cloud: {source_name}")

    groups = (
        ("Input", ("input_points", "world_extent")),
        ("Lattice", ("requested_spacing", "source_spacing", "spacing_source",
                     "spacing_coarsened", "solidify_close_radius", "interior_fill")),
        ("Source grid", ("source_shape", "occupied_voxels", "solid_voxels",
                         "despeckled_voxels", "cavity_count", "cavity_voxels")),
        ("Detail gate", ("detail_threshold", "detail_region_voxels",
                         "detail_dropped_voxels", "detail_discriminating")),
        ("Reconstruction", ("fine_shape", "fine_spacing", "fine_voxels",
                            "budget_reduced", "factors")),
        ("Surface", ("surface_source", "isovalue", "intensity_range",
                     "intensity_level_requested", "intensity_level_chosen",
                     "intensity_level_absolute", "intensity_level_clamped",
                     "intensity_above_level_fraction", "intensity_level_auto",
                     "intensity_parts_unsmoothed", "intensity_parts_smoothed")),
        ("Filters", ("necks_reach_voxels", "necks_parts_found", "necks_cut_voxels",
                     "islands_total", "islands_dropped", "islands_min_volume")),
        ("Output", ("tier_label", "tier_intensity_range", "vertices", "faces")),
    )

    for title, keys in groups:
        present = [(k, stats[k]) for k in keys if k in stats]
        if present:
            lines.append(f"[{title}]")
            for key, value in present:
                lines.append(f"  {key} = {fmt(value)}")

    scan = stats.get("intensity_scan")
    if scan:
        lines.append("[Level scan]  level: material kept, parts")
        for level, kept, parts in scan:
            lines.append(f"  {level:.2f}: {kept:.1%}, {parts}")

    warnings = stats.get("warnings") or []
    if warnings:
        lines.append("[Warnings]")
        for w in warnings:
            lines.append(f"  - {w}")

    return "\n".join(lines)


def _read_pointcloud_arrays(obj):
    """Extract ``(coords, intensities)`` from a point cloud object.

    Coordinates stay in the object's local space. Every object generated from
    one of these clouds copies the source's ``matrix_world``, so reconstructing
    in local space keeps the result aligned without any round-tripping.
    ``intensities`` is ``None`` for clouds that carry neither an Intensity
    attribute nor vertex colours.
    """
    cloud = obj.data
    count = len(cloud.points)
    coords = np.empty(count * 3, dtype=np.float32)
    cloud.points.foreach_get("co", coords)
    coords = coords.reshape((-1, 3))
    intensities = _extract_cloud_intensity_values(cloud)
    if intensities is not None:
        intensities = np.clip(np.asarray(intensities, dtype=np.float32).reshape(-1), 0.0, 1.0)
    return coords, intensities


def _report_shell_warnings(operator, stats: dict) -> None:
    """Surface reconstruction warnings as Blender operator reports.

    A blob-shaped result is silent otherwise - the mesh looks plausible until
    you compare it with the cloud - so anything the diagnostics caught is
    pushed into the info log where the user will actually see it.
    """
    messages = [str(m) for m in ((stats or {}).get("warnings") or [])]
    for message in messages:
        try:
            operator.report({"WARNING"}, message)
        except Exception:
            pass
    # And on the panel, where the person who set the settings is looking.
    try:
        context = getattr(operator, "_warning_context", None) or bpy.context
        context.scene.dicom_import_props.last_warnings = "\n".join(messages)
    except Exception:
        pass


def _popup_warnings(context, title: str, messages) -> None:
    """Put problems with the files in front of the user, not in the log.

    An operator report lands in the status bar and the info editor. Neither is
    where someone is looking after clicking Import, so a series that cannot
    work - a localizer, a stack with slices missing - was imported, looked
    plausible, and only turned out to be wrong much later. This is the one
    class of problem worth interrupting for, because no setting can fix it.
    """
    lines = [str(m) for m in (messages or []) if str(m).strip()]
    # Set even when empty: a clean import has to clear the last one's
    # complaints, or they sit on the panel looking like they describe what was
    # just imported.
    try:
        context.scene.dicom_import_props.last_warnings = "\n".join(lines)
    except Exception:
        pass
    if not lines:
        return

    def draw(self, _context):
        column = self.layout.column(align=True)
        for line in lines:
            # Blender labels do not wrap, and a warning cut off at the popup
            # edge is no better than one nobody read.
            words = str(line).split()
            row = ""
            for word in words:
                if len(row) + len(word) + 1 > 72:
                    column.label(text=row)
                    row = word
                else:
                    row = f"{row} {word}".strip()
            if row:
                column.label(text=row)
            column.separator()

    # Not merely guarded with try/except: popup_menu in a background Blender
    # does not raise, it dies with an access violation, so the only safe thing
    # is not to call it. The report and the panel still carry the message.
    if not bool(getattr(bpy.app, "background", False)):
        try:
            if getattr(context, "window", None) is not None:
                context.window_manager.popup_menu(draw, title=title,
                                                  icon="ERROR")
        except Exception:
            # A popup is never worth failing an import over.
            pass


def _format_shell_report(stats: dict) -> str:
    """One-line summary of a reconstruction, for the status bar."""
    parts = []
    fine = stats.get("fine_shape")
    if fine:
        parts.append(f"grid {fine[2]}x{fine[1]}x{fine[0]}")
    spacing = stats.get("fine_spacing")
    if spacing:
        parts.append(f"step {min(spacing):.3g}")
    cavities = int(stats.get("cavity_count", 0) or 0)
    if cavities:
        volumes = stats.get("cavity_volumes") or []
        biggest = f", largest {volumes[0]:.1f}" if volumes else ""
        parts.append(f"{cavities} cavity/cavities{biggest}")
    else:
        parts.append("no cavities")
    filled = int(stats.get("noise_pockets_filled", 0) or 0)
    if filled:
        parts.append(f"{filled} noise voxels filled")
    if stats.get("budget_reduced"):
        parts.append("resolution reduced to fit voxel budget")

    before = int(stats.get("components_before_bridge", 0) or 0)
    after = int(stats.get("components_after_bridge", 0) or 0)
    if before and after and after < before:
        parts.append(f"gap bridging merged {before}->{after} structures")

    count = len((stats or {}).get("warnings") or [])
    if count:
        parts.append(f"{count} warning(s) - see the Info log")
    return "; ".join(parts)


def _intensity_to_rgba(value: float, mode: str):
    v = max(0.0, min(1.0, float(value)))
    if mode == "HEAT":
        # Cool-to-hot palette for stronger structure separation.
        if v < 0.33:
            t = v / 0.33
            return (0.08 * (1.0 - t) + 0.0 * t, 0.15 * (1.0 - t) + 0.65 * t, 0.5 * (1.0 - t) + 1.0 * t, 1.0)
        if v < 0.66:
            t = (v - 0.33) / 0.33
            return (0.0 * (1.0 - t) + 1.0 * t, 0.65 * (1.0 - t) + 0.85 * t, 1.0 * (1.0 - t) + 0.0 * t, 1.0)
        t = (v - 0.66) / 0.34
        return (1.0, 0.85 * (1.0 - t) + 0.05 * t, 0.0 * (1.0 - t) + 0.0 * t, 1.0)

    return (v, v, v, 1.0)


def _create_point_material(name: str = "DICOMPointCloud_Mat"):
    # Create per-object material to avoid shared node-tree mutations across undo history.
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new(type="ShaderNodeOutputMaterial")
    out.location = (400, 0)
    bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
    bsdf.location = (140, 0)
    attr = nodes.new(type="ShaderNodeAttribute")
    attr.location = (-120, 0)
    attr.attribute_name = "Col"

    links.new(attr.outputs[0], bsdf.inputs[0])
    links.new(bsdf.outputs[0], out.inputs[0])
    return mat


def _create_point_cloud_object(
    context,
    points,
    intensities,
    spacing,
    props,
    object_name: str = "DICOMPointCloud",
    apply_stride: bool = True,
    extra_attributes=None,
):
    points = np.asarray(points, dtype=np.float32)
    intensities = np.asarray(intensities, dtype=np.float32).reshape(-1)

    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("Point buffer must be Nx3")
    if intensities.shape[0] != points.shape[0]:
        raise ValueError("Intensity buffer length must match point count")

    cloud = bpy.data.pointclouds.new(object_name)
    point_count = int(points.shape[0])
    cloud.resize(point_count)

    # Derived clouds (surface extraction, upsampling) already have their spacing
    # baked into `spacing`, so the import stride must not be applied again -
    # doing so would draw points several times larger than their real footprint.
    stride = float(props.stride) if apply_stride else 1.0
    base_step = max(0.0001, min(float(spacing[0]), float(spacing[1]), float(spacing[2])) * stride)
    radius = max(0.0005, base_step * float(props.point_radius_scale))

    flat_points = points.reshape(-1)
    cloud.points.foreach_set("co", flat_points)
    cloud.points.foreach_set("radius", np.full(point_count, radius, dtype=np.float32))

    col_attr = cloud.attributes.get("Col")
    if col_attr is None:
        col_attr = cloud.attributes.new(name="Col", type="FLOAT_COLOR", domain="POINT")

    intensity_attr = cloud.attributes.get("Intensity")
    if intensity_attr is None:
        intensity_attr = cloud.attributes.new(name="Intensity", type="FLOAT", domain="POINT")

    flat_colors = np.empty(point_count * 4, dtype=np.float32)
    if props.color_mode == "GRAYSCALE":
        v = np.clip(intensities, 0.0, 1.0)
        flat_colors[0::4] = v
        flat_colors[1::4] = v
        flat_colors[2::4] = v
        flat_colors[3::4] = 1.0
    else:
        v = np.clip(intensities, 0.0, 1.0)
        r = np.empty_like(v)
        g = np.empty_like(v)
        b = np.empty_like(v)

        low = v < 0.33
        mid = (v >= 0.33) & (v < 0.66)
        high = v >= 0.66

        if np.any(low):
            t = v[low] / 0.33
            r[low] = 0.08 * (1.0 - t)
            g[low] = 0.15 * (1.0 - t) + 0.65 * t
            b[low] = 0.5 * (1.0 - t) + 1.0 * t

        if np.any(mid):
            t = (v[mid] - 0.33) / 0.33
            r[mid] = t
            g[mid] = 0.65 * (1.0 - t) + 0.85 * t
            b[mid] = 1.0 - t

        if np.any(high):
            t = (v[high] - 0.66) / 0.34
            r[high] = 1.0
            g[high] = 0.85 * (1.0 - t) + 0.05 * t
            b[high] = 0.0

        flat_colors[0::4] = r
        flat_colors[1::4] = g
        flat_colors[2::4] = b
        flat_colors[3::4] = 1.0
    col_attr.data.foreach_set("color", flat_colors)
    intensity_attr.data.foreach_set("value", np.clip(intensities, 0.0, 1.0))

    # Anything else measured per point, kept as it was rather than windowed.
    # Intensity is for looking at - it is clipped to 0..1 against a display
    # range - so a later pass that needs the real numbers cannot use it.
    for name, values in (extra_attributes or {}).items():
        attr = cloud.attributes.get(name)
        if attr is None:
            attr = cloud.attributes.new(name=name, type="FLOAT", domain="POINT")
        attr.data.foreach_set(
            "value", np.asarray(values, dtype=np.float32).reshape(-1))

    obj = bpy.data.objects.new(object_name, cloud)
    context.collection.objects.link(obj)
    obj.location = (0.0, 0.0, 0.0)
    obj.show_name = True
    obj["dicom_pointcloud_imported"] = True

    mat = _create_point_material()
    obj.active_material = mat

    return obj


def _set_progress(context, props, percent: float, message: str) -> None:
    clamped = max(0.0, min(100.0, float(percent)))
    current_props = None
    try:
        current_props = context.scene.dicom_import_props
    except Exception:
        current_props = props

    try:
        if current_props is not None:
            previous = float(getattr(current_props, "progress_percent", 0.0))
            if abs(previous - clamped) >= 0.5:
                current_props.progress_percent = clamped
            current_props.status = f"{message} ({int(clamped)}%)"
    except Exception:
        pass

    try:
        context.window_manager.progress_update(clamped)
    except Exception:
        pass
    for window in context.window_manager.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            area.tag_redraw()


def _get_selected_imported_pointcloud(context):
    obj = context.active_object
    if obj is None:
        return None
    if obj.type != "POINTCLOUD":
        return None
    if not bool(obj.get("dicom_pointcloud_imported", False)):
        return None
    return obj


def _get_selected_pointclouds(context):
    selected = []
    for obj in context.selected_objects:
        if obj is None:
            continue
        if obj.type != "POINTCLOUD":
            continue
        selected.append(obj)

    if selected:
        return selected

    active = context.active_object
    if active is not None and active.type != "POINTCLOUD":
        active = None
    return [active] if active is not None else []


def _extract_cloud_intensity_values(cloud) -> np.ndarray | None:
    """Read a cloud's per-point Intensity, or derive it from vertex colours.

    Accepts either a point-cloud datablock or the Object wrapping one. Callers
    naturally have an Object in hand while this needs its data, and passing the
    wrong one used to fail deep inside with an unhelpful AttributeError.
    """
    if not hasattr(cloud, "attributes") and hasattr(cloud, "data"):
        cloud = cloud.data

    intensity_attr = cloud.attributes.get("Intensity")
    if intensity_attr is not None:
        values = np.empty(len(cloud.points), dtype=np.float32)
        intensity_attr.data.foreach_get("value", values)
        return values

    color_attr = cloud.attributes.get("Col")
    if color_attr is not None:
        colors = np.empty(len(cloud.points) * 4, dtype=np.float32)
        color_attr.data.foreach_get("color", colors)
        colors = colors.reshape((-1, 4))
        # Use luminance as a fallback proxy for intensity on legacy clouds.
        return (0.2126 * colors[:, 0]) + (0.7152 * colors[:, 1]) + (0.0722 * colors[:, 2])

    return None


def _make_unique_object_name(base: str) -> str:
    if bpy.data.objects.get(base) is None:
        return base
    i = 1
    while True:
        candidate = f"{base}_{i:03d}"
        if bpy.data.objects.get(candidate) is None:
            return candidate
        i += 1


def _resolve_source_pointcloud_for_filter(context):
    active = context.active_object
    if active is not None and active.type == "POINTCLOUD":
        return active

    if active is not None:
        source_name = str(active.get("dicom_hull_source", "") or "")
        if source_name:
            candidate = bpy.data.objects.get(source_name)
            if candidate is not None and candidate.type == "POINTCLOUD":
                return candidate

    for obj in context.selected_objects:
        if obj.type == "POINTCLOUD":
            return obj

    return None


def _edges_from_faces(faces) -> np.ndarray:
    """Unique undirected edges of a uniform-size polygon array.

    The smoother needs vertex adjacency, and asking Blender for it means relying
    on ``Mesh.update(calc_edges=True)`` having populated ``mesh.edges`` - which
    is exactly the dependency that made the smoother a no-op. The faces are
    already in hand, so the adjacency is derived here instead and nothing about
    whether smoothing runs depends on the order Blender builds its caches in.
    """
    faces = np.asarray(faces, dtype=np.int64)
    if faces.ndim != 2 or faces.shape[0] == 0:
        return np.zeros((0, 2), dtype=np.int64)
    per_face = faces.shape[1]
    pairs = np.concatenate(
        [
            np.stack((faces[:, k], faces[:, (k + 1) % per_face]), axis=1)
            for k in range(per_face)
        ]
    )
    pairs.sort(axis=1)
    return np.unique(pairs, axis=0)


def _apply_detail_preserving_smoothing(mesh, strength: float, edges=None) -> None:
    """Taubin smoothing, at a strength that can actually be seen.

    Taubin alternates a shrinking pass with an inflating one, which is what lets
    it remove the staircase left by voxel sampling without melting the shape.
    But the effect per iteration is small by design, and the previous settings -
    lambda 0.32 against mu -0.34, run twice - removed only **19% of the surface
    roughness** and moved vertices 2% of a voxel. On a reconstruction at 0.26 mm
    that is a few hundredths of a millimetre: correct, and invisible.

    Measured on a staircased sphere, roughness removed against shape lost:

        lambda/mu     iters   roughness   area
        0.32 / -0.34      2       19.3%   -0.03%   <- old default
        0.50 / -0.53     10       54.9%   -0.31%
        0.65 / -0.68     30       70.2%   -0.86%
        0.90 /  0.00     30       81.5%   -4.24%   <- plain Laplacian, melts

    So ``strength`` drives both the pass count and lambda across that range,
    and mu tracks lambda to keep the volume. At 1.0 it removes about 70% of the
    roughness for under 1% of the surface area.

    There is no step cap. The previous one was dead: measured across preserve
    values of 0.8, 0.5 and 0.2 the results were bit-identical, because Taubin's
    own pass pair is the binding constraint and the cap never engaged.

    Adjacency comes from ``edges`` when the caller has it, which it does - the
    faces were just built. Relying on ``mesh.edges`` instead means relying on
    Blender having populated its edge cache, and when it has not, smoothing
    returns immediately and appears to do nothing.
    """
    strength = max(0.0, min(1.0, float(strength)))
    vertex_count = len(mesh.vertices)
    if strength <= 0.0 or vertex_count == 0:
        return

    iterations = max(1, int(round(2 + 28 * strength)))
    lam = 0.35 + 0.30 * strength
    mu = -(lam + 0.03)

    if edges is None:
        edge_count = len(mesh.edges)
        if edge_count == 0:
            return
        edge_verts = np.empty(edge_count * 2, dtype=np.int32)
        mesh.edges.foreach_get("vertices", edge_verts)
        edge_verts = edge_verts.reshape((-1, 2)).astype(np.int64)
    else:
        edge_verts = np.asarray(edges, dtype=np.int64).reshape((-1, 2))
    if edge_verts.shape[0] == 0:
        return

    verts = np.empty(vertex_count * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", verts)
    # float32 throughout: the coordinates arrive and leave as float32, so the
    # wider type only doubles the same-size temporaries below - about 300 MB
    # per million vertices.
    verts = verts.reshape((-1, 3))

    a = edge_verts[:, 0]
    b = edge_verts[:, 1]
    degree = np.bincount(a, minlength=vertex_count) + np.bincount(
        b, minlength=vertex_count
    )
    has_neighbors = degree > 0
    safe_degree = np.maximum(degree, 1).astype(np.float32)[:, None]

    neighbor_sum = np.empty_like(verts)
    for _ in range(iterations):
        for scale in (lam, mu):
            for axis in range(3):
                # bincount with weights is markedly faster than np.add.at here.
                neighbor_sum[:, axis] = np.bincount(
                    a, weights=verts[b, axis], minlength=vertex_count
                ) + np.bincount(b, weights=verts[a, axis], minlength=vertex_count)
            delta = ((neighbor_sum / safe_degree) - verts) * scale
            delta[~has_neighbors] = 0.0
            verts += delta

    mesh.vertices.foreach_set("co", verts.reshape(-1))
    mesh.update()


def _set_mesh_progress(context, percent: float, message: str) -> None:
    clamped = max(0.0, min(100.0, float(percent)))
    try:
        props = context.scene.dicom_import_props
        props.mesh_progress_percent = clamped
        props.mesh_conversion_running = True
        props.status = f"{message} ({int(clamped)}%)"
    except Exception:
        pass

    try:
        context.window_manager.progress_update(clamped)
    except Exception:
        pass

    for window in context.window_manager.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            area.tag_redraw()


def _describe_pointcloud(obj) -> str:
    """Everything about a cloud that decides how it will mesh.

    Instant, because it reads the datablock and nothing else. The intensity
    path has three ways to fail silently - a missing attribute, an attribute
    whose values are flat, and an attribute on a scale that gets clipped on
    read - and none of them are visible from the viewport, where the cloud is
    coloured by its material rather than by the values the mesher uses.
    """
    from . import surface as _sf
    from . import voxelgrid as _vg

    cloud = obj.data
    lines = [f"Cloud: {obj.name}  (type {obj.type})"]

    count = len(cloud.points)
    lines.append(f"  points = {count:,}")
    try:
        names = [a.name for a in cloud.attributes]
    except Exception:
        names = []
    lines.append(f"  attributes = {names}")

    coords = np.empty(count * 3, dtype=np.float32)
    cloud.points.foreach_get("co", coords)
    coords = coords.reshape((-1, 3))
    lower = coords.min(axis=0)
    upper = coords.max(axis=0)
    lines.append(
        "  bounds = ({:.3g}, {:.3g}, {:.3g}) to ({:.3g}, {:.3g}, {:.3g})".format(
            *lower, *upper
        )
    )
    extent = upper - lower
    lines.append("  extent = ({:.4g}, {:.4g}, {:.4g})".format(*extent))

    try:
        spacing, source = _vg.estimate_lattice_spacing(coords, with_source=True)
        lines.append(
            "  estimated spacing = ({:.4g}, {:.4g}, {:.4g})  via {}".format(
                *spacing, source
            )
        )
        samples = [
            (extent[i] / spacing[i]) if spacing[i] > 0 else 0.0 for i in range(3)
        ]
        lines.append(
            "  samples across = ({:.0f}, {:.0f}, {:.0f})".format(*samples)
        )
    except Exception as exc:
        lines.append(f"  estimated spacing FAILED: {exc}")

    raw = _extract_cloud_intensity_values(cloud)
    if raw is None:
        lines.append("  INTENSITY: no Intensity attribute and no Col attribute.")
        lines.append("    Intensity surfacing cannot work on this cloud; it will fall")
        lines.append("    back to Occupancy. Re-import with a colour mode.")
        return "\n".join(lines)

    raw = np.asarray(raw, dtype=np.float32).reshape(-1)
    lines.append("  intensity attribute, as stored:")
    lines.append(
        "    min={:.6g} max={:.6g} mean={:.6g}".format(
            float(raw.min()), float(raw.max()), float(raw.mean())
        )
    )
    lines.append(
        "    percentiles "
        + ", ".join(
            "p{}={:.6g}".format(q, float(np.percentile(raw, q)))
            for q in (0, 2, 25, 50, 75, 98, 100)
        )
    )
    outside = int(np.count_nonzero((raw < 0.0) | (raw > 1.0)))
    lines.append(
        "    values outside 0..1 = {:,} of {:,} ({:.1%})".format(
            outside, raw.size, outside / max(1, raw.size)
        )
    )

    clipped = np.clip(raw, 0.0, 1.0)
    spread = float(np.percentile(clipped, 98) - np.percentile(clipped, 2))
    lines.append("  intensity as the mesher reads it (clipped to 0..1):")
    lines.append(
        "    p2={:.6g} p98={:.6g} spread={:.6g}".format(
            float(np.percentile(clipped, 2)), float(np.percentile(clipped, 98)), spread
        )
    )
    if outside > 0.01 * raw.size:
        lines.append(
            "    PROBLEM: values are outside 0..1 and are clipped on read, so the"
        )
        lines.append(
            "    mesher sees a flatter field than the viewport shows. Re-import."
        )
    if spread <= 1e-4:
        lines.append(
            "    PROBLEM: the clipped field is effectively constant - an intensity"
        )
        lines.append("    surface has nothing to follow. Use Occupancy, or re-import.")
    else:
        lines.append("    (spread looks usable for intensity surfacing)")
        for frac in (0.05, 0.10, 0.15, 0.25, 0.35, 0.50, 0.70):
            level = float(np.percentile(clipped, 2)) + frac * spread
            kept = float(np.count_nonzero(clipped >= level)) / float(clipped.size)
            lines.append(
                "    level {:.2f} -> absolute {:.5g}, keeps {:.1%} of points".format(
                    frac, level, kept
                )
            )

    return "\n".join(lines)


class DICOM_OT_inspect_pointcloud(bpy.types.Operator):
    bl_idname = "dicom.inspect_pointcloud"
    bl_label = "Inspect Cloud"
    bl_description = (
        "Report everything about the selected point cloud that decides how it will "
        "mesh: its attributes, extent, estimated lattice spacing, and the actual "
        "distribution of its intensity values including what fraction each Intensity "
        "Level would keep. Runs instantly and copies the result to the clipboard"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        clouds = [
            o for o in (context.selected_objects or []) if o.type == "POINTCLOUD"
        ]
        if not clouds:
            active = context.active_object
            if active is not None and active.type == "POINTCLOUD":
                clouds = [active]
        if not clouds:
            self.report({"WARNING"}, "Select a point cloud first")
            return {"CANCELLED"}

        blocks = []
        for obj in clouds[:4]:
            try:
                blocks.append(_describe_pointcloud(obj))
            except Exception as exc:
                blocks.append(f"Cloud: {obj.name}\n  INSPECTION FAILED: {exc}")
        text = "\n\n".join(blocks)

        print("\n=== DICOM point cloud inspection ===")
        print(text)
        _store_diagnostics(context, text)
        try:
            context.window_manager.clipboard = text
        except Exception:
            self.report({"INFO"}, "Inspection printed to the system console")
            return {"FINISHED"}
        self.report(
            {"INFO"},
            "Inspected {:d} cloud(s); result copied to the clipboard and printed to "
            "the console".format(len(blocks)),
        )
        return {"FINISHED"}


class DICOM_OT_copy_diagnostics(bpy.types.Operator):
    bl_idname = "dicom.copy_diagnostics"
    bl_label = "Copy Diagnostics"
    bl_description = (
        "Copy the measurements from the last mesh conversion to the clipboard and "
        "print them to the system console. Use this when a run produces nothing, or "
        "less than expected - it records the lattice spacing, grid sizes, intensity "
        "range, level scan and every warning, which is what identifies the stage "
        "responsible"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        text = str(getattr(context.scene.dicom_import_props, "last_diagnostics", "") or "")
        if not text:
            self.report({"WARNING"}, "No diagnostics recorded yet - run a conversion first")
            return {"CANCELLED"}
        print("\n=== DICOM mesh conversion diagnostics ===")
        print(text)
        try:
            context.window_manager.clipboard = text
        except Exception as exc:
            self.report({"WARNING"}, f"Printed to console; clipboard failed: {exc}")
            return {"FINISHED"}
        self.report(
            {"INFO"},
            "Diagnostics copied to the clipboard ({:,} characters) and printed to the "
            "console".format(len(text)),
        )
        return {"FINISHED"}


class DICOM_OT_pointcloud_to_hull_mesh(bpy.types.Operator):
    bl_idname = "dicom.pointcloud_to_hull_mesh"
    bl_label = "Point Clouds To Mesh"
    bl_description = "Create meshes from selected point cloud objects"
    bl_options = {"REGISTER", "UNDO"}

    def _start_worker_for_current(self):
        src_obj = self._targets[self._target_index]
        coords, intensities = _read_pointcloud_arrays(src_obj)

        seed = abs(hash(src_obj.name)) % (2**32)
        shell_settings = self._shell_settings

        self._worker_done = False
        self._worker_error = None
        self._worker_result = None
        self._worker_progress = 2.0
        self._worker_message = ""
        self._worker_stats = {}

        def _runner():
            try:
                # Deliberately no sampling. The interior/exterior test reads
                # occupancy, so thinning the cloud first would punch holes
                # through solid material and make the interior read as exposed
                # surface - the density is the signal.
                from .surface import pointcloud_to_shell_mesh

                def _shell_cb(percent, message=""):
                    self._worker_progress = max(self._worker_progress, float(percent))
                    if message:
                        self._worker_message = message

                verts, faces, stats = pointcloud_to_shell_mesh(
                    coords, intensities, shell_settings, progress_cb=_shell_cb
                )
                self._worker_stats = stats
                self._worker_result = {
                    "verts": np.ascontiguousarray(verts, dtype=np.float32),
                    "faces": np.ascontiguousarray(faces, dtype=np.int32),
                    "src_name": src_obj.name,
                }
                self._worker_progress = 100.0
            except Exception as exc:
                self._worker_error = str(exc)
            finally:
                self._worker_done = True

        self._worker_thread = threading.Thread(target=_runner, daemon=True)
        self._worker_thread.start()

    def _finish(self, context, cancelled: bool = False):
        global ACTIVE_MESH_CONVERSION_OPERATOR
        props = context.scene.dicom_import_props

        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None

        try:
            context.window_manager.progress_end()
        except Exception:
            pass

        props.mesh_conversion_running = False
        if cancelled:
            props.status = "Mesh conversion cancelled"
        ACTIVE_MESH_CONVERSION_OPERATOR = None

    def invoke(self, context, event):
        global ACTIVE_MESH_CONVERSION_OPERATOR
        props = context.scene.dicom_import_props

        if ACTIVE_MESH_CONVERSION_OPERATOR is not None:
            self.report({"WARNING"}, "Mesh conversion already running")
            return {"CANCELLED"}

        targets = _get_selected_pointclouds(context)
        if not targets:
            self.report({"ERROR"}, "Select at least one point cloud object")
            return {"CANCELLED"}

        self._targets = [obj for obj in targets if len(obj.data.points) >= 4]
        self._shell_settings = _shell_settings_from_props(props)
        self._smooth_strength = max(0.0, min(1.0, float(props.mesh_smooth_strength)))
        self._prefix = str(props.mesh_hull_prefix)
        self._max_vertices = max(1, int(getattr(props, "mesh_max_vertices_m", 6))) * 1_000_000
        self._hide_source = bool(props.mesh_hull_hide_source)
        self._target_index = 0
        self._created = 0
        self._last_stats = {}
        self._skipped = max(0, len(targets) - len(self._targets))
        self._diagnostic_blocks = []
        self._outcomes = [
            (obj.name, f"skipped: only {len(obj.data.points)} points, needs 4")
            for obj in targets
            if obj not in self._targets
        ]
        self._cancel_requested = False
        self._worker_done = False
        self._worker_error = None
        self._worker_result = None
        self._worker_progress = 0.0
        self._worker_thread = None
        self._timer = None
        self._stage = "start_next"

        if not self._targets:
            self.report({"WARNING"}, "No selected point clouds have enough points")
            return {"CANCELLED"}

        props.mesh_conversion_running = True
        props.mesh_progress_percent = 0.0

        ACTIVE_MESH_CONVERSION_OPERATOR = self
        context.window_manager.progress_begin(0.0, 100.0)
        _set_mesh_progress(context, 0.0, "Preparing mesh conversion")

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC":
            self._cancel_requested = True

        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        if self._cancel_requested:
            self._finish(context, cancelled=True)
            self.report({"WARNING"}, "Mesh conversion cancelled")
            return {"CANCELLED"}

        total = max(1, len(self._targets))

        if self._stage == "start_next":
            if self._target_index >= len(self._targets):
                _set_mesh_progress(context, 100.0, "Mesh conversion complete")
                summary = (
                    f"Created {self._created} mesh object(s)"
                    + (f", skipped {self._skipped}" if self._skipped else "")
                )
                if self._last_stats:
                    detail = _format_shell_report(self._last_stats)
                    if detail:
                        summary = f"{summary} - {detail}"

                # The run's verdict, cloud by cloud, in front of the per-cloud
                # measurements. Converting a whole-body study is a run of many
                # clouds, and "created 3, skipped 2" does not say *which* two -
                # which is the only thing the user actually needs in order to
                # do something about it.
                roster = "\n".join(
                    f"  {name}: {outcome}" for name, outcome in self._outcomes
                )
                header = (
                    f"Mesh conversion: {self._created} created, "
                    f"{self._skipped} skipped, of {len(self._targets)} cloud(s)"
                )
                if roster:
                    header = f"{header}\n{roster}"
                _store_batch_diagnostics(context, self._diagnostic_blocks, header)

                if self._skipped and self._created:
                    names = ", ".join(
                        name for name, outcome in self._outcomes
                        if not outcome.startswith("meshed")
                    )
                    self.report(
                        {"WARNING"},
                        f"These clouds produced no mesh: {names}. Press Copy "
                        f"Diagnostics for the reason for each one.",
                    )
                context.scene.dicom_import_props.status = summary
                self._finish(context, cancelled=False)
                if self._created == 0:
                    self.report(
                        {"WARNING"},
                        "No mesh objects were created. Press Copy Diagnostics in the "
                        "DICOM panel, or see the system console, for the measurements "
                        "from this run.",
                    )
                    return {"CANCELLED"}
                self.report({"INFO"}, context.scene.dicom_import_props.status)
                return {"FINISHED"}

            src_obj = self._targets[self._target_index]
            overall = 100.0 * (float(self._target_index) / float(total))
            _set_mesh_progress(context, overall, f"Preparing {src_obj.name}")
            self._start_worker_for_current()
            self._stage = "worker_running"
            return {"RUNNING_MODAL"}

        if self._stage == "worker_running":
            src_obj = self._targets[self._target_index]
            base = 100.0 * (float(self._target_index) / float(total))
            span = 100.0 / float(total)
            overall = base + (span * max(0.0, min(100.0, float(self._worker_progress))) / 100.0)
            detail = getattr(self, "_worker_message", "")
            label = f"{src_obj.name}: {detail}" if detail else f"Building {src_obj.name}"
            _set_mesh_progress(context, overall, label)

            if not self._worker_done:
                return {"RUNNING_MODAL"}

            if self._worker_error:
                self._skipped += 1
                self._outcomes.append((src_obj.name, f"failed: {self._worker_error}"))
                self._diagnostic_blocks.append(
                    "Source cloud: {}\nFailed: {}".format(
                        src_obj.name, self._worker_error
                    )
                )
                _store_batch_diagnostics(context, self._diagnostic_blocks)
                print(f"\n=== DICOM mesh conversion failed on {src_obj.name} ===")
                print(self._worker_error)
                self.report({"WARNING"}, f"Skipped {src_obj.name}: {self._worker_error}")
                self._target_index += 1
                self._stage = "start_next"
                return {"RUNNING_MODAL"}

            result = self._worker_result or {}
            verts = result.get("verts")
            faces = result.get("faces")
            has_geometry = faces is not None and len(faces) > 0
            if self._worker_stats:
                self._last_stats = dict(self._worker_stats)
                _report_shell_warnings(self, self._worker_stats)
                self._diagnostic_blocks.append(
                    _format_shell_diagnostics(self._worker_stats, src_obj.name)
                )
                _store_batch_diagnostics(context, self._diagnostic_blocks)
            if not has_geometry:
                self._skipped += 1
                # A result with no geometry has to say why. This used to be a
                # silent skip, which is indistinguishable from the operator
                # never having run.
                report_text = _format_shell_diagnostics(
                    self._last_stats, src_obj.name
                )
                hint = _no_geometry_hint(self._last_stats)
                self._outcomes.append((src_obj.name, f"no geometry - {hint}"))
                if not self._diagnostic_blocks or report_text not in self._diagnostic_blocks:
                    self._diagnostic_blocks.append(report_text)
                _store_batch_diagnostics(context, self._diagnostic_blocks)
                print("\n=== DICOM mesh conversion produced no geometry ===")
                print(report_text)
                self.report(
                    {"WARNING"},
                    "{}: produced no geometry. {} Full diagnostics printed to the "
                    "console and copied by the Copy Diagnostics button.".format(
                        src_obj.name, hint
                    ),
                )
                self._target_index += 1
                self._stage = "start_next"
                return {"RUNNING_MODAL"}

            self._outcomes.append(
                (src_obj.name, f"meshed: {len(verts):,} vertices")
            )

            base = f"{self._prefix}{src_obj.name}"
            if len(verts) > 1_000_000:
                self.report(
                    {"INFO"},
                    "{}: building {:,} vertices".format(base, len(verts)),
                )

            if len(verts) > self._max_vertices:
                self._skipped += 1
                detail = _format_shell_diagnostics(self._last_stats, src_obj.name)
                detail += (
                    "\n[Skipped]\n  {}: {:,} vertices exceeds the {:,} "
                    "limit\n  Lower Resolution Multiplier, raise Min Island "
                    "Volume, or raise Max Vertices if memory allows.".format(
                        base, len(verts), self._max_vertices
                    )
                )
                self._outcomes.append(
                    (src_obj.name,
                     f"skipped: {len(verts):,} vertices over the "
                     f"{self._max_vertices:,} limit")
                )
                self._diagnostic_blocks.append(detail)
                _store_batch_diagnostics(context, self._diagnostic_blocks)
                print(
                    "\n=== DICOM mesh conversion skipped an oversized mesh ==="
                )
                print(detail)
                self.report(
                    {"WARNING"},
                    "{}: {:,} vertices is past the {:,} limit, so it was skipped "
                    "rather than left building indefinitely. Lower Resolution "
                    "Multiplier, raise Min Island Volume, or raise Max Vertices if "
                    "you have the memory.".format(
                        base, len(verts), self._max_vertices
                    ),
                )
                self._target_index += 1
                self._stage = "start_next"
                return {"RUNNING_MODAL"}

            mesh = bpy.data.meshes.new(f"{base}_Mesh")
            _build_mesh_fast(mesh, verts, faces)

            if self._smooth_strength > 0.0:
                _apply_detail_preserving_smoothing(
                    mesh,
                    self._smooth_strength,
                    edges=_edges_from_faces(faces),
                )

            out_obj = bpy.data.objects.new(base, mesh)
            if src_obj.users_collection:
                for col in src_obj.users_collection:
                    col.objects.link(out_obj)
            else:
                context.collection.objects.link(out_obj)

            out_obj.matrix_world = src_obj.matrix_world.copy()
            out_obj["dicom_hull_generated"] = True
            out_obj["dicom_hull_source"] = src_obj.name
            self._created += 1

            if self._hide_source:
                src_obj.hide_set(True)

            self._target_index += 1
            self._stage = "start_next"
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}


class _PointCloudWorkerOperator(bpy.types.Operator):
    """Shared modal scaffolding for threaded point-cloud reconstruction.

    Reconstruction takes seconds to minutes on real scans, so it runs on a
    worker thread while a timer-driven modal loop reports progress and watches
    for ESC. Only the final scene mutation happens on the main thread - Blender
    data cannot safely be touched from the worker.

    Subclasses implement ``_compute`` (worker thread, numpy only) and
    ``_apply_result`` (main thread, may touch bpy.data).
    """

    bl_options = {"REGISTER", "UNDO"}

    _stage_label = "Working"

    def _compute(self, coords, intensities, settings, props_snapshot, report_progress):
        raise NotImplementedError

    def _apply_result(self, context, source_obj, result, props):
        raise NotImplementedError

    def _snapshot_props(self, props) -> dict:
        return {}

    def invoke(self, context, event):
        global ACTIVE_POINTCLOUD_WORKER
        props = context.scene.dicom_import_props

        if ACTIVE_POINTCLOUD_WORKER is not None:
            self.report({"WARNING"}, "Another point cloud operation is already running")
            return {"CANCELLED"}

        # Every selected cloud is processed, one after another. Running them in
        # sequence rather than in parallel keeps peak memory to a single
        # reconstruction, which is what actually limits how large a cloud can be.
        sources = [obj for obj in _get_selected_pointclouds(context) if obj is not None]
        sources = [obj for obj in sources if len(obj.data.points) >= 4]
        if not sources:
            self.report({"ERROR"}, "Select at least one point cloud with 4 or more points")
            return {"CANCELLED"}

        self._queue = sources
        self._queue_index = 0
        self._created_names = []
        self._failures = []
        self._settings = _shell_settings_from_props(props)
        self._snapshot = self._snapshot_props(props)
        self._cancel_requested = False
        self._timer = None
        self._source = None

        props.mesh_conversion_running = True
        props.mesh_progress_percent = 0.0
        ACTIVE_POINTCLOUD_WORKER = self
        context.window_manager.progress_begin(0.0, 100.0)
        _set_mesh_progress(context, 0.0, self._stage_label)

        if not self._start_next(context):
            self._finish(context, cancelled=True)
            return {"CANCELLED"}

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _start_next(self, context):
        """Kick off the worker for the next queued cloud. False if none remain."""
        while self._queue_index < len(self._queue):
            source = self._queue[self._queue_index]
            try:
                coords, intensities = _read_pointcloud_arrays(source)
            except Exception as exc:
                self._failures.append(f"{source.name}: {exc}")
                self._queue_index += 1
                continue

            self._source = source
            self._done = False
            self._error = None
            self._result = None
            self._progress = 0.0
            self._message = f"{self._stage_label}: {source.name}"

            def _report(percent, message=""):
                self._progress = max(self._progress, float(percent))
                if message:
                    self._message = f"{source.name}: {message}"

            def _runner():
                try:
                    self._result = self._compute(
                        coords, intensities, self._settings, self._snapshot, _report
                    )
                except Exception as exc:
                    self._error = str(exc)
                finally:
                    self._done = True

            self._thread = threading.Thread(target=_runner, daemon=True)
            self._thread.start()
            return True
        return False

    def _overall_progress(self):
        """Blend this cloud's progress into the whole queue's."""
        total = max(1, len(self._queue))
        span = 100.0 / float(total)
        return min(100.0, self._queue_index * span + span * (self._progress / 100.0))

    def _finish(self, context, cancelled: bool = False):
        global ACTIVE_POINTCLOUD_WORKER
        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        try:
            context.window_manager.progress_end()
        except Exception:
            pass
        try:
            context.scene.dicom_import_props.mesh_conversion_running = False
        except Exception:
            pass
        ACTIVE_POINTCLOUD_WORKER = None

    def modal(self, context, event):
        if event.type == "ESC":
            self._cancel_requested = True

        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        # The worker cannot be interrupted mid-numpy-call, so cancellation waits
        # for it to return rather than leaving a thread writing into arrays the
        # main thread has moved on from.
        if self._cancel_requested and self._done:
            self._finish(context, cancelled=True)
            context.scene.dicom_import_props.status = "Cancelled"
            self.report({"WARNING"}, "Cancelled")
            return {"CANCELLED"}

        if not self._done:
            label = self._message
            if self._cancel_requested:
                label = f"Finishing current step before cancel: {label}"
            _set_mesh_progress(context, self._overall_progress(), label)
            return {"RUNNING_MODAL"}

        props = context.scene.dicom_import_props
        source = self._source

        if self._error:
            # One bad cloud must not abandon the rest of the selection.
            self._failures.append(f"{source.name}: {self._error}")
            self.report({"WARNING"}, f"{source.name}: {self._error}")
        else:
            if isinstance(self._result, dict):
                _report_shell_warnings(self, self._result.get("stats") or {})
            try:
                status = self._apply_result(context, source, self._result, props)
                self._created_names.append(source.name)
                self.report({"INFO"}, status)
            except Exception as exc:
                self._failures.append(f"{source.name}: {exc}")
                self.report({"WARNING"}, f"{source.name}: {exc}")

        self._queue_index += 1
        if self._start_next(context):
            _set_mesh_progress(context, self._overall_progress(), self._message)
            return {"RUNNING_MODAL"}

        _set_mesh_progress(context, 100.0, "Complete")
        self._finish(context, cancelled=False)

        done = len(self._created_names)
        summary = f"Processed {done} of {len(self._queue)} point cloud(s)"
        if self._failures:
            summary += f"; {len(self._failures)} failed"
        props.status = summary
        if done == 0:
            self.report({"ERROR"}, summary)
            return {"CANCELLED"}
        self.report({"INFO"}, summary)
        return {"FINISHED"}


class DICOM_OT_pointcloud_extract_surface(_PointCloudWorkerOperator):
    bl_idname = "dicom.pointcloud_extract_surface"
    bl_label = "Keep Only Surface Points"
    bl_description = (
        "Create a point cloud containing only points that are not surrounded on all "
        "sides. Interior points are treated as bulk density and discarded, while points "
        "lining an enclosed void are kept"
    )

    _stage_label = "Selecting surface points"

    def _snapshot_props(self, props) -> dict:
        return {"suffix": str(props.pc_shell_output_suffix)}

    def _compute(self, coords, intensities, settings, snapshot, report_progress):
        from .surface import select_surface_points

        keep, stats = select_surface_points(coords, intensities, settings, progress_cb=report_progress)
        return {
            "points": coords[keep],
            "intensities": (intensities[keep] if intensities is not None else None),
            "stats": stats,
        }

    def _apply_result(self, context, source_obj, result, props):
        points = result["points"]
        if int(points.shape[0]) == 0:
            raise ValueError(
                "No surface points found. Increase Shell Thickness, or lower Min Blob Voxels"
            )

        values = result["intensities"]
        if values is None:
            values = np.ones(points.shape[0], dtype=np.float32)

        stats = result["stats"]
        spacing = stats.get("source_spacing", (1.0, 1.0, 1.0))
        name = _make_unique_object_name(f"{source_obj.name}{self._snapshot['suffix']}")

        obj = _create_point_cloud_object(
            context, points, values, spacing, props, object_name=name, apply_stride=False
        )
        obj.matrix_world = source_obj.matrix_world.copy()
        obj["dicom_pointcloud_imported"] = True
        obj["dicom_surface_source"] = source_obj.name
        for key in ("dicom_source_path", "dicom_source_is_zip", "dicom_series_uid"):
            if key in source_obj:
                obj[key] = source_obj[key]

        removed = int(stats.get("removed_points", 0))
        total = int(stats.get("input_points", 0)) or 1
        cavities = int(stats.get("cavity_count", 0))
        return (
            f"Kept {points.shape[0]:,} surface points, removed {removed:,} interior "
            f"({100.0 * removed / total:.1f}%); {cavities} cavity/cavities lined"
        )


class DICOM_OT_pointcloud_upsample(_PointCloudWorkerOperator):
    bl_idname = "dicom.pointcloud_upsample"
    bl_label = "Increase Point Cloud Resolution"
    bl_description = (
        "Reconstruct the cloud's surface as a continuous field and resample it on a "
        "finer, optionally isotropic lattice. Output points sit on interpolated field "
        "crossings, so they are sub-voxel accurate rather than snapped to the source grid"
    )

    _stage_label = "Reconstructing at higher resolution"

    def _snapshot_props(self, props) -> dict:
        return {
            "suffix": str(props.pc_upsample_output_suffix),
            "mode": str(props.pc_upsample_mode),
            "max_points": int(props.pc_upsample_max_points),
        }

    def _compute(self, coords, intensities, settings, snapshot, report_progress):
        from .surface import upsample_pointcloud

        points, values, stats = upsample_pointcloud(
            coords,
            intensities,
            settings,
            mode=snapshot["mode"],
            max_points=snapshot["max_points"],
            progress_cb=report_progress,
        )
        return {"points": points, "intensities": values, "stats": stats}

    def _apply_result(self, context, source_obj, result, props):
        points = result["points"]
        values = result["intensities"]
        stats = result["stats"]
        spacing = stats.get("fine_spacing", (1.0, 1.0, 1.0))

        name = _make_unique_object_name(f"{source_obj.name}{self._snapshot['suffix']}")
        obj = _create_point_cloud_object(
            context, points, values, spacing, props, object_name=name, apply_stride=False
        )
        obj.matrix_world = source_obj.matrix_world.copy()
        obj["dicom_pointcloud_imported"] = True
        obj["dicom_upsample_source"] = source_obj.name
        for key in ("dicom_source_path", "dicom_source_is_zip", "dicom_series_uid"):
            if key in source_obj:
                obj[key] = source_obj[key]

        gain = float(stats.get("density_gain", 0.0))
        return (
            f"Created {points.shape[0]:,} points ({gain:.2f}x density) - "
            + _format_shell_report(stats)
        )


class DICOM_OT_cancel_mesh_conversion(bpy.types.Operator):
    bl_idname = "dicom.cancel_mesh_conversion"
    bl_label = "Stop Mesh Conversion"
    bl_description = "Stop the current point-cloud conversion or reconstruction"

    def execute(self, context):
        op = ACTIVE_MESH_CONVERSION_OPERATOR or ACTIVE_POINTCLOUD_WORKER
        props = context.scene.dicom_import_props
        if op is None:
            props.mesh_conversion_running = False
            self.report({"WARNING"}, "Nothing is running")
            return {"CANCELLED"}

        op._cancel_requested = True
        self.report({"INFO"}, "Stop requested")
        return {"FINISHED"}


class DICOM_OT_create_filtered_pointcloud(bpy.types.Operator):
    bl_idname = "dicom.create_filtered_pointcloud"
    bl_label = "Create Filtered Point Cloud"
    bl_description = "Create a second point cloud by removing darkest or lightest intensity values"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.dicom_import_props
        src_obj = _resolve_source_pointcloud_for_filter(context)
        if src_obj is None:
            self.report({"ERROR"}, "No source point cloud found")
            return {"CANCELLED"}

        cloud = src_obj.data
        point_count = len(cloud.points)
        if point_count < 8:
            self.report({"ERROR"}, "Source point cloud has too few points")
            return {"CANCELLED"}

        values = _extract_cloud_intensity_values(cloud)
        if values is None or values.shape[0] != point_count:
            self.report({"ERROR"}, "Source cloud has no usable intensity data")
            return {"CANCELLED"}

        remove_pct = max(0.0, min(99.0, float(props.pc_filter_remove_percent))) / 100.0
        remove_count = int(round(remove_pct * point_count))
        remove_count = max(0, min(point_count - 4, remove_count))

        order = np.argsort(values)
        mask = np.ones(point_count, dtype=bool)
        if remove_count > 0:
            if bool(props.pc_filter_invert):
                remove_idx = order[-remove_count:]
            else:
                remove_idx = order[:remove_count]
            mask[remove_idx] = False

        kept_count = int(np.count_nonzero(mask))
        if kept_count < 4:
            self.report({"ERROR"}, "Filtering removed too many points")
            return {"CANCELLED"}

        coords = np.empty(point_count * 3, dtype=np.float32)
        cloud.points.foreach_get("co", coords)
        coords = coords.reshape((-1, 3))

        radii = np.empty(point_count, dtype=np.float32)
        cloud.points.foreach_get("radius", radii)
        source_radius = float(np.median(radii)) if radii.size else 0.001

        kept_points = coords[mask]
        kept_values = values[mask]

        name_base = f"{src_obj.name}{props.pc_filter_output_suffix}"
        object_name = _make_unique_object_name(name_base)
        out_obj = _create_point_cloud_object(
            context=context,
            points=kept_points,
            intensities=kept_values,
            spacing=(1.0, 1.0, 1.0),
            props=props,
            object_name=object_name,
        )

        try:
            out_obj.data.points.foreach_set("radius", np.full(kept_count, source_radius, dtype=np.float32))
        except Exception:
            pass

        try:
            context.collection.objects.unlink(out_obj)
        except Exception:
            pass
        if src_obj.users_collection:
            for col in src_obj.users_collection:
                col.objects.link(out_obj)
        else:
            context.collection.objects.link(out_obj)

        out_obj.matrix_world = src_obj.matrix_world.copy()
        out_obj["dicom_source_path"] = src_obj.get("dicom_source_path", "")
        out_obj["dicom_source_is_zip"] = bool(src_obj.get("dicom_source_is_zip", False))
        out_obj["dicom_series_uid"] = src_obj.get("dicom_series_uid", "")
        out_obj["dicom_pointcloud_imported"] = True
        _copy_lattice(src_obj, out_obj)

        mode_txt = "lightest" if bool(props.pc_filter_invert) else "darkest"
        props.status = f"Created {out_obj.name}: removed {remove_count} {mode_txt} points"
        self.report({"INFO"}, props.status)
        return {"FINISHED"}


class DICOM_OT_scan_series(bpy.types.Operator):
    bl_idname = "dicom.scan_series"
    bl_label = "Scan Series"
    bl_description = "Scan source and list DICOM series"

    def execute(self, context):
        props = context.scene.dicom_import_props

        try:
            from .io_dicom import discover_series
            from .panel import NO_SERIES
        except ModuleNotFoundError as exc:
            self.report({"ERROR"}, f"Missing dependency: {exc.name}. Install requirements in Blender Python.")
            props.status = f"Missing dependency: {exc.name}"
            return {"CANCELLED"}

        if not props.source_path:
            self.report({"ERROR"}, "Set Source Path first")
            return {"CANCELLED"}

        # Blender cannot redraw while an operator's execute() runs, so a long
        # scan looks exactly like a hang. The busy cursor at least says the
        # application is working rather than dead.
        scan_stats = {}
        window = getattr(context, "window", None)
        if window is not None and hasattr(window, "cursor_set"):
            try:
                window.cursor_set("WAIT")
            except Exception:
                window = None
        started = time.monotonic()
        try:
            series = discover_series(props.source_path, props.source_is_zip, stats=scan_stats)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            props.status = f"Scan failed: {exc}"
            return {"CANCELLED"}
        finally:
            if window is not None:
                try:
                    window.cursor_set("DEFAULT")
                except Exception:
                    pass
        elapsed = time.monotonic() - started
        scanned = int(scan_stats.get("files_scanned", 0) or 0)
        rate = scanned / elapsed if elapsed > 0.01 else 0.0
        # Reported rather than left to guesswork: when a scan is slow, whether
        # it is the file count or the per-file cost decides what to do about it.
        print(f"[DICOM] scanned {scanned:,} files in {elapsed:.1f}s "
              f"({rate:,.0f} files/s), {len(series)} series")

        # Previews are built here rather than on demand: the series names in
        # this data differ by a few characters across a hundred-odd entries, so
        # the list is close to unusable without them.
        thumbnails = {}
        try:
            from . import previews

            thumbnails = previews.build(props.source_path, props.source_is_zip,
                                        series)
        except Exception as exc:
            print(f"[DICOM] previews unavailable: {exc}")

        props.series_items.clear()
        for item in series:
            entry = props.series_items.add()
            entry.uid = item.uid
            entry.label = item.label
            entry.thumbnail = thumbnails.get(str(item.uid), "")

        # Assigning to a dynamic enum can fail if the items callback has not
        # caught up with series_items yet, and a failure here should not lose
        # the scan results that were just stored.
        def _select(uid):
            try:
                props.series_uid = uid
                return True
            except (TypeError, ValueError):
                return False

        if series:
            _select(series[0].uid)
            props.status = (
                f"Found {len(series)} series in {scanned:,} files "
                f"({elapsed:.1f}s)"
            )
            self.report({"INFO"}, props.status)
            return {"FINISHED"}

        _select(NO_SERIES)
        looked_at = int(scan_stats.get("files_scanned", 0))
        readable = int(scan_stats.get("dicom_files", 0))
        detail = f"No DICOM series found in {looked_at} file(s)"
        if looked_at and not readable:
            kinds = scan_stats.get("extensions") or {}
            listed = ", ".join(
                f"{count} {ext or 'no extension'}"
                for ext, count in sorted(kinds.items(), key=lambda kv: -kv[1])[:4]
            )
            detail += f" - none were DICOM"
            if listed:
                detail += f" ({listed})"
        elif readable:
            detail += f" - {readable} file(s) parsed as DICOM but carried no SeriesInstanceUID"
        props.status = detail
        self.report({"WARNING"}, detail)
        return {"CANCELLED"}


def _load_series_cloud(props, uid, enhance=True):
    """Load one series and turn it into points, intensities and a note.

    Shared by the single import and the by-contrast batch import so the two
    cannot drift apart - the batch one exists precisely because a study has
    many series, and having it reimplement thresholding or placement would be
    a second set of rules to keep in step.

    Returns ``(points, intensities, spacing, note, geometry_stats)``.
    """
    from .io_dicom import load_series_volume
    from .pointcloud import build_points_from_volume

    geometry_stats = {}
    volume, spacing = load_series_volume(
        props.source_path, props.source_is_zip, uid, stats=geometry_stats
    )

    note = ""
    resample_offset = None
    if enhance and bool(props.import_enhance_enabled):
        from .surface import enhance_volume

        volume, fine_grid, enhance_stats = enhance_volume(
            volume, spacing, settings=_import_settings_from_props(props)
        )
        if enhance_stats.get("resampled"):
            spacing = fine_grid.spacing
            resample_offset = tuple(float(v) for v in fine_grid.origin)
            shape = enhance_stats["fine_shape"]
            note = (f" (enhanced to {shape[2]}x{shape[1]}x{shape[0]}, "
                    f"step {min(spacing):.3g})")
            if enhance_stats.get("budget_reduced"):
                note += " - reduced to fit voxel budget"

    if bool(getattr(props, "shading_correct", False)):
        from .preprocessing import correct_shading

        volume = correct_shading(
            volume, spacing,
            sigma_mm=float(getattr(props, "shading_scale_mm", 20.0)))
        note += " (shading flattened)"

    origin = orientation = None
    if bool(getattr(props, "place_in_patient_space", False)):
        if geometry_stats.get("has_patient_geometry"):
            origin = geometry_stats.get("volume_origin")
            orientation = geometry_stats.get("volume_orientation")
            if origin is not None and resample_offset is not None:
                # The tag gives the centre of voxel zero, not the corner of
                # the box. Enhancement keeps the box and moves the centres, so
                # the tag no longer points at the first sample.
                from .pointcloud import shift_origin

                origin = shift_origin(origin, orientation, resample_offset)

    point_stats = {}
    points, intensities = build_points_from_volume(
        volume=volume,
        spacing=spacing,
        threshold=props.threshold,
        stride=props.stride,
        max_points=props.max_points,
        threshold_max=getattr(props, "threshold_max", 0.0),
        origin=origin,
        orientation=orientation,
        stats=point_stats,
    )
    # Recorded so the cloud can be put back on the grid it came from later.
    # Splitting one needs that, and it used to be written only by the
    # segmented import, so an ordinary import produced a cloud that could
    # never be split - "imported before this existed", about a cloud
    # imported a moment ago.
    from .pointcloud import lattice_used

    geometry_stats["lattice"] = lattice_used(
        volume.shape, spacing, origin, orientation,
        stride=int(point_stats.get("stride", props.stride) or 1))
    return (
        np.asarray(points, dtype=np.float32),
        np.asarray(intensities, dtype=np.float32).reshape(-1),
        spacing,
        note,
        geometry_stats,
    )




class DICOM_OT_import_point_cloud(bpy.types.Operator):
    bl_idname = "dicom.import_point_cloud"
    bl_label = "Import Point Cloud"
    bl_description = "Import selected DICOM series as a point cloud mesh"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.dicom_import_props

        try:
            from .io_dicom import load_series_volume
            from .pointcloud import build_points_from_volume
        except ModuleNotFoundError as exc:
            self.report({"ERROR"}, f"Missing dependency: {exc.name}. Install requirements in Blender Python.")
            props.status = f"Missing dependency: {exc.name}"
            return {"CANCELLED"}

        if not props.source_path:
            self.report({"ERROR"}, "Set Source Path first")
            return {"CANCELLED"}

        from .panel import has_series_selected

        if not has_series_selected(props):
            self.report({"ERROR"}, "Scan and select a series first")
            return {"CANCELLED"}

        try:
            points, intensities, spacing, enhance_note, geometry_stats = (
                _load_series_cloud(props, props.series_uid)
            )

            # Said before anything else, because a series that cannot support a
            # 3D reconstruction produces a point cloud that looks perfectly fine
            # and then fails to mesh for reasons that look like settings.
            found = list(geometry_stats.get("geometry_warnings", []) or [])
            for message in found:
                self.report({"WARNING"}, message)
            _popup_warnings(context, "Check this series", found)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            props.status = f"Import failed: {exc}"
            return {"CANCELLED"}

        point_count = int(points.shape[0]) if points.ndim >= 1 else 0
        if point_count == 0:
            self.report({"WARNING"}, "No points above threshold")
            props.status = "No points produced. Lower threshold."
            return {"CANCELLED"}

        if bool(props.safe_mode) and point_count > int(props.safe_cap_points):
            rng = np.random.default_rng(42)
            keep = rng.choice(point_count, size=int(props.safe_cap_points), replace=False)
            points = points[keep]
            intensities = intensities[keep]
            self.report({"WARNING"}, f"Safe Mode capped points to {props.safe_cap_points} for stability")

        obj = _create_point_cloud_object(context, points, intensities, spacing, props)

        # Persist source metadata for later segmentation-from-selection workflows.
        if obj is not None and obj.type == "POINTCLOUD":
            obj["dicom_source_path"] = props.source_path
            obj["dicom_source_is_zip"] = bool(props.source_is_zip)
            obj["dicom_series_uid"] = props.series_uid
            _store_lattice(obj, geometry_stats.get("lattice"))

        props.status = f"Imported {points.shape[0]:,} points{enhance_note}"
        self.report({"INFO"}, props.status)
        return {"FINISHED"}







# --------------------------------------------------------------------------
# Volume view
# --------------------------------------------------------------------------

def _volume_cache_dir(props):
    """Where converted volumes live, made if it is not there yet.

    One folder for everything rather than a folder per study: the files are
    named by a hash of what is in them, so there is nothing to collide, and a
    single location is one thing to point at when it needs clearing.
    """
    import os
    import tempfile

    chosen = str(getattr(props, "volume_cache_dir", "") or "").strip()
    if chosen:
        path = bpy.path.abspath(chosen)
    else:
        path = os.path.join(tempfile.gettempdir(), "dicom_volume_cache")
    os.makedirs(path, exist_ok=True)
    return path


def _apply_volume_quality(context, props):
    """Make EEVEE draw volumes at full resolution rather than an eighth.

    Blender's default volume resolution is 1/8 of the screen, which is sized
    for atmospheric haze rather than for a scan with millimetre detail in it.
    Measured on a chest CT, going to full resolution was 15.6 times sharper by
    variance of the Laplacian - and faster, because the coarse pass spends its
    time on tiles that are then thrown away.

    Returns a note when something was changed, so a scene-level change is
    never silent.
    """
    eevee = getattr(context.scene, "eevee", None)
    if eevee is None or not bool(getattr(props, "volume_sharp_display", True)):
        return ""
    was = str(getattr(eevee, "volumetric_tile_size", "1"))
    if was == "1":
        return ""
    try:
        eevee.volumetric_tile_size = "1"
    except Exception:
        return ""
    return f"volume resolution raised from 1/{was} to full"


def _volume_range_warning(context, obj):
    """A custom volumetric range shorter than the scan hides it completely.

    The default range follows the camera clipping, which is right. But the
    custom range defaults to 100 units, and a CT is some 370 units across, so
    switching it on without changing it makes the volume disappear rather than
    look wrong - measured as nothing at all rendering.
    """
    eevee = getattr(context.scene, "eevee", None)
    if eevee is None or not bool(getattr(eevee, "use_volume_custom_range",
                                         False)):
        return ""
    try:
        from mathutils import Vector

        corners = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    except Exception:
        return ""
    extent = max(
        (a - b).length for a in corners for b in corners) if corners else 0.0
    end = float(getattr(eevee, "volumetric_end", 0.0))
    if extent > end:
        return ("The scene uses a custom volume range ending at {:.0f} units, "
                "but this scan is {:.0f} units across, so most of it will not "
                "be drawn. Turn off Render > Volumes > Custom Range, or raise "
                "its End past {:.0f}.".format(end, extent, extent))
    return ""


def _volume_material(name, props, window):
    """A transfer function: scan value in, something you can see out.

    The grid holds a window mapped onto 0..1, so the ramp here is positioned
    in those terms and the window is what gives them meaning. The cut is done
    in the shader as well as in the viewport display, because the display
    slice is viewport-only - measured as exactly zero difference in a render,
    in both EEVEE and Cycles - and a volume cut on screen but whole in the
    render reads as a bug rather than a setting.
    """
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    tree = mat.node_tree
    for node in list(tree.nodes):
        tree.nodes.remove(node)

    out = tree.nodes.new("ShaderNodeOutputMaterial")
    out.location = (600, 0)
    principled = tree.nodes.new("ShaderNodeVolumePrincipled")
    principled.location = (340, 0)

    info = tree.nodes.new("ShaderNodeVolumeInfo")
    info.location = (-620, 0)

    ramp = tree.nodes.new("ShaderNodeValToRGB")
    ramp.location = (-400, -40)
    ramp.name = "DICOM Transfer"
    ramp.label = "Transfer Function"
    # Dark and transparent at the bottom of the window, bright and solid at
    # the top. Two stops is enough to read a scan; more is a matter of taste
    # and this is meant to be edited.
    ramp.color_ramp.elements[0].position = 0.08
    ramp.color_ramp.elements[0].color = (0.05, 0.03, 0.02, 1.0)
    ramp.color_ramp.elements[1].position = 0.78
    ramp.color_ramp.elements[1].color = (1.0, 0.96, 0.9, 1.0)

    density = tree.nodes.new("ShaderNodeValue")
    density.location = (-400, 220)
    density.name = "DICOM Density"
    density.label = "Density"
    density.outputs[0].default_value = float(
        getattr(props, "volume_density", 4.0))

    # The cut: anything on the far side of the plane has its density zeroed.
    cut_depth = tree.nodes.new("ShaderNodeValue")
    cut_depth.location = (-620, -300)
    cut_depth.name = "DICOM Cut Depth"
    cut_depth.label = "Cut Depth"
    cut_depth.outputs[0].default_value = float(
        getattr(props, "volume_cut_depth", 0.5))

    cut_on = tree.nodes.new("ShaderNodeValue")
    cut_on.location = (-620, -400)
    cut_on.name = "DICOM Cut Enable"
    cut_on.label = "Cut On"
    cut_on.outputs[0].default_value = (
        1.0 if getattr(props, "volume_cut_enabled", True) else 0.0)

    texco = tree.nodes.new("ShaderNodeTexCoord")
    texco.location = (-900, -180)

    # The axis is a vector rather than a choice of which socket to link, so
    # changing it later is setting three numbers. Linking one component of a
    # Separate XYZ would bake the axis into the graph at import, and the panel
    # could then move the depth but never the direction.
    axis_vec = tree.nodes.new("ShaderNodeCombineXYZ")
    axis_vec.location = (-900, -340)
    axis_vec.name = "DICOM Cut Axis"
    axis_vec.label = "Cut Axis"

    along = tree.nodes.new("ShaderNodeVectorMath")
    along.location = (-720, -220)
    along.operation = "DOT_PRODUCT"
    along.label = "Position along the cut axis"
    tree.links.new(texco.outputs["Generated"], along.inputs[0])
    tree.links.new(axis_vec.outputs["Vector"], along.inputs[1])

    # keep = cut is off, OR this voxel is on the near side of the plane
    side = tree.nodes.new("ShaderNodeMath")
    side.location = (-400, -300)
    side.operation = "LESS_THAN"
    side.name = "DICOM Cut Side"
    side.label = "Which side of the cut to keep"
    tree.links.new(along.outputs["Value"], side.inputs[0])
    tree.links.new(cut_depth.outputs[0], side.inputs[1])

    off = tree.nodes.new("ShaderNodeMath")
    off.location = (-400, -460)
    off.operation = "SUBTRACT"
    off.inputs[0].default_value = 1.0
    tree.links.new(cut_on.outputs[0], off.inputs[1])

    keep = tree.nodes.new("ShaderNodeMath")
    keep.location = (-220, -380)
    keep.operation = "MAXIMUM"
    keep.label = "Keep this voxel"
    tree.links.new(side.outputs[0], keep.inputs[0])
    tree.links.new(off.outputs[0], keep.inputs[1])

    # Between the grid and the density: this is what decides whether the
    # scan reads as fog or as objects with edges. Widening the range it maps
    # across softens the boundary, narrowing it to almost nothing turns the
    # volume into a surface at that level.
    shaped = tree.nodes.new("ShaderNodeMapRange")
    shaped.location = (-220, 160)
    shaped.name = "DICOM Level"
    shaped.label = "Surface Level"
    shaped.clamp = True
    tree.links.new(info.outputs["Density"], shaped.inputs["Value"])

    scaled = tree.nodes.new("ShaderNodeMath")
    scaled.location = (-40, 140)
    scaled.operation = "MULTIPLY"
    tree.links.new(shaped.outputs["Result"], scaled.inputs[0])
    tree.links.new(density.outputs[0], scaled.inputs[1])

    gated = tree.nodes.new("ShaderNodeMath")
    gated.location = (140, 60)
    gated.operation = "MULTIPLY"
    gated.label = "Density after the cut"
    tree.links.new(scaled.outputs[0], gated.inputs[0])
    tree.links.new(keep.outputs[0], gated.inputs[1])

    tree.links.new(shaped.outputs["Result"], ramp.inputs["Fac"])
    tree.links.new(ramp.outputs["Color"], principled.inputs["Color"])
    tree.links.new(gated.outputs[0], principled.inputs["Density"])
    tree.links.new(principled.outputs["Volume"], out.inputs["Volume"])

    mat["dicom_window_low"] = float(window[0])
    mat["dicom_window_high"] = float(window[1])

    # One place decides what the cut nodes hold, so import and a later change
    # cannot disagree about it.
    _push_cut_to_material_target(mat, props)
    return mat


def _push_cut_to_material_target(mat, props):
    """Write the panel's cut settings into one material's nodes."""
    if mat is None or not mat.use_nodes:
        return
    nodes = mat.node_tree.nodes
    axis = str(getattr(props, "volume_cut_axis", "AUTO"))
    enabled = bool(getattr(props, "volume_cut_enabled", True))

    node = nodes.get("DICOM Cut Depth")
    if node is not None:
        node.outputs[0].default_value = float(
            getattr(props, "volume_cut_depth", 0.5))
    node = nodes.get("DICOM Density")
    if node is not None:
        node.outputs[0].default_value = float(
            getattr(props, "volume_density", 4.0))

    node = nodes.get("DICOM Level")
    if node is not None:
        level = float(getattr(props, "volume_level", 0.35))
        hardness = float(getattr(props, "volume_hardness", 0.75))
        # Hardness is the width of the transition, inverted: a wide band is a
        # soft fog, a band of almost nothing is a surface. The floor keeps it
        # from collapsing to zero width, which would alias badly.
        half = max(0.002, (1.0 - hardness) * 0.5)
        low = max(0.0, level - half)
        high = min(1.0, level + half)
        if high - low < 0.002:
            high = min(1.0, low + 0.002)
        node.inputs["From Min"].default_value = low
        node.inputs["From Max"].default_value = high
        node.inputs["To Min"].default_value = 0.0
        node.inputs["To Max"].default_value = 1.0

    node = nodes.get("DICOM Cut Axis")
    if node is not None:
        vector = {"X": (1.0, 0.0, 0.0), "Y": (0.0, 1.0, 0.0)}.get(
            axis, (0.0, 0.0, 1.0))
        for socket, value in zip(node.inputs, vector):
            socket.default_value = float(value)

    node = nodes.get("DICOM Cut Side")
    if node is not None:
        # Same plane, other half: the comparison is what decides which side
        # survives, so flipping is a change of operation rather than of any
        # of the numbers.
        node.operation = ("GREATER_THAN"
                          if bool(getattr(props, "volume_cut_flip", False))
                          else "LESS_THAN")

    node = nodes.get("DICOM Cut Enable")
    if node is not None:
        # Auto turns the viewport cut to face the view, and a render has no
        # single view to face - so rather than quietly cutting along some
        # axis the user did not choose, a render of an Auto cut shows the
        # whole volume. Picking X, Y or Z cuts both.
        in_render = enabled and axis in {"X", "Y", "Z"}
        node.outputs[0].default_value = 1.0 if in_render else 0.0


def _build_volume_file(props, uid, report=None):
    """DICOM series -> a .vdb in the cache. Returns (path, info)."""
    import os

    from .io_dicom import load_series_volume
    from .volume import (cache_name, centred_placement, resolve_window,
                         to_unit, write_grid)

    say = report or (lambda *_a, **_k: None)
    say("Reading the series")
    stats = {}
    # Deliberately not enhanced: a volume renderer interpolates the field
    # itself, so resampling first costs memory and adds nothing.
    raw, spacing = load_series_volume(
        props.source_path, props.source_is_zip, uid, stats=stats)

    modality = str(stats.get("modality") or "").upper()
    is_ct = modality == "CT" or bool(getattr(props, "muscle_ct_mode", False))
    low, high, window_note = resolve_window(
        raw, getattr(props, "volume_window", "AUTO"), is_ct=is_ct)

    label = str(stats.get("series_description") or "volume")
    half = bool(getattr(props, "volume_half_float", True))

    placed = bool(getattr(props, "place_in_patient_space", False))
    if placed and stats.get("has_patient_geometry"):
        origin = stats.get("volume_origin")
        orientation = stats.get("volume_orientation")
    else:
        origin, orientation = centred_placement(raw.shape, spacing)

    # The transform goes into the name: the same series placed two ways is two
    # different files, and reusing one for the other moves the scan.
    from .volume import transform_matrix

    path = os.path.join(
        _volume_cache_dir(props),
        cache_name(uid, low, high, half, label,
                   placement=transform_matrix(spacing, origin, orientation)))

    if os.path.exists(path):
        say("Already converted")
        return path, {"cached": True, "window": (low, high),
                      "shape": tuple(int(v) for v in raw.shape),
                      "bytes": int(os.path.getsize(path)),
                      "window_note": window_note,
                      "warnings": list(stats.get("geometry_warnings") or [])}

    say("Windowing")
    unit = to_unit(raw, low, high)
    say("Writing the volume")
    info = write_grid(path, unit, spacing, origin, orientation, half=half)
    info["cached"] = False
    info["window"] = (low, high)
    info["window_note"] = window_note
    info["warnings"] = list(stats.get("geometry_warnings") or [])
    return path, info


def _existing_volume(props, uid):
    """A volume already in the scene for this series, if there is one."""
    for obj in bpy.data.objects:
        if (obj.type == "VOLUME" and obj.get("dicom_volume")
                and str(obj.get("dicom_series_uid") or "") == str(uid)):
            return obj
    return None


def _place_volume(context, props, path, info, name, uid=""):
    """Import the .vdb and set it up the way the panel says.

    Re-uses the object already showing this series rather than adding a
    second one. Two volumes of the same scan occupy exactly the same space,
    so the newer one is hidden inside the older and changing the Window looks
    like it does nothing at all - which is how it was reported.
    """
    before = set(bpy.data.objects.keys())
    bpy.ops.object.volume_import(filepath=str(path))
    fresh = [n for n in bpy.data.objects.keys() if n not in before]
    if not fresh:
        return None
    obj = bpy.data.objects[fresh[0]]

    if bool(getattr(props, "volume_replace", True)):
        previous = _existing_volume(props, uid)
        if previous is not None and previous is not obj:
            # Move the new grid into the object that is already placed and
            # selected, then drop the carrier the importer made.
            stale = previous.data
            previous.data = obj.data
            previous.data.materials.clear()
            bpy.data.objects.remove(obj, do_unlink=True)
            if stale.users == 0:
                bpy.data.volumes.remove(stale)
            obj = previous
    obj.name = name

    obj["dicom_volume"] = True
    obj["dicom_source_path"] = str(props.source_path)
    obj["dicom_series_uid"] = str(props.series_uid)
    # Recorded so a value read off the grid can be turned back into the number
    # the scanner measured; the grid itself only holds 0..1.
    obj["dicom_window_low"] = float(info["window"][0])
    obj["dicom_window_high"] = float(info["window"][1])
    obj["dicom_vdb_path"] = str(path)

    data = obj.data
    try:
        data.display.use_slice = bool(props.volume_cut_enabled)
        data.display.slice_axis = str(props.volume_cut_axis)
        data.display.slice_depth = float(props.volume_cut_depth)
        data.display.interpolation_method = "LINEAR"
    except Exception:
        pass

    window = info["window"]
    data.materials.append(_volume_material(f"{name}_Transfer", props, window))
    return obj


def _volume_summary(info) -> str:
    size = info.get("bytes", 0) / 1024.0 / 1024.0
    shape = info.get("shape") or ()
    parts = []
    if shape:
        parts.append("x".join(str(int(v)) for v in reversed(shape)))
    parts.append(f"{size:.1f} MB")
    if info.get("cached"):
        parts.append("already converted")
    elif "occupancy" in info:
        parts.append(f"{100.0 * float(info['occupancy']):.1f}% of voxels kept")
    low, high = info.get("window", (0.0, 1.0))
    parts.append(f"window {low:.0f} to {high:.0f}")
    return " | ".join(parts)


class DICOM_OT_import_as_volume(bpy.types.Operator):
    bl_idname = "dicom.import_as_volume"
    bl_label = "Import As Volume"
    bl_description = (
        "Show the selected series as a volume rather than as points. Solid "
        "shading shows a cut through it; Rendered shading shows the volume "
        "itself"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .panel import has_series_selected

        props = context.scene.dicom_import_props
        if not has_series_selected(props):
            self.report({"ERROR"}, "Scan and select a series first")
            return {"CANCELLED"}

        try:
            import openvdb                                   # noqa: F401
        except ImportError:
            self.report({"ERROR"},
                        "This Blender has no OpenVDB module, so volumes "
                        "cannot be written")
            return {"CANCELLED"}

        wm = context.window_manager
        wm.progress_begin(0.0, 100.0)
        try:
            path, info = _build_volume_file(
                props, props.series_uid,
                report=lambda msg: setattr(props, "volume_status", msg))
        except Exception as exc:                             # noqa: BLE001
            wm.progress_end()
            props.volume_status = f"Failed: {exc}"
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        wm.progress_end()

        label = _series_label_for(props, props.series_uid)
        obj = _place_volume(context, props, path, info, label,
                            uid=props.series_uid)
        if obj is None:
            props.volume_status = "Blender did not create a volume object"
            self.report({"ERROR"}, props.volume_status)
            return {"CANCELLED"}

        notes = list(info.get("warnings") or [])
        if info.get("window_note"):
            notes.insert(0, str(info["window_note"]))
        raised = _apply_volume_quality(context, props)
        clipped = _volume_range_warning(context, obj)
        if clipped:
            notes.append(clipped)

        props.volume_status = _volume_summary(info)
        if raised:
            # A scene-level change, so it is said out loud rather than just
            # quietly done.
            props.volume_status += f" | {raised}"
        self.report({"INFO"}, props.volume_status)
        _popup_warnings(context, "Check this series", notes)
        return {"FINISHED"}


def _series_label_for(props, uid) -> str:
    """A short object name taken from the series description."""
    for item in getattr(props, "series_items", []):
        if getattr(item, "uid", "") == uid:
            # The label carries the tags the list shows - "[MR]", the slice
            # count - which belong in a list and not in an object name.
            text = str(getattr(item, "label", "") or "")
            return text.split("[")[0].strip()[:40] or "DICOMVolume"
    return "DICOMVolume"


class DICOM_OT_refresh_volume_look(bpy.types.Operator):
    bl_idname = "dicom.refresh_volume_look"
    bl_label = "Apply To Volumes"
    bl_description = (
        "Push the cut and density settings onto every volume already in the "
        "scene"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .panel import _push_volume_cut

        props = context.scene.dicom_import_props
        _push_volume_cut(props, context)
        raised = _apply_volume_quality(context, props)
        count = sum(1 for o in bpy.data.objects
                    if o.type == "VOLUME" and o.get("dicom_volume"))
        message = f"Updated {count} volume(s)"
        if raised:
            message += f", {raised}"
        self.report({"INFO"}, message)
        return {"FINISHED"}


class DICOM_OT_drop_volume(bpy.types.Operator):
    """Import whatever was dropped on the viewport as a volume.

    A DICOM series is a folder, not a file, and Blender's drop handling works
    on files - so what arrives here is one slice of something. The series it
    belongs to is found by indexing the folder it sits in, which is the same
    index the rest of the addon uses, and the whole series is converted. A zip
    is handled as a zip.
    """

    bl_idname = "dicom.drop_volume"
    bl_label = "Drop DICOM As Volume"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    directory: bpy.props.StringProperty(subtype="DIR_PATH")

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        import os

        from .panel import NO_SERIES

        dropped = str(self.filepath or "")
        if not dropped and self.directory:
            dropped = str(self.directory)
        if not dropped or not os.path.exists(dropped):
            self.report({"ERROR"}, "Nothing readable was dropped")
            return {"CANCELLED"}

        try:
            import openvdb                                   # noqa: F401
        except ImportError:
            self.report({"ERROR"},
                        "This Blender has no OpenVDB module, so volumes "
                        "cannot be written")
            return {"CANCELLED"}

        props = context.scene.dicom_import_props
        is_zip = dropped.lower().endswith(".zip")

        # A file that is not DICOM is refused here rather than quietly
        # standing in for its folder. Importing some unrelated series that
        # happened to sit beside it is a worse answer than saying no.
        if not is_zip and os.path.isfile(dropped):
            from .io_dicom import looks_like_dicom

            if not looks_like_dicom(dropped):
                known = {
                    ".z": "Unix compressed (.Z)",
                    ".gz": "gzip",
                    ".tar": "a tar archive",
                    ".nii": "NIfTI",
                    ".raw": "raw binary",
                }
                suffix = os.path.splitext(dropped)[1].lower()
                what = known.get(suffix, "not a format this reads")
                self.report(
                    {"ERROR"},
                    "{} is {}, not DICOM. Drop a .dcm or a .zip of a study, "
                    "or set Source Path to the folder and use Scan "
                    "Series.".format(os.path.basename(dropped), what))
                return {"CANCELLED"}
        # A dropped slice stands for the folder it came from: one slice on its
        # own is a single image, and nobody drags a scan in wanting that.
        source = dropped if (is_zip or os.path.isdir(dropped)) \
            else os.path.dirname(dropped)

        props.source_path = source
        props.source_is_zip = bool(is_zip)

        try:
            from .io_dicom import discover_series

            found = [item for item in discover_series(source, bool(is_zip))
                     if not item.localizer]
        except Exception as exc:                             # noqa: BLE001
            self.report({"ERROR"}, f"Could not read that: {exc}")
            return {"CANCELLED"}

        if not found:
            self.report({"ERROR"},
                        "No usable series there - only localizers, or not "
                        "DICOM at all")
            return {"CANCELLED"}

        chosen = found[0]
        if not is_zip and os.path.isfile(dropped):
            # Prefer the series the dropped file is actually part of.
            try:
                from .io_dicom import _series_file_index

                index = _series_file_index(source)
                target = os.path.normcase(os.path.abspath(dropped))
                for uid, paths in index.items():
                    if any(os.path.normcase(os.path.abspath(str(p))) == target
                           for p in paths):
                        match = next((f for f in found if f.uid == uid), None)
                        if match is not None:
                            chosen = match
                        break
            except Exception:
                pass

        props.series_uid = chosen.uid
        if props.series_uid == NO_SERIES:
            self.report({"ERROR"}, "Could not identify a series")
            return {"CANCELLED"}

        try:
            return bpy.ops.dicom.import_as_volume()
        except RuntimeError as exc:
            # The inner operator reports its own error; re-raising it here
            # only adds a traceback on top of a message already shown.
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


# Drag-and-drop arrived in Blender 4.1. Everything this addon targets has it,
# but it is a convenience rather than the feature, so a Blender without it
# should lose the drop handler and keep the addon.
_FileHandlerBase = getattr(bpy.types, "FileHandler", None)
HAS_FILE_HANDLER = _FileHandlerBase is not None
if _FileHandlerBase is None:                      # pragma: no cover
    _FileHandlerBase = type("_NoFileHandler", (), {})


class DICOM_FH_drop(_FileHandlerBase):
    """Lets a .dcm or a .zip be dragged straight onto the 3D viewport.

    Extensionless DICOM files - which are common - cannot be registered for,
    because the handler matches on extension. Those still have to go through
    Scan Series.
    """

    bl_idname = "DICOM_FH_drop"
    bl_label = "DICOM Volume"
    bl_import_operator = "dicom.drop_volume"
    bl_file_extensions = ".dcm;.DCM;.ima;.IMA;.zip"

    @classmethod
    def poll_drop(cls, context):
        return (getattr(context, "area", None) is not None
                and context.area.type == "VIEW_3D")



CUT_GROUP = "DICOM Volume Cut"


def _volume_cut_node_group(name):
    """A node group that drops the faces past the cut plane.

    Geometry Nodes rather than a boolean: measured on a 470k vertex surface,
    deleting faces takes 0.04s, a boolean intersect against a box takes about
    half a second with the float solver and over a minute with the exact one.
    Only the first is quick enough to drag a slider against. The surface is
    left open at the cut rather than capped, which is what most scan viewers
    show anyway.

    One group per surface, and the plane lives on the nodes inside it rather
    than on modifier inputs. Modifier inputs would let a single group be
    shared, but writing to them raises "id properties not supported for this
    type" for the vector, and a half-written plane means a Threshold left at
    its default of zero - which deletes every face of a scan sitting at a z
    of 1500, so the whole object vanishes.
    """
    tree = bpy.data.node_groups.new(name, "GeometryNodeTree")
    tree.interface.new_socket("Geometry", in_out="INPUT",
                              socket_type="NodeSocketGeometry")
    tree.interface.new_socket("Geometry", in_out="OUTPUT",
                              socket_type="NodeSocketGeometry")

    nodes = tree.nodes
    group_in = nodes.new("NodeGroupInput")
    group_in.location = (-600, 0)
    group_out = nodes.new("NodeGroupOutput")
    group_out.location = (300, 0)

    position = nodes.new("GeometryNodeInputPosition")
    position.location = (-600, -200)

    along = nodes.new("ShaderNodeVectorMath")
    along.location = (-400, -200)
    along.operation = "DOT_PRODUCT"
    along.name = "DICOM Cut Axis"
    along.inputs[1].default_value = (0.0, 0.0, 1.0)

    compare = nodes.new("FunctionNodeCompare")
    compare.location = (-200, -200)
    compare.operation = "GREATER_THAN"
    compare.name = "DICOM Cut Plane"

    delete = nodes.new("GeometryNodeDeleteGeometry")
    delete.location = (100, 0)
    delete.domain = "FACE"

    tree.links.new(position.outputs[0], along.inputs[0])
    tree.links.new(along.outputs["Value"], compare.inputs[0])
    tree.links.new(group_in.outputs["Geometry"], delete.inputs["Geometry"])
    tree.links.new(compare.outputs[0], delete.inputs["Selection"])
    tree.links.new(delete.outputs[0], group_out.inputs[0])
    return tree


SURFACE_COLOUR_ATTRIBUTE = "Col"
SURFACE_VALUE_ATTRIBUTE = "DICOM Tissue"


def _add_surface_colour(tree, volume):
    """Colour the surface by what the scan reads a little way beneath it.

    Not at the surface: that is the level set where the value equals the
    level, so it reads nearly the same everywhere - measured at about 350 HU
    of spread against 943 HU two millimetres in, which is the difference
    between one white and a surface where bone and soft tissue are plainly
    different.

    Everything is live, so the colour follows the level and the cut rather
    than being baked once at the moment the surface was made.
    """
    nodes = tree.nodes
    delete = next((n for n in nodes if n.bl_idname
                   == "GeometryNodeDeleteGeometry"), None)
    group_out = next((n for n in nodes if n.bl_idname == "NodeGroupOutput"),
                     None)
    if delete is None or group_out is None:
        return None

    position = nodes.new("GeometryNodeInputPosition")
    position.location = (-620, 420)
    normal = nodes.new("GeometryNodeInputNormal")
    normal.location = (-620, 320)

    depth = nodes.new("ShaderNodeValue")
    depth.location = (-620, 240)
    depth.name = "DICOM Colour Depth"
    depth.label = "Colour Depth"
    depth.outputs[0].default_value = 2.0

    inward = nodes.new("ShaderNodeVectorMath")
    inward.location = (-440, 340)
    inward.operation = "SCALE"
    tree.links.new(normal.outputs[0], inward.inputs[0])
    tree.links.new(depth.outputs[0], inward.inputs["Scale"])

    info = nodes.new("GeometryNodeObjectInfo")
    info.location = (-620, 560)
    info.name = "DICOM Colour Source"
    info.transform_space = "RELATIVE"
    info.inputs["Object"].default_value = volume

    named = nodes.new("GeometryNodeGetNamedGrid")
    named.location = (-440, 560)
    named.data_type = "FLOAT"
    named.inputs["Name"].default_value = "density"
    tree.links.new(info.outputs["Geometry"], named.inputs["Volume"])

    # Three depths, and the strongest wins. One fixed step walks out of the
    # tissue wherever the anatomy is thinner than the step - on a 14 slice MR
    # at 4.8 mm spacing a quarter of the samples came back as background, and
    # background is what made the colour look unrelated to the scan. A sample
    # that left the body reads near nothing, so the largest of the three is
    # the one that stayed inside.
    sampled = None
    for index, fraction in enumerate((0.5, 1.0, 1.5)):
        offset = nodes.new("ShaderNodeVectorMath")
        offset.location = (-260, 460 - index * 90)
        offset.operation = "SCALE"
        offset.inputs["Scale"].default_value = fraction
        tree.links.new(inward.outputs["Vector"], offset.inputs[0])

        beneath = nodes.new("ShaderNodeVectorMath")
        beneath.location = (-180, 460 - index * 90)
        beneath.operation = "SUBTRACT"
        tree.links.new(position.outputs[0], beneath.inputs[0])
        tree.links.new(offset.outputs["Vector"], beneath.inputs[1])

        probe = nodes.new("GeometryNodeSampleGrid")
        probe.location = (-80, 540 - index * 90)
        probe.data_type = "FLOAT"
        tree.links.new(named.outputs["Grid"], probe.inputs["Grid"])
        tree.links.new(beneath.outputs["Vector"], probe.inputs["Position"])

        if sampled is None:
            sampled = probe.outputs["Value"]
        else:
            strongest = nodes.new("ShaderNodeMath")
            strongest.location = (20, 520 - index * 70)
            strongest.operation = "MAXIMUM"
            tree.links.new(sampled, strongest.inputs[0])
            tree.links.new(probe.outputs["Value"], strongest.inputs[1])
            sampled = strongest.outputs[0]

    # Kept as a plain number too, so the ramp can be fitted to it and so a
    # material of your own can read the scan value directly.
    keep = nodes.new("GeometryNodeStoreNamedAttribute")
    keep.location = (220, 140)
    keep.data_type = "FLOAT"
    keep.domain = "POINT"
    keep.name = "DICOM Tissue Store"
    keep.inputs["Name"].default_value = SURFACE_VALUE_ATTRIBUTE
    tree.links.new(sampled, keep.inputs["Value"])

    ramp = nodes.new("ShaderNodeValToRGB")
    ramp.location = (120, 540)
    ramp.name = "DICOM Surface Colours"
    ramp.label = "Surface Colours"
    # Greyscale, the way a scan is read. A tint carries no extra information
    # here - the value behind it is one number - and it makes two tissues of
    # similar density harder to tell apart than plain lightness does. The
    # positions are set again from the data once the surface exists.
    ramp.color_ramp.elements[0].position = 0.30
    ramp.color_ramp.elements[0].color = (0.02, 0.02, 0.02, 1.0)
    ramp.color_ramp.elements[1].position = 0.80
    ramp.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
    middle = ramp.color_ramp.elements.new(0.55)
    middle.color = (0.45, 0.45, 0.45, 1.0)
    tree.links.new(sampled, ramp.inputs["Fac"])

    store = nodes.new("GeometryNodeStoreNamedAttribute")
    store.location = (380, 300)
    store.data_type = "FLOAT_COLOR"
    store.domain = "POINT"
    store.inputs["Name"].default_value = SURFACE_COLOUR_ATTRIBUTE
    tree.links.new(delete.outputs[0], keep.inputs["Geometry"])
    tree.links.new(keep.outputs["Geometry"], store.inputs["Geometry"])
    tree.links.new(ramp.outputs["Color"], store.inputs["Value"])
    tree.links.new(store.outputs["Geometry"], group_out.inputs[0])
    return store


def _fit_surface_ramp(obj, tree) -> str:
    """Spread the colours across the values this surface actually has.

    A fixed band washes out whenever the data does not fill it. On an MR the
    values sit in a narrow range that is nowhere near the band chosen for a
    CT, so everything came out one tone - which reads as a colour that is not
    following the scan at all. The ramp is fitted to the spread that is
    there, once, when the surface is made.
    """
    nodes = getattr(tree, "nodes", None)
    ramp = nodes.get("DICOM Surface Colours") if nodes else None
    if ramp is None:
        return ""
    try:
        graph = bpy.context.evaluated_depsgraph_get()
        graph.update()
        evaluated = obj.evaluated_get(graph)
        mesh = evaluated.to_mesh()
        attr = mesh.attributes.get(SURFACE_VALUE_ATTRIBUTE)
        if attr is None or len(attr.data) < 64:
            evaluated.to_mesh_clear()
            return ""
        values = np.empty(len(attr.data), dtype=np.float32)
        attr.data.foreach_get("value", values)
        evaluated.to_mesh_clear()
    except Exception:
        return ""

    finite = values[np.isfinite(values)]
    if finite.size < 64:
        return ""
    # Ignore what came back as nothing: those are samples that left the body,
    # and letting them set the low end wastes half the ramp on background.
    inside = finite[finite > 1e-4]
    if inside.size > finite.size // 10:
        finite = inside
    low, mid, high = (float(np.percentile(finite, p)) for p in (5, 50, 95))
    if high - low < 0.02:
        return ""
    mid = min(max(mid, low + 0.01), high - 0.01)

    elements = ramp.color_ramp.elements
    for element, position in zip(elements, (low, mid, high)):
        element.position = float(min(max(position, 0.0), 1.0))
    return "{:.2f} to {:.2f}".format(low, high)


def _surface_material(name):
    """A material that shows the colour the nodes stored."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    tree = mat.node_tree
    for node in list(tree.nodes):
        tree.nodes.remove(node)
    out = tree.nodes.new("ShaderNodeOutputMaterial")
    out.location = (400, 0)
    shader = tree.nodes.new("ShaderNodeBsdfPrincipled")
    shader.location = (100, 0)
    attr = tree.nodes.new("ShaderNodeAttribute")
    attr.location = (-200, 0)
    attr.attribute_name = SURFACE_COLOUR_ATTRIBUTE
    tree.links.new(attr.outputs["Color"], shader.inputs["Base Color"])
    tree.links.new(shader.outputs[0], out.inputs["Surface"])
    return mat


def _cut_plane(volume, props):
    """Where the cut sits, in the volume's own local space.

    The material works in generated coordinates, which run 0..1 across the
    bounding box; a mesh is in object space. Converting here keeps one slider
    meaning the same thing in both.
    """
    corners = [list(c) for c in volume.bound_box]
    low = [min(c[i] for c in corners) for i in range(3)]
    high = [max(c[i] for c in corners) for i in range(3)]
    axis = str(getattr(props, "volume_cut_axis", "AUTO"))
    index = {"X": 0, "Y": 1, "Z": 2}.get(axis, 2)
    depth = float(getattr(props, "volume_cut_depth", 0.5))
    vector = [0.0, 0.0, 0.0]
    vector[index] = 1.0
    return vector, low[index] + depth * (high[index] - low[index])


_PENDING_LEVELS: dict[str, float] = {}
_LEVEL_TIMER_ARMED = False
LEVEL_SETTLE_SECONDS = 0.25

APPLY_LEVEL_IMMEDIATELY = None
"""Whether to rebuild the surface at once instead of waiting for the drag.

``None`` decides from whether Blender has a window. Set outright so the
waiting path can be exercised where there is no viewport, which is the only
place the tests can run and the one place the behaviour does not apply.
"""


def _apply_pending_levels():
    """Set the surface level once a drag has stopped moving."""
    global _LEVEL_TIMER_ARMED

    _LEVEL_TIMER_ARMED = False
    pending = dict(_PENDING_LEVELS)
    _PENDING_LEVELS.clear()
    for name, level in pending.items():
        obj = bpy.data.objects.get(name)
        if obj is None:
            continue
        for modifier in obj.modifiers:
            if modifier.type != "VOLUME_TO_MESH":
                continue
            if abs(modifier.threshold - level) > 1e-6:
                modifier.threshold = level
            obj["dicom_threshold"] = level
        obj.update_tag()
    return None


def _queue_surface_level(obj, level):
    """Rebuild the surface after the slider settles, not on every tick.

    Changing the level rebuilds the whole isosurface - some 700,000 vertices
    on a chest CT - and a slider sends a change per mouse step. EEVEE keeps
    each object's vertex buffers between redraws to work out motion vectors,
    and replacing the geometry that often while it is drawing crashed Blender
    inside its velocity module, reading a buffer that had already been freed.

    Waiting for the drag to stop collapses a whole drag into one rebuild. In
    background mode there is no viewport, no timers to speak of, and nothing
    to tear: the value is set at once so scripts and tests see it immediately.
    """
    global _LEVEL_TIMER_ARMED

    _PENDING_LEVELS[obj.name] = float(level)
    immediate = APPLY_LEVEL_IMMEDIATELY
    if immediate is None:
        immediate = bool(getattr(bpy.app, "background", False))
    if immediate:
        _apply_pending_levels()
        return
    if _LEVEL_TIMER_ARMED:
        return
    try:
        bpy.app.timers.register(_apply_pending_levels,
                                first_interval=LEVEL_SETTLE_SECONDS)
        _LEVEL_TIMER_ARMED = True
    except Exception:
        _apply_pending_levels()


def _push_surface_colour(obj, props):
    """Keep the colour depth in step with the panel."""
    for modifier in obj.modifiers:
        if modifier.type != "NODES":
            continue
        nodes = getattr(modifier.node_group, "nodes", None)
        node = nodes.get("DICOM Colour Depth") if nodes else None
        if node is not None:
            node.outputs[0].default_value = float(
                getattr(props, "volume_color_depth", 2.0))


def _push_cut_to_surface(obj, props):
    """Keep a meshed surface showing the same cut and level as its volume."""
    volume = bpy.data.objects.get(str(obj.get("dicom_source_volume") or ""))

    for modifier in obj.modifiers:
        if modifier.type == "VOLUME_TO_MESH":
            # Queued rather than set: this one rebuilds the whole surface.
            _queue_surface_level(obj, float(getattr(props, "volume_level",
                                                    0.55)))
        elif modifier.type == "NODES" and str(getattr(
                modifier.node_group, "name", "")).startswith(CUT_GROUP):
            axis = str(getattr(props, "volume_cut_axis", "AUTO"))
            # Auto turns the cut to face the view, and a mesh has no view to
            # face, so it is left uncut rather than cut along an axis nobody
            # chose - the same rule the render follows.
            on = (bool(getattr(props, "volume_cut_enabled", True))
                  and axis in {"X", "Y", "Z"})
            nodes = getattr(modifier.node_group, "nodes", None)
            axis_node = nodes.get("DICOM Cut Axis") if nodes else None
            plane_node = nodes.get("DICOM Cut Plane") if nodes else None
            colours = nodes.get("DICOM Surface Colours") if nodes else None

            if axis_node is None or plane_node is None:
                # Rather than cut in the wrong place, or at a default of zero
                # which would delete the whole surface, show it uncut.
                modifier.show_viewport = False
                modifier.show_render = False
                continue

            # The group carries the colour as well as the cut, so switching
            # the modifier off to stop cutting took the colour with it. It
            # stays on whenever either has work to do, and a cut that is off
            # is made a cut that selects nothing instead.
            live = on or colours is not None
            modifier.show_viewport = live
            modifier.show_render = live
            if volume is None or not live:
                continue

            flipped = bool(getattr(props, "volume_cut_flip", False))
            plane_node.operation = "LESS_THAN" if flipped else "GREATER_THAN"
            if on:
                vector, threshold = _cut_plane(volume, props)
                axis_node.inputs[1].default_value = tuple(
                    float(v) for v in vector)
            else:
                # Past every coordinate the surface has, in whichever
                # direction the comparison is reading.
                threshold = -1.0e9 if flipped else 1.0e9
            plane_node.inputs[1].default_value = float(threshold)
    _push_surface_colour(obj, props)
    obj.update_tag()

class DICOM_OT_volume_to_mesh(bpy.types.Operator):
    bl_idname = "dicom.volume_to_mesh"
    bl_label = "Volume To Mesh"
    bl_description = (
        "Build a real surface at the Surface Level, as geometry rather than "
        "as something that only looks solid. The result is an ordinary mesh "
        "object, so the mesh tools and modifiers all apply to it"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "VOLUME"

    def execute(self, context):
        props = context.scene.dicom_import_props
        source = context.active_object
        if source is None or source.type != "VOLUME":
            self.report({"ERROR"}, "Select a volume first")
            return {"CANCELLED"}

        grid = "density"
        try:
            source.data.grids.load()
            names = [g.name for g in source.data.grids]
            if names:
                grid = names[0]
        except Exception:
            pass

        mesh = bpy.data.meshes.new(f"{source.name}_Surface")
        obj = bpy.data.objects.new(f"{source.name}_Surface", mesh)
        for collection in source.users_collection:
            collection.objects.link(obj)
        if not source.users_collection:
            context.collection.objects.link(obj)
        # The surface has to sit on the volume, and the modifier works in the
        # volume's own space, so the two share a transform.
        obj.matrix_world = source.matrix_world.copy()

        modifier = obj.modifiers.new("DICOM Surface", "VOLUME_TO_MESH")
        modifier.object = source
        modifier.grid_name = grid
        # The grid's own resolution: anything coarser throws away detail that
        # is already in the file, and this is the one place it is free.
        modifier.resolution_mode = "GRID"
        modifier.threshold = float(getattr(props, "volume_level", 0.35))
        modifier.adaptivity = 0.0

        # The same cut the volume is showing, carried onto the geometry.
        cut = obj.modifiers.new("DICOM Cut", "NODES")
        cut.node_group = _volume_cut_node_group(f"{CUT_GROUP} {source.name}")
        fitted = ""
        colour_group = None
        if bool(getattr(props, "volume_surface_color", True)):
            if _add_surface_colour(cut.node_group, source) is not None:
                obj.data.materials.append(
                    _surface_material(f"{obj.name}_Tissue"))
                # The colour only exists on the modifier's output, and the
                # viewport will not show a colour attribute that is not the
                # active one - which cannot be set on geometry that is not
                # there yet. Declaring it on the base mesh gives the viewport
                # something to make active; the modifier then fills it in.
                colours = mesh.color_attributes
                if SURFACE_COLOUR_ATTRIBUTE not in colours:
                    colours.new(name=SURFACE_COLOUR_ATTRIBUTE,
                                type="FLOAT_COLOR", domain="POINT")
                index = colours.find(SURFACE_COLOUR_ATTRIBUTE)
                if index >= 0:
                    colours.active_color_index = index
                    colours.render_color_index = index
                colour_group = cut.node_group

        obj["dicom_volume_surface"] = True
        obj["dicom_source_volume"] = source.name
        obj["dicom_threshold"] = float(modifier.threshold)
        for key in ("dicom_window_low", "dicom_window_high",
                    "dicom_series_uid"):
            if source.get(key) is not None:
                obj[key] = source[key]

        _push_cut_to_surface(obj, props)
        # After the cut is configured, not before: until then the plane sits
        # at its default and selects the whole surface for deletion, so there
        # is no geometry to read a distribution from and the ramp was quietly
        # left at the band chosen for a CT.
        if colour_group is not None:
            fitted = _fit_surface_ramp(obj, colour_group)

        source.hide_set(True)
        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        low = float(source.get("dicom_window_low", 0.0))
        high = float(source.get("dicom_window_high", 1.0))
        at = low + modifier.threshold * (high - low)
        props.volume_status = (
            "Surface at level {:.2f} of the window, about {:.0f} on the "
            "scan's own scale. The modifier is live, so the level can still "
            "be changed on it.".format(modifier.threshold, at)
        )
        if fitted:
            props.volume_status += " Colours fitted to {}.".format(fitted)
        self.report({"INFO"}, props.volume_status)
        return {"FINISHED"}

class DICOM_OT_separate_muscles(bpy.types.Operator):
    bl_idname = "dicom.separate_muscles"
    bl_label = "Import Segmented Features"
    bl_description = (
        "Find individual muscles using the dark fascial line in the out-of-phase "
        "series, and import each as its own point cloud"
    )
    bl_options = {"REGISTER", "UNDO"}

    # Reading three series, resampling each of them and segmenting the result
    # is minutes of work on a real station. Done inside execute() it holds the
    # main thread for all of it and Blender stops redrawing - from outside
    # there is nothing to tell that apart from a hang, which is what was
    # reported. So the numpy half runs on a worker and a timer-driven modal
    # loop reports where it has got to, the same shape as the mesh conversion.
    # Only the scene changes happen on the main thread, one feature per tick,
    # because bpy.data is not safe to touch from the worker.

    def invoke(self, context, event):
        props = context.scene.dicom_import_props
        plan = _plan_segmented_import(
            props, bool(props.muscle_allow_partial),
            bool(props.muscle_ct_mode))
        if isinstance(plan, str):
            self.report({"ERROR"}, plan)
            return {"CANCELLED"}

        self._plan = plan
        self._snapshot = _segmented_settings(props)
        self._cancelled = False
        self._done = False
        self._error = None
        self._result = None
        self._progress = 0.0
        self._message = "Starting"
        self._made = 0
        self._total = 0
        self._next_feature = 0
        self._timer = None

        props.muscle_running = True
        props.muscle_progress_percent = 0.0
        props.muscle_status = "Starting"
        context.window_manager.progress_begin(0.0, 100.0)

        def _report(percent, message=""):
            self._progress = max(self._progress, float(percent))
            if message:
                self._message = str(message)

        def _work():
            try:
                self._result = _segment_station(
                    self._plan, self._snapshot, _report,
                    lambda: self._cancelled,
                )
            except Exception as exc:                      # noqa: BLE001
                self._error = exc
            finally:
                self._done = True

        self._thread = threading.Thread(target=_work, daemon=True)
        self._thread.start()

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        """Synchronous path, for scripting and for running without a window."""
        props = context.scene.dicom_import_props
        plan = _plan_segmented_import(
            props, bool(props.muscle_allow_partial),
            bool(props.muscle_ct_mode))
        if isinstance(plan, str):
            self.report({"ERROR"}, plan)
            return {"CANCELLED"}
        try:
            result = _segment_station(plan, _segmented_settings(props),
                                      lambda p, m="": None, lambda: False)
        except Exception as exc:                          # noqa: BLE001
            props.muscle_status = "Failed: {}".format(exc)
            self.report({"ERROR"}, props.muscle_status)
            return {"CANCELLED"}

        made = total = 0
        for feature in result["features"]:
            if _place_feature(context, props, feature, plan["target"],
                              result["spacing"]) is not None:
                made += 1
                total += len(feature["points"])
        props.muscle_status = _segmented_status(result, plan["target"], made, total)
        self.report({"INFO"}, props.muscle_status)
        _popup_warnings(context, "Check this series",
                        result.get("file_warnings"))
        return {"FINISHED"} if made else {"CANCELLED"}

    def _finish(self, context):
        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        try:
            context.window_manager.progress_end()
        except Exception:
            pass
        try:
            context.scene.dicom_import_props.muscle_running = False
        except Exception:
            pass

    def modal(self, context, event):
        props = context.scene.dicom_import_props

        if event.type == "ESC" and event.value == "PRESS":
            self._cancelled = True
            self._message = "Stopping"

        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        if not self._done:
            # The worker's own 0-100 covers reading and segmenting, which is
            # the long part; placing the clouds afterwards is the last tenth.
            _set_muscle_progress(context, 0.9 * self._progress, self._message)
            return {"RUNNING_MODAL"}

        if self._error is not None:
            props.muscle_status = "Failed: {}".format(self._error)
            self.report({"ERROR"}, props.muscle_status)
            self._finish(context)
            return {"CANCELLED"}

        if self._cancelled:
            props.muscle_status = "Cancelled"
            self.report({"WARNING"}, props.muscle_status)
            self._finish(context)
            return {"CANCELLED"}

        features = self._result["features"]
        if self._next_feature < len(features):
            # One per tick, so the viewport keeps redrawing while several
            # million points are handed over.
            feature = features[self._next_feature]
            self._next_feature += 1
            _set_muscle_progress(
                context,
                90.0 + 10.0 * self._next_feature / max(1, len(features)),
                "Placing feature {} of {}".format(self._next_feature, len(features)),
            )
            if _place_feature(context, props, feature, self._plan["target"],
                              self._result["spacing"]) is not None:
                self._made += 1
                self._total += len(feature["points"])
            return {"RUNNING_MODAL"}

        props.muscle_status = _segmented_status(
            self._result, self._plan["target"], self._made, self._total)
        _set_muscle_progress(context, 100.0, props.muscle_status)
        self.report({"INFO"}, props.muscle_status)
        self._finish(context)
        _popup_warnings(context, "Check this series",
                        self._result.get("file_warnings"))
        return {"FINISHED"} if self._made else {"CANCELLED"}


def _set_muscle_progress(context, percent: float, message: str) -> None:
    clamped = max(0.0, min(100.0, float(percent)))
    try:
        props = context.scene.dicom_import_props
        props.muscle_progress_percent = clamped
        props.muscle_status = message
    except Exception:
        return
    try:
        context.window_manager.progress_update(clamped)
    except Exception:
        pass
    # Redraw the sidebar, or the number sits there unchanged and the thing
    # still looks frozen, which was the whole complaint.
    for window in getattr(context.window_manager, "windows", []):
        for area in getattr(getattr(window, "screen", None), "areas", []):
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _segmented_settings(props) -> dict:
    """Everything the worker needs, copied before it leaves the main thread."""
    return {
        "source_path": str(props.source_path),
        "source_is_zip": bool(props.source_is_zip),
        "enhanced": bool(props.import_enhance_enabled),
        "import_settings": _import_settings_from_props(props),
        "boundary_cut": float(props.muscle_boundary_cut),
        "boundary_fat": float(props.muscle_boundary_fat),
        "link_fraction": float(props.muscle_link_fraction),
        "min_volume": float(props.muscle_min_volume),
        "max_fat_fraction": float(props.muscle_max_fat_fraction),
        "min_thickness_slices": float(props.muscle_min_slices),
        "stride": max(1, int(props.stride)),
        "max_points": max(0, int(props.max_points)),
        "threshold": float(props.threshold),
        "threshold_max": float(getattr(props, "threshold_max", 0.0)),
        "ct_mode": bool(getattr(props, "muscle_ct_mode", False)),
        "bone_core_cm3": float(getattr(props, "muscle_bone_core", 0.15)),
        "bone_cortex_hu": float(getattr(props, "muscle_bone_cortex", 700.0)),
        "bone_refine": float(getattr(props, "muscle_bone_refine", 0.95)),
        "mri_bone": bool(getattr(props, "muscle_mri_bone", False)),
        "mri_marrow_fat": float(getattr(props, "muscle_mri_marrow_fat", 0.30)),
        "mri_cortex_rim": float(getattr(props, "muscle_mri_cortex_rim", 0.02)),
        "mri_bone_min": float(getattr(props, "muscle_mri_bone_min", 1.0)),
        "mri_bone_grow": int(getattr(props, "muscle_mri_bone_grow", 8)),
        "mri_bone_mode": str(getattr(props, "muscle_mri_bone_mode", "DARK")),
        "mri_dark_level": float(getattr(props, "muscle_mri_dark_level", 0.18)),
        "shading_correct": bool(getattr(props, "shading_correct", False)),
        "shading_scale_mm": float(getattr(props, "shading_scale_mm", 20.0)),
        "safe_mode": bool(props.safe_mode),
        "safe_cap": int(props.safe_cap_points),
        "place": bool(getattr(props, "place_in_patient_space", False)),
    }


def _plan_segmented_import(props, allow_partial: bool = False,
                           ct_mode: bool = False):
    """Pick the station and its series. A string is an error message.

    Normally this wants fat, water and out-of-phase: they come from one
    acquisition so they are inherently co-registered, which is what lets fat
    fraction be computed per voxel. With ``allow_partial`` it takes whatever a
    station has, down to a single series, and the segmenter works out what it
    can from that.
    """
    from .io_dicom import discover_series

    if not props.source_path:
        return "Set Source Path first"
    try:
        series = discover_series(props.source_path, props.source_is_zip)
    except Exception as exc:                              # noqa: BLE001
        return str(exc)
    if not series:
        return "No series found at that path"

    stations = {}
    for item in series:
        key = round(float(item.position), 1)
        # An unclassified series is still a volume. It is only ever used when
        # nothing better sits at the same station, and never overwrites one
        # whose contrast is known.
        slot = item.contrast or "ANY"
        stations.setdefault(key, {}).setdefault(slot, item)

    chosen_uid = str(props.series_uid or "")
    chosen = next((item for item in series if item.uid == chosen_uid), None)

    if ct_mode:
        # One series, the one selected. A CT has no companion channels to
        # gather, so there is no station to assemble.
        if chosen is None:
            chosen = next((item for item in series if not item.localizer), None)
        if chosen is None:
            return "No usable series at that path"
        if chosen.localizer:
            return ("That series is a localizer, not a volume - pick a real "
                    "series.")
        if chosen.modality and chosen.modality != "CT":
            return ("CT Scan is ticked but the selected series is "
                    f"{chosen.modality}, not CT. Untick it, or pick a CT "
                    f"series.")
        return {"target": round(float(chosen.position), 1),
                "uids": {"CT": chosen.uid}}

    needed = ("FAT", "WATER", "OPP")
    core = ("FAT", "WATER")
    complete = sorted(key for key, got in stations.items()
                      if all(c in got for c in needed))
    # Out-of-phase is |water - fat|, so a station carrying both can stand in
    # for one that was never acquired - that is the derived tier, and it only
    # works in this direction, because magnitude images drop the sign.
    derivable = sorted(key for key, got in stations.items()
                       if all(c in got for c in core))

    if not allow_partial:
        missing = [c for c in core
                   if not any(c in got for got in stations.values())]
        if missing:
            return ("This needs fat and water series; missing: "
                    + ", ".join(missing)
                    + ". Tick Work From Single Source to run on fewer.")
        if not derivable:
            return ("No station has both fat and water. Tick Work From "
                    "Single Source to run on fewer.")
        usable = complete or derivable
    else:
        usable = sorted(stations)

    if allow_partial and chosen is not None:
        # One source means the one that was asked for. Picking a station from
        # it and then reading whatever else happened to sit there was how a
        # run came back having never touched the selected scan.
        if chosen.localizer:
            return ("That series is a localizer, not a volume - its slices are "
                    "planning images, so stacking them gives a slanted shape "
                    "rather than anatomy. Pick a real series.")
        slot = chosen.contrast or "ANY"
        return {"target": round(float(chosen.position), 1),
                "uids": {slot: chosen.uid}}

    # The station nearest the selected series, so that choice means something
    # here rather than silently taking the first.
    target = usable[0]
    if chosen is not None:
        target = min(usable, key=lambda k: abs(k - float(chosen.position)))

    got = stations[target]
    if allow_partial:
        uids = {name: item.uid for name, item in got.items()
                if not item.localizer}
        if not uids:
            return "Every series at that station is a localizer, not a volume"
        # One unclassified series alongside named ones adds nothing and costs
        # a full volume read.
        if len(uids) > 1:
            uids.pop("ANY", None)
    else:
        uids = {c: got[c].uid for c in needed if c in got}
    return {"target": target, "uids": uids}


def _segment_station(plan, cfg, report, is_cancelled):
    """All the numpy work, with no bpy in it, so it can run on a worker."""
    from .io_dicom import load_series_volume
    from .muscle import (TIER_FULL, TIER_GRADIENT, TIER_NO_FAT, TIER_NOTES,
                         derive_channels, separate_muscles)
    from .pointcloud import build_points_from_volume

    volumes = {}
    geometry = {}
    file_warnings = []
    spacing = (1.0, 1.0, 1.0)
    resample_offset = None
    wanted = list(plan["uids"])
    for index, contrast in enumerate(wanted):
        if is_cancelled():
            raise RuntimeError("cancelled")
        base = 2.0 + index * (36.0 / max(1, len(wanted)))
        report(base, "Reading the {} series".format(contrast.lower()))
        stats = {}
        raw, spacing = load_series_volume(
            cfg["source_path"], cfg["source_is_zip"], plan["uids"][contrast],
            stats=stats,
        )
        value = np.asarray(raw, dtype=np.float32)
        # Before the resample, because afterwards the spacing is the fine one
        # and the thickness the scanner actually acquired is gone.
        acquired_mm = float(spacing[2])
        if cfg["enhanced"]:
            # Interpolating the measured intensities before anything is
            # thresholded is worth more here than at import. The fascia between
            # muscles is thinner than a slice, so whether it survives
            # resampling decides what can be separated at all. All three
            # contrasts share a shape and spacing, so they land on one grid and
            # stay voxel-aligned.
            from .surface import enhance_volume

            report(base + 5.0, "Sharpening the {} series".format(contrast.lower()))
            value, fine_grid, _ = enhance_volume(
                value, spacing, settings=cfg["import_settings"])
            spacing = fine_grid.spacing
            # One grid for every contrast, so the same shift each time.
            resample_offset = tuple(float(v) for v in fine_grid.origin)
        if cfg["ct_mode"]:
            # Left in Hounsfield units. Dividing by a percentile would throw
            # away the one thing that makes a CT easier to read than an MR -
            # that its numbers already mean something.
            ceiling = 1.0
            volumes[contrast] = np.asarray(value, dtype=np.float32)
        else:
            ceiling = max(float(np.percentile(value, 99.5)), 1e-6)
            volumes[contrast] = np.clip(
                np.asarray(value, dtype=np.float32) / ceiling, 0.0, 1.0)
        geometry = stats
        for message in stats.get("geometry_warnings") or []:
            # The contrasts of one station are the same acquisition, so the
            # same complaint arrives once per series.
            if message not in file_warnings:
                file_warnings.append(message)

    if cfg["shading_correct"] and cfg["ct_mode"]:
        # A CT has no receive coil to roll off, and its numbers are calibrated
        # - "flattening" them would only break the calibration.
        report(78.0, "Shading correction skipped - a CT has none")
    elif cfg["shading_correct"] and len(volumes) > 1:
        # One gain for every channel, taken from their sum. They arrive
        # through the same coil, so correcting them separately would change
        # the ratio between them - and that ratio is the fat fraction.
        from .preprocessing import shading_gain

        report(78.0, "Flattening the coil's shading")
        total = sum(np.asarray(v, dtype=np.float32) for v in volumes.values())
        tissue = total > max(float(np.percentile(total, 70.0)), 1e-6)
        gain = shading_gain(total, spacing, tissue,
                            sigma_mm=cfg["shading_scale_mm"])
        for name in list(volumes):
            volumes[name] = np.clip(volumes[name] * gain, 0.0, 1.0)
    elif cfg["shading_correct"]:
        from .preprocessing import correct_shading

        report(78.0, "Flattening the coil's shading")
        only = next(iter(volumes))
        volumes[only] = np.clip(
            correct_shading(volumes[only], spacing,
                            sigma_mm=cfg["shading_scale_mm"]), 0.0, 1.0)

    shapes = {c: volumes[c].shape for c in volumes}
    if len(set(shapes.values())) != 1:
        raise ValueError(
            "The series came out on different grids ({}); they have to be "
            "voxel-aligned to be combined.".format(shapes))

    if is_cancelled():
        raise RuntimeError("cancelled")
    classes = {}
    if cfg["ct_mode"]:
        from .muscle import TIER_CT, ct_classes

        tier = TIER_CT
        hu = next(iter(volumes.values()))
        labels = np.zeros(hu.shape, dtype=np.int32)
        stats = {}
        offset = 0
        passes = ct_classes(hu)
        for index, (class_name, class_mask, field, class_cut) in enumerate(passes):
            if is_cancelled():
                raise RuntimeError("cancelled")
            base = 40.0 + 45.0 * index / max(1, len(passes))
            report(base, "Separating {}".format(class_name.lower()))
            if not class_mask.any():
                continue
            if class_cut == "touching":
                # Bones meet at joints rather than being parted by anything in
                # the image, so there is no field to cut. Separated by how
                # deep inside one each voxel sits instead.
                from .muscle import refine_by_local_cortex, split_by_cortex

                voxel_cm3 = float(np.prod(spacing)) / 1000.0
                part = split_by_cortex(
                    class_mask, hu,
                    cortex_hu=cfg["bone_cortex_hu"],
                    min_seed_cm3=cfg["bone_core_cm3"],
                    voxel_cm3=voxel_cm3)
                if cfg["bone_refine"] > 0.0:
                    # One level cannot seed a tarsal and a phalanx both, so
                    # each piece is looked at again against its own density.
                    report(base + 15.0, "Splitting the smaller bones")
                    part = refine_by_local_cortex(
                        part, hu, voxel_cm3,
                        fraction=cfg["bone_refine"],
                        min_seed_cm3=cfg["bone_core_cm3"] / 2.5)
                part, part_stats = _trim_small(
                    part, float(np.prod(spacing)) / 1000.0,
                    cfg["min_volume"])
                if not (part > 0).any():
                    continue
                present = part > 0
                labels[present] = part[present] + offset
                for value in range(1, int(part.max()) + 1):
                    classes[value + offset] = class_name
                offset += int(part.max())
                stats = _merge_class_stats(stats, part_stats)
                continue
            blank = np.zeros_like(field)
            part, part_stats = separate_muscles(
                blank, field, field, spacing, mask=class_mask,
                # Belonging to the class has already done most of the
                # separating. Cutting hard on top of that only empties the
                # interior and leaves the fill to guess - measured on a CT of
                # two feet, bone at a 0.55 cut came back 96% guessed and at
                # 0.02 it was 15%. Only muscle, which really is parted by fat
                # planes inside its own class, takes the panel's setting.
                boundary_cut=(cfg["boundary_cut"] if class_cut is None
                              else float(class_cut)),
                # The fat terms need two channels to mean anything and a CT
                # class has one field, so they are switched off rather than
                # faked out of a number that does not carry that information.
                boundary_fat_fraction=0.99,
                link_fraction=cfg["link_fraction"],
                min_volume_cm3=cfg["min_volume"],
                min_thickness_slices=cfg["min_thickness_slices"],
                acquired_slice_mm=acquired_mm,
                clamp_cut=False,
                progress_cb=lambda p, m="", b=base: report(b + 0.45 * p / 3.0, m),
            )
            if not (part > 0).any():
                continue
            present = part > 0
            labels[present] = part[present] + offset
            for value in range(1, int(part.max()) + 1):
                classes[value + offset] = class_name
            offset += int(part.max())
            stats = _merge_class_stats(stats, part_stats)
    else:
        fat, water, outphase, tier = derive_channels(volumes, spacing)

        # Threshold is in raw scanner units and the channels have been divided
        # by their own 99.5th percentile, so the window comes along with them.
        # Only used where there is no fat fraction to decide tissue instead.
        low, high = 0.18, 0.0
        if tier in (TIER_NO_FAT, TIER_GRADIENT) and ceiling > 0.0:
            low = max(0.0, float(cfg["threshold"]) / ceiling)
            high = max(0.0, float(cfg["threshold_max"]) / ceiling)

        bone = None
        if cfg.get("mri_bone") and fat is not None and water is not None:
            from .muscle import mri_bone

            report(38.0, "Looking for bone")
            if cfg.get("mri_bone_mode", "DARK") == "DARK":
                from .muscle import mri_dark_interior

                bone = mri_dark_interior(
                    water, fat, spacing,
                    level=cfg["mri_dark_level"],
                    min_volume_cm3=cfg["mri_bone_min"])
            else:
                bone = mri_bone(water, fat, spacing,
                                fat_level=cfg["mri_marrow_fat"],
                                min_volume_cm3=cfg["mri_bone_min"],
                                rim_void=cfg["mri_cortex_rim"],
                                grow=cfg["mri_bone_grow"])
            if not (bone > 0).any():
                bone = None

        labels, stats = separate_muscles(
            fat, water, outphase, spacing,
            min_signal=low, max_signal=high,
            acquired_slice_mm=acquired_mm,
            clamp_cut=(tier != TIER_GRADIENT),
            boundary_cut=cfg["boundary_cut"],
            boundary_fat_fraction=cfg["boundary_fat"],
            link_fraction=cfg["link_fraction"],
            min_volume_cm3=cfg["min_volume"],
            max_fat_fraction=cfg["max_fat_fraction"],
            min_thickness_slices=cfg["min_thickness_slices"],
            mask=None,
            progress_cb=lambda p, m="": report(40.0 + 0.45 * p, m),
        )

        if bone is not None:
            # Taken out after, not before. ``mask`` says what *is* tissue -
            # that is how the CT classes use it - so handing it everything
            # that is not bone declares the surrounding air to be tissue, and
            # the station came back with eight times the volume it has.
            labels[bone > 0] = 0
            offset = int(labels.max())
            for value in range(1, int(bone.max()) + 1):
                where = bone == value
                if not where.any():
                    continue
                offset += 1
                labels[where] = offset
                classes[offset] = "Bone"
            for value in range(1, offset + 1):
                classes.setdefault(value, "Muscle")
            stats["bones"] = int(bone.max())

    # Fat plus water is the in-phase image: every tissue with signal, which is
    # what makes the shape readable in the viewport. Its range is taken once,
    # over the whole station, so all the features share one scale.
    if cfg["ct_mode"]:
        # A window wide enough to hold fat through bone, so every class is
        # readable in the viewport rather than one of them being flat white.
        hu = np.asarray(next(iter(volumes.values())), dtype=np.float32)
        shading = np.clip((hu + 200.0) / 1200.0, 0.0, 1.0)
    else:
        shading = (np.asarray(fat, dtype=np.float32)
                   + np.asarray(water, dtype=np.float32))
    lit = shading[shading > 0.0]
    shade_range = ((float(np.percentile(lit, 2.0)), float(np.percentile(lit, 98.0)))
                   if lit.size else (0.0, 1.0))

    origin = geometry.get("volume_origin")
    orientation = geometry.get("volume_orientation")
    if origin is not None and orientation is not None and resample_offset:
        from .pointcloud import shift_origin

        origin = shift_origin(origin, orientation, resample_offset)

    highest = int(labels.max())
    features = []
    capped = False
    for value in range(1, highest + 1):
        if is_cancelled():
            raise RuntimeError("cancelled")
        report(85.0 + 15.0 * value / max(1, highest),
               "Building feature {} of {}".format(value, highest))
        volume_mask = (labels == value).astype(np.float32)
        if not volume_mask.any():
            continue
        point_stats = {}
        points, shades = build_points_from_volume(
            volume=volume_mask, spacing=spacing, threshold=0.5,
            # Stride and Max Points are the import's density controls and apply
            # here too - a station came back with 15 million points because
            # this path ignored both. Threshold deliberately does not: it is a
            # level in raw scanner units, and what is being sampled here is a
            # finished 0/1 mask, so Max Fat Fraction and the boundary settings
            # are what decide membership.
            stride=cfg["stride"], max_points=cfg["max_points"],
            origin=origin if cfg["place"] else None,
            orientation=orientation if cfg["place"] else None,
            value_volume=shading, value_range=shade_range,
            stats=point_stats,
        )
        if cfg["safe_mode"] and len(points) > cfg["safe_cap"]:
            rng = np.random.default_rng(42)
            keep = rng.choice(len(points), size=cfg["safe_cap"], replace=False)
            keep.sort()
            points = points[keep]
            shades = shades[keep]
            capped = True
        if len(points) < 4:
            continue
        feature = {"index": value, "points": points, "shades": shades,
                   "name": classes.get(value, "Muscle")}
        if cfg["ct_mode"]:
            # The real Hounsfield numbers, so a later pass can work from the
            # cloud alone instead of reading the study again. Intensity will
            # not do: it is clipped to a display range.
            from .pointcloud import lattice_used, voxel_indices

            # The frame the points were actually laid out in - which is not
            # the patient frame when Use Scanner Position is off, and is not
            # one voxel per step when Stride is above 1.
            taken = int(point_stats.get("stride", cfg["stride"]) or 1)
            placed = cfg["place"]
            base, axes, step = lattice_used(
                hu.shape, spacing,
                origin if placed else None,
                orientation if placed else None,
                stride=taken)

            # Sampling needs indices in the volume's own voxels, so the
            # original spacing rather than the strided step.
            index = voxel_indices(points, base, axes, spacing)
            inside = ((index >= 0).all(axis=1)
                      & (index[:, 0] < hu.shape[2])
                      & (index[:, 1] < hu.shape[1])
                      & (index[:, 2] < hu.shape[0]))
            measured = np.zeros(len(points), dtype=np.float32)
            measured[inside] = hu[index[inside, 2], index[inside, 1],
                                  index[inside, 0]]
            feature["hu"] = measured
            feature["lattice"] = (base, axes, step)
        features.append(feature)

    return {"features": features, "stats": stats, "spacing": spacing,
            "capped": capped, "enhanced": cfg["enhanced"], "tier": tier,
            "used": sorted(volumes), "classes": classes,
            "file_warnings": file_warnings}


def _trim_small(labels, voxel_cm3: float, min_volume_cm3: float):
    """Drop pieces under the size limit and renumber. Returns (labels, stats).

    The depth split does its own separating, so it does not go through
    separate_muscles - but the result still has to honour Min Muscle and
    report the same figures the other classes do.
    """
    counts = np.bincount(labels.reshape(-1))
    counts[0] = 0
    keep = (counts * voxel_cm3) >= float(min_volume_cm3)
    remap = np.zeros(counts.size, dtype=np.int32)
    chosen = np.nonzero(keep)[0]
    remap[chosen] = np.arange(1, len(chosen) + 1)
    out = remap[labels]
    final = np.bincount(out.reshape(-1))
    final[0] = 0
    return out, {
        "regions": int((counts > 0).sum()),
        "muscles": int(len(chosen)),
        "muscle_cm3": float(counts.sum() * voxel_cm3),
        "largest_cm3": float(final.max() * voxel_cm3) if final.size > 1 else 0.0,
        "threads_cm3": 0.0,
        "thin_layer_moved_cm3": 0.0,
        "thin_layer_dropped_cm3": 0.0,
        "single_slice_dropped": 0,
        "boundary_cut": 0.0,
        "boundary_cut_clamped": False,
        # Every voxel of the mask was given to a core by the grow-back, so
        # nothing here was left to a nearest-label guess over open ground.
        "filled_fraction": 0.0,
        "unassigned_fraction": float((out == 0).sum() - (labels == 0).sum())
        / max(1, int((labels > 0).sum())),
    }


def _merge_class_stats(total: dict, part: dict) -> dict:
    """Add one class's figures to the running total.

    A CT is segmented a class at a time, so the numbers the status line reads
    arrive in pieces. Volumes add up; the largest is the largest of any of
    them; the share that was guessed is weighted by how much tissue each class
    contributed, because an unweighted average would let a tiny class sway it.
    """
    merged = dict(total) if total else {}
    for key in ("muscle_cm3", "threads_cm3", "thin_layer_moved_cm3",
                "thin_layer_dropped_cm3", "regions", "muscles",
                "single_slice_dropped"):
        merged[key] = merged.get(key, 0) + part.get(key, 0)
    merged["largest_cm3"] = max(merged.get("largest_cm3", 0.0),
                                part.get("largest_cm3", 0.0))
    # Running sums, divided out each time rather than averaging an average -
    # dividing in place would re-weight figures that had already been divided.
    weight = float(part.get("muscle_cm3", 0.0))
    merged["_weight"] = merged.get("_weight", 0.0) + weight
    for key in ("filled_fraction", "unassigned_fraction"):
        total_key = "_sum_" + key
        merged[total_key] = (merged.get(total_key, 0.0)
                             + float(part.get(key, 0.0)) * weight)
        if merged["_weight"] > 0.0:
            merged[key] = merged[total_key] / merged["_weight"]
    merged.setdefault("boundary_cut", part.get("boundary_cut", 0.0))
    merged["boundary_cut_clamped"] = bool(merged.get("boundary_cut_clamped")
                                          or part.get("boundary_cut_clamped"))
    return merged


def _place_feature(context, props, feature, target, spacing):
    """Hand one finished feature to Blender. Main thread only."""
    extra = {}
    if feature.get("hu") is not None:
        extra["HU"] = feature["hu"]
    obj = _create_point_cloud_object(
        context, feature["points"], feature["shades"], spacing, props,
        object_name="{}_{:02d}".format(feature.get("name", "Muscle"),
                                       feature["index"]),
        extra_attributes=extra or None,
    )
    if obj is not None and obj.type == "POINTCLOUD":
        obj["dicom_source_path"] = props.source_path
        obj["dicom_station_position"] = float(target)
        obj["dicom_muscle_index"] = int(feature["index"])
        obj["dicom_class"] = str(feature.get("name", "Muscle"))
        lattice = feature.get("lattice")
        if lattice is not None:
            # Enough to put the points back on the lattice they came from,
            # without needing the study or the settings that made them.
            origin, axes, step = lattice
            obj["dicom_voxel_origin"] = list(origin)
            obj["dicom_voxel_axes"] = [c for axis in axes for c in axis]
            obj["dicom_voxel_spacing"] = list(step)
    return obj


def _class_tally(result) -> str:
    """How many of each tissue class came out, when there are classes.

    A CT is segmented a class at a time, and "47 features" says much less
    than "10 bones, 11 muscles, 20 fat" about whether the run worked.
    """
    classes = result.get("classes") or {}
    if not classes:
        return ""
    counts = {}
    for name in classes.values():
        counts[name] = counts.get(name, 0) + 1
    order = ("Bone", "Muscle", "Fat")
    parts = [f"{counts[name]} {name.lower()}"
             for name in order if counts.get(name)]
    parts += [f"{count} {name.lower()}" for name, count in sorted(counts.items())
              if name not in order]
    return " | " + ", ".join(parts) if parts else ""


def _segmented_status(result, target, made, total) -> str:
    from .muscle import TIER_FULL, TIER_NOTES

    stats = result["stats"]
    return (
        "{} feature(s) at station {:.0f}, {:,} points".format(made, target, total)
        + (" | enhanced" if result["enhanced"] else "")
        + _class_tally(result)
        + ("" if result.get("tier", TIER_FULL) == TIER_FULL else
           " | from {} ({})".format(", ".join(result.get("used", [])),
                                    TIER_NOTES.get(result["tier"], "")))
        + " | {:,.0f}cm3 of tissue, largest {:,.0f}cm3".format(
            stats["muscle_cm3"], stats.get("largest_cm3", 0.0))
        + (" | {:,.0f}cm3 of threads removed".format(stats["threads_cm3"])
           if stats.get("threads_cm3", 0.0) >= 0.5 else "")
        + (" | {:,.0f}cm3 of thin layers moved to what they sit on".format(
            stats["thin_layer_moved_cm3"])
           if stats.get("thin_layer_moved_cm3", 0.0) >= 0.5 else "")
        # Worth saying out loud. When the interior comes out sparse the
        # boundaries between features are not found, they are a
        # nearest-structure guess, and the user has no other way to see that
        # the numbers mean less than they look like they do.
        + (" | WARNING {:.0f}% of this was filled in by nearest structure, "
           "not segmented - lower Boundary Strength".format(
               100 * stats["filled_fraction"])
           if stats.get("filled_fraction", 0.0) > 0.5 else "")
        + (" | Safe Mode capped some features" if result["capped"] else "")
        + (" | boundary capped to {:.2f} - the value asked for was above the "
           "tissue's own brightness".format(stats["boundary_cut"])
           if stats.get("boundary_cut_clamped") else "")
    )


class DICOM_OT_add_voxel_remesh(bpy.types.Operator):
    bl_idname = "dicom.add_voxel_remesh"
    bl_label = "Add Voxel Remesh"
    bl_description = (
        "Add a Voxel Remesh modifier sized to this mesh. The modifier's own "
        "default voxel size assumes an object a couple of units across, and "
        "these are in millimetres, so the default asks for a grid thousands of "
        "cells on a side and Blender runs out of memory"
    )
    bl_options = {"REGISTER", "UNDO"}

    GRID_MINIMUM = 32
    """Fewest cells along the longest side. The typical edge length reads the
    lattice off a reconstruction, but on a mesh from somewhere else - a plain
    cube, say - the typical edge is the whole object, and a voxel that size
    would dissolve it."""

    VERTS_PER_CELL = 1.3
    """How many vertices a voxel remesh returns per voxel of surface area.

    Measured across three voxel sizes on one reconstruction: 3.89M, 16.26M and
    66.86M vertices against area/voxel^2 of 3.21M, 12.85M and 51.3M - a ratio
    of 1.21, 1.27 and 1.30. Used to keep the result inside the vertex budget
    instead of finding out afterwards.
    """

    @classmethod
    def poll(cls, context):
        return any(obj.type == "MESH" for obj in context.selected_objects)

    def execute(self, context):
        props = context.scene.dicom_import_props
        detail = float(props.remesh_detail)
        budget = max(1, int(props.mesh_max_vertices_m)) * 1_000_000

        done = []
        for obj in context.selected_objects:
            if obj.type != "MESH":
                continue
            size, limited = self._voxel_size_for(obj, detail, budget)
            existing = next((m for m in obj.modifiers if m.type == "REMESH"), None)
            mod = existing or obj.modifiers.new("Remesh", "REMESH")
            mod.mode = "VOXEL"
            mod.voxel_size = size
            done.append("{} at {:.3g}{}".format(
                obj.name, size, " (held to the vertex budget)" if limited else ""))

        if not done:
            self.report({"ERROR"}, "Select at least one mesh")
            return {"CANCELLED"}
        self.report({"INFO"}, "Voxel remesh: " + ", ".join(done))
        return {"FINISHED"}

    @staticmethod
    def _surface_area(mesh) -> float:
        """Total area, which is what decides how big the remesh comes out."""
        try:
            mesh.calc_loop_triangles()
            tris = np.empty(len(mesh.loop_triangles) * 3, dtype=np.int32)
            mesh.loop_triangles.foreach_get("vertices", tris)
            co = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
            mesh.vertices.foreach_get("co", co)
        except Exception:
            return 0.0
        co = co.reshape(-1, 3)
        tris = tris.reshape(-1, 3)
        if not len(tris):
            return 0.0
        p = co[tris]
        cross = np.cross(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0])
        return 0.5 * float(np.linalg.norm(cross, axis=1).sum())

    def _voxel_size_for(self, obj, detail: float, budget: int):
        """Voxel size for this mesh. Returns ``(size, held_to_budget)``.

        The typical edge length reads the lattice the mesh was built on
        straight off the mesh. A voxel that size keeps about two thirds of the
        surface area, because resampling a surface at its own sampling rate
        cannot hold the finest thing in it - so Detail scales it down from
        there, and the vertex budget stops it going finer than the machine can
        carry.
        """
        mesh = obj.data
        step = 0.0
        n_edges = len(mesh.edges)
        if n_edges:
            idx = np.empty(n_edges * 2, dtype=np.int32)
            mesh.edges.foreach_get("vertices", idx)
            co = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
            mesh.vertices.foreach_get("co", co)
            co = co.reshape(-1, 3)
            pairs = idx.reshape(-1, 2)
            if n_edges > 200_000:
                rng = np.random.default_rng(0)
                pairs = pairs[rng.choice(n_edges, 200_000, replace=False)]
            lengths = np.linalg.norm(co[pairs[:, 0]] - co[pairs[:, 1]], axis=1)
            lengths = lengths[lengths > 0.0]
            if lengths.size:
                step = float(np.median(lengths))

        longest = max(float(v) for v in obj.dimensions) if obj.dimensions else 0.0
        if longest <= 0.0:
            return (step if step > 0.0 else 0.1), False
        ceiling = longest / float(self.GRID_MINIMUM)
        if step <= 0.0:
            step = ceiling
        wanted = step * max(0.05, float(detail))

        # The finest voxel this mesh can be remeshed at and still fit in the
        # budget. Below it the result is not a better mesh, it is an
        # unresponsive Blender.
        area = self._surface_area(mesh)
        floor = 0.0
        if area > 0.0 and budget > 0:
            floor = float(np.sqrt(self.VERTS_PER_CELL * area / float(budget)))

        size = min(max(wanted, floor), ceiling)
        return size, bool(floor > wanted + 1e-9)


def _store_lattice(obj, lattice) -> None:
    """Record the voxel grid a cloud's points sit on."""
    if obj is None or lattice is None:
        return
    origin, axes, step = lattice
    obj["dicom_voxel_origin"] = [float(v) for v in origin]
    obj["dicom_voxel_axes"] = [float(c) for axis in axes for c in axis]
    obj["dicom_voxel_spacing"] = [float(v) for v in step]


def _copy_lattice(source, target) -> None:
    """Carry the grid onto a cloud made by keeping some of the points.

    Filtering and surface extraction both drop points without moving any, so
    the grid is unchanged and the result is still splittable. Upsampling is
    not in this list on purpose: it puts points between the old ones, so the
    grid it came from no longer describes it.
    """
    if source is None or target is None:
        return
    for key in ("dicom_voxel_origin", "dicom_voxel_axes",
                "dicom_voxel_spacing", "dicom_source_path",
                "dicom_series_uid", "dicom_station_position", "dicom_class"):
        if source.get(key) is not None:
            target[key] = source[key]


def _infer_lattice(obj):
    """Work the grid out from the points, for clouds that never recorded it.

    Only accepted when the points really do sit on an even axis-aligned grid:
    the step is taken from the gaps actually present, and every coordinate
    then has to land on it. A cloud placed at an angle in patient space does
    not, and gets no inferred grid rather than a wrong one.
    """
    cloud = getattr(obj, "data", None)
    count = len(cloud.points) if cloud is not None else 0
    if count < 8:
        return None
    coords = np.empty(count * 3, dtype=np.float32)
    try:
        cloud.points.foreach_get("co", coords)
    except Exception:
        return None
    coords = coords.reshape(-1, 3).astype(np.float64)

    origin = []
    step = []
    for axis in range(3):
        values = np.unique(np.round(coords[:, axis], 4))
        if values.size < 2:
            origin.append(float(coords[:, axis].min()))
            step.append(1.0)
            continue
        gaps = np.diff(values)
        gaps = gaps[gaps > 1e-6]
        if gaps.size == 0:
            return None
        size = float(np.median(gaps))
        if size <= 1e-6:
            return None
        start = float(values[0])
        offset = (coords[:, axis] - start) / size
        if float(np.mean(np.abs(offset - np.rint(offset)) < 0.1)) < 0.99:
            return None
        origin.append(start)
        step.append(size)

    identity = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
    return origin, identity, step


def _cloud_lattice(obj):
    """The voxel grid a cloud came from, or None if it does not know."""
    origin = obj.get("dicom_voxel_origin")
    axes = obj.get("dicom_voxel_axes")
    spacing = obj.get("dicom_voxel_spacing")
    if origin is None or axes is None or spacing is None:
        return _infer_lattice(obj)
    flat = [float(v) for v in axes]
    if len(flat) != 9 or len(origin) != 3 or len(spacing) != 3:
        return None
    return ([float(v) for v in origin],
            [flat[0:3], flat[3:6], flat[6:9]],
            [float(v) for v in spacing])


def _read_cloud_attribute(cloud, name):
    """One float attribute off a point cloud, or None if it is not there."""
    attr = cloud.attributes.get(name)
    if attr is None:
        return None
    values = np.empty(len(cloud.points), dtype=np.float32)
    try:
        attr.data.foreach_get("value", values)
    except Exception:
        return None
    return values


class DICOM_OT_split_selected_cloud(bpy.types.Operator):
    bl_idname = "dicom.split_selected_cloud"
    bl_label = "Split Selected Cloud"
    bl_description = (
        "Separate the selected cloud further, using only that cloud's own "
        "data. Everything the pass needs - the points, the Hounsfield number "
        "each one measured, and the lattice they sit on - is already on the "
        "object, so the study is not read again and only the region you "
        "picked is worked on"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(obj.type == "POINTCLOUD" for obj in context.selected_objects)

    def execute(self, context):
        from .muscle import split_into
        from .pointcloud import voxel_indices

        props = context.scene.dicom_import_props
        wanted = max(2, int(getattr(props, "muscle_split_pieces", 2)))
        made = []
        skipped = []
        short = []

        for source in [o for o in context.selected_objects
                       if o.type == "POINTCLOUD"]:
            lattice = _cloud_lattice(source)
            if lattice is None:
                skipped.append(f"{source.name}: imported before this existed, "
                               f"re-import to use it")
                continue
            origin, axes, spacing = lattice
            cloud = source.data
            count = len(cloud.points)
            if count < 8:
                skipped.append(f"{source.name}: too few points")
                continue

            co = np.empty(count * 3, dtype=np.float32)
            cloud.points.foreach_get("co", co)
            points = co.reshape(-1, 3)

            # Hounsfield units if the cloud has them, otherwise the
            # brightness every imported cloud carries. Neither is required:
            # the split is decided by shape - which cores sit deepest - and
            # the values only break ties between cores at equal depth. This
            # used to refuse anything without HU, which is every cloud except
            # a segmented CT, so an ordinary import could never be split.
            measured = _read_cloud_attribute(cloud, "HU")
            background = -1000.0
            if measured is None:
                measured = _read_cloud_attribute(cloud, "Intensity")
                background = 0.0

            index = voxel_indices(points, origin, axes, spacing)
            index -= index.min(axis=0)
            shape = tuple(int(v) + 1 for v in index.max(axis=0))[::-1]
            if int(np.prod(shape)) > 400_000_000:
                skipped.append(f"{source.name}: region too large to rebuild")
                continue

            # The piece's own little volume, just big enough to hold it.
            mask = np.zeros(shape, dtype=bool)
            mask[index[:, 2], index[:, 1], index[:, 0]] = True
            values = None
            if measured is not None:
                values = np.full(shape, background, dtype=np.float32)
                values[index[:, 2], index[:, 1], index[:, 0]] = measured

            voxel_cm3 = float(np.prod(spacing)) / 1000.0
            # Not the import's own pass - that is the same operation on the
            # same data, so it either reproduces the division already made or
            # finds nothing. What this can do instead is take the number from
            # the person looking at the piece.
            labels = split_into(
                mask, wanted, voxel_cm3, values=values,
                min_core_cm3=max(1e-4, float(props.muscle_bone_core)))

            pieces = [v for v in range(1, int(labels.max()) + 1)
                      if (labels == v).any()]
            if len(pieces) < 2:
                skipped.append(f"{source.name}: only one centre in it")
                continue
            if len(pieces) < wanted:
                short.append(f"{source.name} has {len(pieces)}, not {wanted}")

            at = labels[index[:, 2], index[:, 1], index[:, 0]]
            for order, value in enumerate(pieces, start=1):
                keep = at == value
                if int(keep.sum()) < 8:
                    continue
                obj = _create_point_cloud_object(
                    context, points[keep],
                    np.clip((measured[keep] + 200.0) / 1200.0, 0.0, 1.0),
                    spacing, props,
                    object_name=f"{source.name}_{order:02d}",
                    apply_stride=False,
                    extra_attributes={"HU": measured[keep]},
                )
                if obj is None:
                    continue
                for key in ("dicom_source_path", "dicom_series_uid",
                            "dicom_station_position", "dicom_class",
                            "dicom_voxel_origin", "dicom_voxel_axes",
                            "dicom_voxel_spacing"):
                    if source.get(key) is not None:
                        obj[key] = source[key]
                made.append(obj.name)
            source.hide_set(True)

        parts = []
        if made:
            parts.append(f"{len(made)} piece(s) from "
                         f"{len(set(n.rsplit('_', 1)[0] for n in made))} cloud(s)")
        for note in short:
            parts.append(note)
        for note in skipped:
            parts.append(note)
        props.status = "; ".join(parts) or "Nothing to split"
        self.report({"INFO" if made else "WARNING"}, props.status)
        return {"FINISHED"} if made else {"CANCELLED"}


class DICOM_OT_import_contrast_group(bpy.types.Operator):
    bl_idname = "dicom.import_contrast_group"
    bl_label = "Import All Of Type"
    bl_description = (
        "Import every series of the chosen Dixon type in this study - one point "
        "cloud per station, each placed where the scanner recorded it"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.dicom_import_props
        try:
            from .io_dicom import (
                DIXON_CONTRAST_LABELS,
                discover_series,
            )
        except ModuleNotFoundError as exc:
            self.report({"ERROR"}, f"Missing dependency: {exc.name}")
            return {"CANCELLED"}

        if not props.source_path:
            self.report({"ERROR"}, "Set Source Path first")
            return {"CANCELLED"}

        wanted = str(props.import_contrast)
        try:
            series = discover_series(props.source_path, props.source_is_zip)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            props.status = f"Scan failed: {exc}"
            return {"CANCELLED"}

        matching = [s for s in series if s.contrast == wanted]
        if not matching:
            found = sorted({s.contrast for s in series if s.contrast})
            names = ", ".join(DIXON_CONTRAST_LABELS[c] for c in found) or "none"
            self.report(
                {"ERROR"},
                f"No {DIXON_CONTRAST_LABELS.get(wanted, wanted)} series here. "
                f"Recognised in this study: {names}",
            )
            props.status = "No series of that type"
            return {"CANCELLED"}

        # Head to toe, so the object list reads in anatomical order rather than
        # whatever order the files happened to be walked in.
        matching.sort(key=lambda item: item.position)
        label = DIXON_CONTRAST_LABELS.get(wanted, wanted)

        made = 0
        total = 0
        skipped = []
        for index, info in enumerate(matching, start=1):
            try:
                points, intensities, spacing, _note, _stats = _load_series_cloud(
                    props, info.uid
                )
            except Exception as exc:
                skipped.append(f"station {index}: {exc}")
                continue

            if points.shape[0] == 0:
                skipped.append(f"station {index}: no points above threshold")
                continue

            if bool(props.safe_mode) and points.shape[0] > int(props.safe_cap_points):
                rng = np.random.default_rng(42)
                keep = rng.choice(
                    points.shape[0], size=int(props.safe_cap_points), replace=False
                )
                points = points[keep]
                intensities = intensities[keep]

            obj = _create_point_cloud_object(
                context,
                points,
                intensities,
                spacing,
                props,
                object_name=f"{label.replace(' ', '')}_{index:02d}",
            )
            if obj is not None and obj.type == "POINTCLOUD":
                obj["dicom_source_path"] = props.source_path
                obj["dicom_source_is_zip"] = bool(props.source_is_zip)
                obj["dicom_series_uid"] = info.uid
                obj["dicom_contrast"] = wanted
                obj["dicom_station_position"] = float(info.position)
            made += 1
            total += int(points.shape[0])

        if not made:
            props.status = f"Imported nothing: {'; '.join(skipped)}"
            self.report({"ERROR"}, props.status)
            return {"CANCELLED"}

        placed = "patient position" if props.place_in_patient_space else "centred"
        props.status = (
            f"Imported {made} {label} station(s), {total:,} points, {placed}"
        )
        self.report({"INFO"}, props.status)
        for message in skipped:
            self.report({"WARNING"}, message)
        return {"FINISHED"}


class DICOM_OT_segment_bones(bpy.types.Operator):
    bl_idname = "dicom.segment_bones"
    bl_label = "Segment Cloud"
    bl_description = (
        "Separate the selected point cloud into intensity ranges - one cloud per "
        "range, sorted by brightness"
    )
    bl_options = {"REGISTER"}


    def _start_worker(self, target):
        self._worker_done = False
        self._worker_result = None
        self._worker_error = None

        def _runner():
            try:
                self._worker_result = target()
            except Exception as exc:
                self._worker_error = str(exc)
            finally:
                self._worker_done = True

        self._worker_thread = threading.Thread(target=_runner, daemon=True)
        self._worker_thread.start()

    def _output_spacing(self, points):
        """Spacing to size the generated cloud's points by.

        The volume path has the scan spacing. The cloud path has none - it never
        loaded a volume - so fall back to the spacing measured from the source
        cloud, then to the spacing of these points, then to unit spacing. Any of
        those is a real number, which is what matters: passing None here used to
        raise inside the point-cloud builder.
        """
        spacing = getattr(self, "_spacing", None)
        if spacing is not None:
            return spacing

        measured = (getattr(self, "_split_stats", None) or {}).get("point_spacing")
        if measured and all(float(v) > 0.0 for v in measured):
            return tuple(float(v) for v in measured)

        try:
            from .voxelgrid import estimate_lattice_spacing

            estimated = estimate_lattice_spacing(points)
            if all(float(v) > 0.0 for v in estimated):
                return tuple(float(v) for v in estimated)
        except Exception:
            pass
        return (1.0, 1.0, 1.0)

    def _split_selected_cloud(self):
        """Band the selected cloud by brightness. The only split there is."""
        split_stats = {}
        self._split_stats = split_stats
        return self._split_pointcloud_by_intensity(
            points=self._cloud_points,
            intensities=self._cloud_intensities,
            range_count=max(2, int(self._props.local_intensity_bands)),
            stats=split_stats,
        )

    def _begin_local_preparing(self, context, reason: str | None = None):
        if reason:
            self.report({"WARNING"}, reason)
        self._local_prepare_reason = reason or ""
        self._stage = "local_preparing"
        _set_progress(context, self._props, 3.0, "Banding the cloud by brightness")

        def _task():
            # No volume is loaded and no grid is built: banding compares each
            # point's own brightness against the band edges and nothing else.
            return None, None, self._split_selected_cloud()

        self._start_worker(_task)
        return {"RUNNING_MODAL"}

    def _start_local_components(self, context, reason: str | None = None):
        return self._begin_local_preparing(context, reason)

    def _cancel_with_error(self, context, message: str):
        props = context.scene.dicom_import_props
        props.status = message
        level = {"WARNING"} if "cancelled" in message.lower() else {"ERROR"}
        self.report(level, message)
        self._teardown(context)
        return {"CANCELLED"}

    def _teardown(self, context):
        global ACTIVE_SEGMENTATION_OPERATOR
        wm = context.window_manager

        source_context = getattr(self, "_source_context", None)
        if source_context is not None:
            try:
                source_context.cleanup()
            except Exception:
                pass
        self._source_context = None

        timer = getattr(self, "_timer", None)
        if timer is not None:
            try:
                wm.event_timer_remove(timer)
            except Exception:
                pass
        self._timer = None

        try:
            wm.progress_end()
        except Exception:
            pass

        try:
            props = context.scene.dicom_import_props
            props.segmentation_running = False
        except Exception:
            pass

        if ACTIVE_SEGMENTATION_OPERATOR is self:
            ACTIVE_SEGMENTATION_OPERATOR = None

    def invoke(self, context, event):
        global ACTIVE_SEGMENTATION_OPERATOR
        props = context.scene.dicom_import_props

        if ACTIVE_SEGMENTATION_OPERATOR is not None:
            self.report({"WARNING"}, "Segmentation is already running")
            return {"CANCELLED"}

        selected_cloud = _get_selected_imported_pointcloud(context)
        source_path = props.source_path
        source_is_zip = bool(props.source_is_zip)
        series_uid = props.series_uid
        target_object_name = ""

        cloud_points = None
        if selected_cloud is not None:
            target_object_name = selected_cloud.name
            source_path = str(selected_cloud.get("dicom_source_path", source_path) or source_path)
            source_is_zip = bool(selected_cloud.get("dicom_source_is_zip", source_is_zip))
            series_uid = str(selected_cloud.get("dicom_series_uid", series_uid) or series_uid)
            selected_cloud["dicom_source_path"] = source_path
            selected_cloud["dicom_source_is_zip"] = source_is_zip
            selected_cloud["dicom_series_uid"] = series_uid

            # Keep the cloud's own coordinates so the reloaded scan can be cut
            # down to the region the user actually imported.
            try:
                cloud_points, _values = _read_pointcloud_arrays(selected_cloud)
            except Exception as exc:
                self.report({"WARNING"}, f"Could not read cloud extent: {exc}")
                cloud_points = None

        # Brightness is the only thing segmentation splits on, and only a point
        # cloud carries per-point brightness, so the cloud is the only source.
        self._cloud_intensities = None
        if selected_cloud is None:
            self.report(
                {"ERROR"},
                "Select a point cloud to split",
            )
            return {"CANCELLED"}
        if cloud_points is None:
            try:
                cloud_points, _v = _read_pointcloud_arrays(selected_cloud)
            except Exception as exc:
                self.report({"ERROR"}, f"Could not read the point cloud: {exc}")
                return {"CANCELLED"}
        self._cloud_intensities = _extract_cloud_intensity_values(selected_cloud.data)
        if self._cloud_intensities is None:
            self.report(
                {"WARNING"},
                "Cloud has no Intensity attribute; seam detection will be geometric only",
            )

        try:
            from .io_dicom import load_series_volume
            from .segmentation import (
                build_points_from_point_indices,
                split_pointcloud_by_intensity,
            )
        except ModuleNotFoundError as exc:
            self.report({"ERROR"}, f"Missing dependency: {exc.name}")
            props.status = f"Missing dependency: {exc.name}"
            return {"CANCELLED"}

        wm = context.window_manager
        wm.progress_begin(0.0, 100.0)
        _set_progress(context, props, 1.0, "Preparing segmentation")

        self._props = props
        from .pointcloud import crop_volume_to_points

        self._crop_volume_to_points = crop_volume_to_points
        self._cloud_points = cloud_points
        self._volume_origin = None
        self._crop_bounds = None
        self._crop_rejected = ""
        self._volume_probe = {}
        # NOTE: _cloud_intensities is read earlier in this function. Do not
        # re-initialise it here - an earlier version did, and silently sent
        # every run down a path with no brightness to split on.
        self._split_pointcloud_by_intensity = split_pointcloud_by_intensity
        self._build_points_from_point_indices = build_points_from_point_indices

        self._source_context = None
        self._volume = None
        self._spacing = None
        self._split_stats = {}
        self._local_components = []
        self._mask_index = 0
        self._created = 0
        self._bone_collection = None
        self._warned_safe_cap = False
        self._cancel_requested = False
        self._worker_thread = None
        self._worker_done = False
        self._worker_result = None
        self._worker_error = None
        self._local_prepare_reason = ""
        self._segment_source_path = source_path
        self._segment_source_is_zip = source_is_zip
        self._segment_series_uid = series_uid
        self._target_object_name = target_object_name

        props.segmentation_running = True
        ACTIVE_SEGMENTATION_OPERATOR = self

        self._begin_local_preparing(context)

        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC":
            return self._cancel_with_error(context, "Segmentation cancelled")

        if getattr(self, "_cancel_requested", False):
            return self._cancel_with_error(context, "Segmentation cancelled by user")

        if event.type != "TIMER":
            # Keep this modal operator exclusive while running to avoid UI/operator races
            # with heavy point-cloud creation in Blender 5.1.
            return {"RUNNING_MODAL"}

        props = self._props

        if self._stage == "local_preparing":
            if not self._worker_done:
                _set_progress(context, props, 35.0, "Preparing native split")
                return {"RUNNING_MODAL"}

            if self._worker_error:
                return self._cancel_with_error(context, f"Native split prep failed: {self._worker_error}")

            self._volume, self._spacing, self._local_components = self._worker_result

            crop_rejected = getattr(self, "_crop_rejected", "")
            if crop_rejected:
                self.report({"WARNING"}, crop_rejected)
                self._crop_rejected = ""

            split_stats = getattr(self, "_split_stats", None) or {}
            ranges = split_stats.get("ranges") or []
            if ranges:
                self.report(
                    {"INFO"},
                    "Separated {:,} points into {} intensity ranges".format(
                        int(split_stats.get("input_points", 0)), len(ranges)
                    ),
                )
                for entry in ranges:
                    lo, hi = entry["range"]
                    self.report(
                        {"INFO"},
                        "  range {}: {:.4f}..{:.4f}  {:,} points".format(
                            entry["index"] + 1, lo, hi, entry["points"]
                        ),
                    )

            crop = getattr(self, "_crop_bounds", None)
            if crop:
                full_shape, crop_shape, _bounds = crop
                full = float(full_shape[0]) * full_shape[1] * full_shape[2]
                kept = float(crop_shape[0]) * crop_shape[1] * crop_shape[2]
                if full > 0:
                    self.report(
                        {"INFO"},
                        "Limited to the selected cloud: {}x{}x{} of {}x{}x{} voxels "
                        "({:.1f}% of the scan)".format(
                            crop_shape[2], crop_shape[1], crop_shape[0],
                            full_shape[2], full_shape[1], full_shape[0],
                            100.0 * kept / full,
                        ),
                    )
            if not self._local_components:
                probe = getattr(self, "_volume_probe", None) or {}
                split_stats = getattr(self, "_split_stats", None) or {}
                detail = ""
                if probe:
                    shape = probe.get("shape", ("?", "?", "?"))
                    detail = (
                        " Region {}x{}x{} voxels, HU {:.0f}..{:.0f}, {:,} voxels at or above "
                        "Bone HU, {:,} at or above Core HU, {} usable cores.".format(
                            shape[2], shape[1], shape[0],
                            probe.get("hu_min", 0.0), probe.get("hu_max", 0.0),
                            probe.get("bone_voxels", 0), probe.get("core_voxels", 0),
                            split_stats.get("markers", "no"),
                        )
                    )
                    if probe.get("bone_voxels", 0) == 0:
                        detail += (
                            " Nothing meets Bone HU at all - lower it, or the region is wrong."
                        )
                    elif probe.get("core_voxels", 0) == 0:
                        detail += " Nothing meets Core HU - lower Core HU."
                    else:
                        detail += (
                            " Bone was found, so lower Min Core Voxels or Local Min Voxels."
                        )
                return self._cancel_with_error(
                    context,
                    "Segmentation produced no bone components." + detail,
                )

            target_collection_name = "DICOM_Bones"
            self._bone_collection = bpy.data.collections.get(target_collection_name)
            if self._bone_collection is None:
                self._bone_collection = bpy.data.collections.new(target_collection_name)
                context.scene.collection.children.link(self._bone_collection)

            self._mask_index = 0
            _set_progress(context, props, 78.0, f"Processing {len(self._local_components)} native components")
            self._stage = "process_local_components"
            return {"RUNNING_MODAL"}

        if self._stage == "process_local_components":
            if self._mask_index >= len(self._local_components):
                if self._created == 0:
                    return self._cancel_with_error(context, "Split completed, but no bone point clouds were created")

                target_name = getattr(self, "_target_object_name", "")
                if target_name:
                    src_obj = bpy.data.objects.get(target_name)
                    if src_obj is not None:
                        src_obj.hide_set(True)

                _set_progress(context, props, 100.0, f"Created {self._created} bone point cloud objects")
                props.status = f"Created {self._created} bone point cloud objects"
                self.report({"INFO"}, props.status)
                self._teardown(context)
                return {"FINISHED"}

            comp = self._local_components[self._mask_index]
            total = max(1, len(self._local_components))
            start_progress = 78.0 + (20.0 * (float(self._mask_index) / float(total)))
            _set_progress(context, props, start_progress, f"Building bone {self._mask_index + 1}/{total}")

            # No cap and no Safe Mode trim: separating means every point
            # ends up in exactly one range. Truncating a range would silently
            # lose points the user asked to be sorted, and the total across all
            # ranges is the source cloud, which is already in the scene.
            effective_max_points = 0

            source_intensities = self._cloud_intensities
            if source_intensities is None:
                source_intensities = np.ones(len(self._cloud_points), dtype=np.float32)
            points, intensities = self._build_points_from_point_indices(
                component_idx=comp,
                points=self._cloud_points,
                intensities=source_intensities,
                max_points=effective_max_points,
            )

            if points.shape[0] > 0:
                obj_name = f"Range_{self._mask_index + 1:02d}"
                # No volume is loaded, so there is no scan spacing. The
                # cloud's own sample spacing is the right basis for point radius
                # anyway, and the import stride must not be applied again to a
                # cloud that already has it baked in.
                obj = _create_point_cloud_object(
                    context=context,
                    points=points,
                    intensities=intensities,
                    spacing=self._output_spacing(points),
                    props=props,
                    object_name=obj_name,
                    apply_stride=False,
                )
                try:
                    context.collection.objects.unlink(obj)
                except Exception:
                    pass
                self._bone_collection.objects.link(obj)
                self._created += 1

            self._mask_index += 1
            done_progress = 78.0 + (20.0 * (float(self._mask_index) / float(total)))
            _set_progress(context, props, done_progress, f"Built {self._created} bone objects")
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}


class DICOM_OT_cancel_segmentation(bpy.types.Operator):
    bl_idname = "dicom.cancel_segmentation"
    bl_label = "Stop Segmentation"
    bl_description = "Stop the currently running segmentation job"

    def execute(self, context):
        global ACTIVE_SEGMENTATION_OPERATOR
        op = ACTIVE_SEGMENTATION_OPERATOR
        props = context.scene.dicom_import_props

        if op is None:
            props.segmentation_running = False
            self.report({"WARNING"}, "No segmentation job is running")
            return {"CANCELLED"}

        op._cancel_requested = True
        props.status = "Stopping segmentation..."
        self.report({"INFO"}, "Stop requested")
        return {"FINISHED"}
