from __future__ import annotations

import numpy as np


def volume_world_origin(shape, spacing):
    """World XYZ of voxel (0, 0, 0) for a cloud built by this module.

    ``build_points_from_volume`` centres the cloud on the origin, so anything
    that needs to line geometry up with an imported cloud - the isosurface
    extractor in particular - has to know where voxel zero landed. Keeping that
    arithmetic in one place is what stops the mesh from drifting half a voxel
    away from its point cloud.
    """
    nz, ny, nx = (int(v) for v in shape)
    sx, sy, sz = (float(v) for v in spacing)
    return (
        -((nx - 1) * sx) / 2.0,
        -((ny - 1) * sy) / 2.0,
        -((nz - 1) * sz) / 2.0,
    )


def volume_index_bounds_for_points(points, shape, spacing, margin_voxels: int = 2):
    """Index range of a volume that the given points actually cover.

    Returns ``((z0, z1), (y0, y1), (x0, x1))`` as half-open slices, clamped to
    the volume. ``margin_voxels`` pads each side so a surface right on the
    boundary is not clipped.

    The points are assumed to be in the centred world space
    ``build_points_from_volume`` produces. That holds even when the cloud was
    generated from a resampled (resolution-enhanced) volume, because both share
    the same physical extent and both centre on it - only the sample count
    differs.
    """
    pts = np.asarray(points, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] == 0:
        nz, ny, nx = (int(v) for v in shape)
        return ((0, nz), (0, ny), (0, nx))

    nz, ny, nx = (int(v) for v in shape)
    sx, sy, sz = (max(1e-9, float(v)) for v in spacing)
    ox, oy, oz = volume_world_origin(shape, (sx, sy, sz))
    margin = max(0, int(margin_voxels))

    lower = pts.min(axis=0)
    upper = pts.max(axis=0)

    def _span(lo, hi, origin, step, count):
        i0 = int(np.floor((lo - origin) / step)) - margin
        i1 = int(np.ceil((hi - origin) / step)) + 1 + margin
        i0 = max(0, min(i0, count - 1))
        i1 = max(i0 + 1, min(i1, count))
        return i0, i1

    return (
        _span(lower[2], upper[2], oz, sz, nz),
        _span(lower[1], upper[1], oy, sy, ny),
        _span(lower[0], upper[0], ox, sx, nx),
    )


def crop_volume_to_points(volume: np.ndarray, spacing, points, margin_voxels: int = 2):
    """Restrict a volume to the region a point cloud occupies.

    Segmentation that reloads the source series otherwise works on the whole
    scan, which for a full-body study means segmenting everything when the user
    only imported one region - slow, and it produces bones nowhere near the
    cloud they selected.

    Returns ``(cropped, origin, bounds)``. ``origin`` is the world position of
    the cropped volume's voxel ``(0, 0, 0)``; pass it wherever points are built
    from the crop, because the cropped volume's own centre is no longer the
    scan's centre and re-centring on it would displace the result.
    """
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError("volume must be 3D")

    (z0, z1), (y0, y1), (x0, x1) = volume_index_bounds_for_points(
        points, vol.shape, spacing, margin_voxels=margin_voxels
    )
    cropped = vol[z0:z1, y0:y1, x0:x1]

    sx, sy, sz = (float(v) for v in spacing)
    ox, oy, oz = volume_world_origin(vol.shape, (sx, sy, sz))
    origin = (ox + x0 * sx, oy + y0 * sy, oz + z0 * sz)
    return cropped, origin, ((z0, z1), (y0, y1), (x0, x1))


def _within(values, low: float, high: float):
    """Voxels inside the brightness window. ``high`` of 0 means no upper end.

    A lower threshold alone cannot isolate a structure that is dimmer than
    something else in the scan. On a T2 lumbar spine the vertebral marrow sits
    well below the subcutaneous fat, so every threshold that keeps the bone
    also keeps the fat, which wraps round the outside and hides it.
    """
    keep = values >= float(low)
    if float(high) > float(low):
        keep &= values <= float(high)
    return keep


def build_points_from_volume(
    volume: np.ndarray,
    spacing: tuple[float, float, float],
    threshold: float,
    stride: int,
    max_points: int,
    threshold_max: float = 0.0,
    origin=None,
    orientation=None,
    value_volume=None,
    value_range=None,
    stats=None,
):
    if volume.ndim != 3:
        raise ValueError("Volume must be a 3D array")
    if stride < 1:
        raise ValueError("Stride must be >= 1")

    # Decimate by widening the stride, not by picking points at random.
    #
    # A random subset of a lattice is not a lattice: its nearest-neighbour
    # distance is far finer than one point per cell, so the mesher's solidity
    # calibration sees an interior full of holes and coarsens the working grid
    # to compensate - measured at 2x on a capped cloud, which throws away more
    # resolution than the cap saved. Taking every n-th sample keeps the cloud on
    # a (coarser) lattice, so nothing downstream has to compensate for it.
    effective_stride = max(1, int(stride))
    if max_points > 0:
        for _ in range(8):
            sub = volume[::effective_stride, ::effective_stride, ::effective_stride]
            if int(np.count_nonzero(_within(sub, threshold, threshold_max))) <= max_points:
                break
            effective_stride += 1
    stride = effective_stride

    if stats is not None:
        # The stride can widen on its own to meet Max Points, so the caller
        # cannot work out afterwards how far apart the points ended up. It
        # has to be told, or anything that rebuilds the lattice later - a
        # later split, say - spaces the points wrong and gets a mask full of
        # holes.
        stats["stride"] = int(stride)

    sub = volume[::stride, ::stride, ::stride]
    idx = np.argwhere(_within(sub, threshold, threshold_max))

    if idx.size == 0:
        return np.empty((0, 3), dtype=np.float32), np.empty((0,), dtype=np.float32)

    if value_volume is not None:
        # Brightness read from a different volume than the one that decided
        # which voxels to keep. A segmented feature is selected by a 0/1 mask,
        # and sampling that mask gives every point the same value - a flat
        # white cloud with no visible form. The anatomy has to come from the
        # image.
        source = np.asarray(value_volume)[::stride, ::stride, ::stride]
        values = source[idx[:, 0], idx[:, 1], idx[:, 2]].astype(np.float32)
    else:
        values = sub[idx[:, 0], idx[:, 1], idx[:, 2]].astype(np.float32)

    idx = idx.astype(np.float32) * float(stride)
    sz, sy, sx = spacing[2], spacing[1], spacing[0]

    z = idx[:, 0] * sz
    y = idx[:, 1] * sy
    x = idx[:, 2] * sx

    if origin is not None and orientation is not None:
        # Patient coordinates: each cloud lands where the scanner says it was,
        # so stations of a whole-body study assemble into one body and the
        # contrasts of a Dixon acquisition land exactly on one another.
        row, col, normal = (np.asarray(v, dtype=np.float64) for v in orientation)
        length = float(np.linalg.norm(normal))
        normal = normal / length if length > 1e-9 else np.cross(row, col)
        points = (
            np.asarray(origin, dtype=np.float64)
            + x[:, None] * row
            + y[:, None] * col
            + z[:, None] * normal
        ).astype(np.float32)
    else:
        points = np.stack((x, y, z), axis=1).astype(np.float32)
        points += np.asarray(
            volume_world_origin(volume.shape, (sx, sy, sz)), dtype=np.float32
        )

    if max_points > 0 and len(points) > max_points:
        # Widening the stride is quantised, so it can still land slightly over.
        # Trim from the end rather than at random, which keeps what remains on
        # the lattice.
        points = points[:max_points]
        values = values[:max_points]

    if value_range is not None:
        # A fixed range, so every feature of one scan is shaded on the same
        # scale. Normalising each one against its own percentiles would make a
        # dim structure look as bright as a vivid one.
        low, high = (float(v) for v in value_range)
    else:
        low = float(np.percentile(values, 5.0))
        high = float(np.percentile(values, 99.0))
    if high <= low:
        high = low + 1.0

    normalized = np.clip((values - low) / (high - low), 0.0, 1.0).astype(np.float32)
    return points, normalized


def voxel_indices(points, origin, axes, spacing):
    """World positions back to the voxel indices they came from.

    The forward mapping in :func:`build_points_from_volume` is
    ``origin + x*row + y*col + z*normal`` with ``x, y, z`` the physical
    offsets along each axis. The three axes are orthonormal, so the inverse is
    a projection onto each of them and a divide by the spacing.

    Used both when a cloud is created - to record what each point measured -
    and when one is split later, to put the points back on their lattice. One
    implementation, so the two cannot drift apart.
    """
    points = np.asarray(points, dtype=np.float64)
    row, col, normal = (np.asarray(v, dtype=np.float64) for v in axes)
    offset = points - np.asarray(origin, dtype=np.float64)
    local = np.stack((offset @ row, offset @ col, offset @ normal), axis=1)
    steps = np.asarray(spacing, dtype=np.float64).reshape(1, 3)
    return np.rint(local / np.where(steps == 0.0, 1.0, steps)).astype(np.int64)


def lattice_used(volume_shape, spacing, origin=None, orientation=None,
                 stride: int = 1):
    """Where the points of :func:`build_points_from_volume` actually sit.

    Returns ``(origin, axes, step)`` such that
    ``voxel_indices(points, origin, axes, step)`` gives consecutive indices
    starting from the corner of the region - which is what rebuilding a mask
    from a cloud needs.

    Two things make this more than a restatement of the arguments. Without
    patient placement the points are not laid out from the DICOM origin at
    all, they are centred on the world origin, so the frame is different.
    And ``step`` is the spacing times the stride, because every n-th voxel was
    taken: using the voxel spacing leaves a hole between every pair of points.
    """
    step = tuple(float(v) * max(1, int(stride)) for v in spacing)
    if origin is not None and orientation is not None:
        row, col, normal = (np.asarray(v, dtype=np.float64)
                            for v in orientation)
        length = float(np.linalg.norm(normal))
        normal = normal / length if length > 1e-9 else np.cross(row, col)
        axes = (tuple(float(v) for v in row), tuple(float(v) for v in col),
                tuple(float(v) for v in normal))
        return tuple(float(v) for v in origin), axes, step

    base = volume_world_origin(
        volume_shape, (float(spacing[0]), float(spacing[1]), float(spacing[2])))
    identity = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
    return tuple(float(v) for v in base), identity, step


def shift_origin(origin, orientation, offset):
    """Move a patient-space origin by an offset given in volume axes.

    Resampling keeps the box but not the sampling inside it: the fine grid's
    first cell centre sits half an output voxel in from the edge, where the
    source grid's sat half a source voxel in. ``enhance_volume`` reports that
    shift as the origin of the grid it returns, measured along the volume's
    own axes. Without applying it the cloud sits up to half a source voxel out
    on every axis - small, consistent, and invisible until two series are laid
    over one another.
    """
    row, col, normal = (np.asarray(v, dtype=np.float64) for v in orientation)
    length = float(np.linalg.norm(normal))
    normal = normal / length if length > 1e-9 else np.cross(row, col)
    moved = (np.asarray(origin, dtype=np.float64)
             + float(offset[0]) * row
             + float(offset[1]) * col
             + float(offset[2]) * normal)
    return tuple(float(v) for v in moved)
