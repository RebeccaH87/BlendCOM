"""Pure-numpy volumetric primitives shared by the resolution and shell pipelines.

Everything here works on dense boolean/float arrays indexed ``[z, y, x]`` and is
vectorised - no scipy, no per-voxel Python loops. Blender ships numpy but not
scipy, so these are the building blocks the rest of the addon relies on.

The two primitives that matter most:

``label_regions``
    Connected-component labelling via a frontier BFS over flat indices. Total
    work is O(voxels in the mask) rather than O(voxels x diameter), which is
    what an iterative-dilation flood fill would cost. This is what lets us tell
    "air outside the patient" apart from "enclosed cavity where the bone marrow
    should be" on grids in the hundreds-of-voxels-per-axis range.

``boundary_mask``
    Solid voxels with at least one non-solid neighbour, i.e. exactly the voxels
    that are *not* surrounded on all sides. Interior voxels - points packed
    together as bulk density - are dropped.
"""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np


# Frontier expansion is chunked so a wide BFS front cannot spike memory.
_MAX_FRONTIER_ELEMENTS = 1 << 22

# Guard against accidentally allocating a grid that will not fit in RAM.
# label_regions needs ~5 bytes/voxel (bool pad + int32 labels), so 96M voxels
# is roughly a 460^3 grid at ~500 MB peak.
DEFAULT_VOXEL_BUDGET = 96_000_000


@dataclass(frozen=True)
class GridSpec:
    """Maps voxel indices ``[z, y, x]`` onto world-space coordinates.

    Attributes:
        origin: World XYZ of voxel ``(0, 0, 0)``.
        spacing: World size of one voxel along X, Y and Z.
        shape: Array shape as ``(nz, ny, nx)``.
    """

    origin: tuple[float, float, float]
    spacing: tuple[float, float, float]
    shape: tuple[int, int, int]
    coarsened: float = 1.0
    """How much the requested spacing had to be enlarged to fit a voxel budget.
    1.0 means the caller got exactly what it asked for."""

    @property
    def voxel_count(self) -> int:
        nz, ny, nx = self.shape
        return int(nz) * int(ny) * int(nx)

    @property
    def voxel_volume(self) -> float:
        sx, sy, sz = self.spacing
        return float(sx) * float(sy) * float(sz)

    def rescaled(self, factors, shape) -> "GridSpec":
        """Return a grid covering the same region at a different sample count.

        Output cell centres are placed so the two grids cover an identical
        world-space box, which is the convention ``resample.resample_volume``
        uses.
        """
        fx, fy, fz = float(factors[0]), float(factors[1]), float(factors[2])
        sx, sy, sz = self.spacing
        new_spacing = (sx / fx, sy / fy, sz / fz)
        ox, oy, oz = self.origin
        # The region edge sits half an input voxel before input centre 0; output
        # centre 0 sits half an output voxel in from that same edge.
        new_origin = (
            ox - 0.5 * sx + 0.5 * new_spacing[0],
            oy - 0.5 * sy + 0.5 * new_spacing[1],
            oz - 0.5 * sz + 0.5 * new_spacing[2],
        )
        return GridSpec(
            origin=new_origin,
            spacing=new_spacing,
            shape=(int(shape[0]), int(shape[1]), int(shape[2])),
            coarsened=self.coarsened,
        )

    def voxel_centers_world(self, idx_zyx: np.ndarray) -> np.ndarray:
        """Convert an ``(N, 3)`` array of ``[z, y, x]`` indices to world XYZ."""
        idx = np.asarray(idx_zyx)
        ox, oy, oz = self.origin
        sx, sy, sz = self.spacing
        out = np.empty((idx.shape[0], 3), dtype=np.float32)
        out[:, 0] = idx[:, 2] * sx + ox
        out[:, 1] = idx[:, 1] * sy + oy
        out[:, 2] = idx[:, 0] * sz + oz
        return out


def check_voxel_budget(
    shape,
    budget: int = DEFAULT_VOXEL_BUDGET,
    what: str = "Grid",
    hint: str = "Lower the resolution multiplier, raise the Voxel Budget, or reduce the input extent.",
) -> None:
    """Raise a readable error before a doomed allocation.

    ``hint`` names the settings that actually apply to the caller - telling
    someone to lower a resolution multiplier is useless when the grid in
    question has nothing to do with one.
    """
    nz, ny, nx = (int(v) for v in shape)
    total = nz * ny * nx
    if total > int(budget):
        raise MemoryError(
            f"{what} would need {nz}x{ny}x{nx} = {total:,} voxels, over the "
            f"{int(budget):,} voxel budget. {hint}"
        )


# --------------------------------------------------------------------------
# Neighbour shifts
# --------------------------------------------------------------------------


def _neighbor_deltas(connectivity: int) -> list:
    if connectivity not in (6, 18, 26):
        raise ValueError("connectivity must be 6, 18 or 26")
    out = []
    for dz in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dz == 0 and dy == 0 and dx == 0:
                    continue
                manhattan = abs(dz) + abs(dy) + abs(dx)
                if connectivity == 6 and manhattan != 1:
                    continue
                if connectivity == 18 and manhattan > 2:
                    continue
                out.append((dz, dy, dx))
    return out


def _axis_slices(delta: int):
    """Source and destination slices for a shift of ``delta`` along one axis."""
    if delta == 0:
        return slice(None), slice(None)
    if delta > 0:
        return slice(delta, None), slice(None, -delta)
    return slice(None, delta), slice(-delta, None)


def shift(array: np.ndarray, delta_zyx, fill) -> np.ndarray:
    """Return ``out`` where ``out[i] == array[i + delta]``, ``fill`` off the edge."""
    dz, dy, dx = delta_zyx
    out = np.full(array.shape, fill, dtype=array.dtype)
    zs, zd = _axis_slices(int(dz))
    ys, yd = _axis_slices(int(dy))
    xs, xd = _axis_slices(int(dx))
    out[zd, yd, xd] = array[zs, ys, xs]
    return out


def _iter_neighbor_views(array: np.ndarray, connectivity: int, fill):
    for delta in _neighbor_deltas(connectivity):
        yield shift(array, delta, fill)


# --------------------------------------------------------------------------
# Connected components
# --------------------------------------------------------------------------


def _flat_offsets(padded_shape, connectivity: int) -> np.ndarray:
    _pz, py, px = padded_shape
    plane = int(py) * int(px)
    offsets = {dz * plane + dy * int(px) + dx for dz, dy, dx in _neighbor_deltas(connectivity)}
    return np.array(sorted(offsets), dtype=np.int64)


def _pad_traversable(mask: np.ndarray, border_traversable: bool) -> np.ndarray:
    """Wrap ``mask`` in two rings.

    The outer ring is never traversable, which guarantees every traversable
    voxel is at least one step from the array edge - so neighbour lookups by
    flat offset can never wrap around a row. The inner ring models the space
    outside the scanned region and is traversable when ``border_traversable``.
    """
    nz, ny, nx = mask.shape
    out = np.zeros((nz + 4, ny + 4, nx + 4), dtype=bool)
    if border_traversable:
        out[1:-1, 1:-1, 1:-1] = True
    out[2:-2, 2:-2, 2:-2] = mask
    return out


def _border_shell_indices(padded_shape) -> np.ndarray:
    """Flat indices of the inner padding ring - the "outside world" seed."""
    shell = np.zeros(padded_shape, dtype=bool)
    shell[1:-1, 1:-1, 1:-1] = True
    shell[2:-2, 2:-2, 2:-2] = False
    return np.flatnonzero(shell.reshape(-1)).astype(np.int64)


def _bfs_fill(
    flat_traversable: np.ndarray,
    flat_labels: np.ndarray,
    offsets: np.ndarray,
    seed: np.ndarray,
    label: int,
) -> int:
    """Label everything reachable from ``seed``; return the voxel count."""
    frontier = np.asarray(seed, dtype=np.int64).reshape(-1)
    if frontier.size:
        frontier = frontier[flat_traversable[frontier] & (flat_labels[frontier] == 0)]
    if frontier.size == 0:
        return 0

    frontier = np.unique(frontier)
    flat_labels[frontier] = label
    total = int(frontier.size)

    block_size = max(1, _MAX_FRONTIER_ELEMENTS // max(1, int(offsets.size)))
    while frontier.size:
        collected = []
        for start in range(0, frontier.size, block_size):
            block = frontier[start : start + block_size]
            candidates = (block[:, None] + offsets[None, :]).reshape(-1)
            candidates = candidates[flat_traversable[candidates] & (flat_labels[candidates] == 0)]
            if candidates.size == 0:
                continue
            candidates = np.unique(candidates)
            # Mark inside the loop so later blocks of this same wave cannot
            # re-collect voxels an earlier block already claimed.
            flat_labels[candidates] = label
            collected.append(candidates)

        if not collected:
            break
        frontier = collected[0] if len(collected) == 1 else np.concatenate(collected)
        total += int(frontier.size)

    return total


def _row_runs(mask: np.ndarray):
    """Start and end column of every run of True, per row of the last axis."""
    nx = mask.shape[2]
    flat = mask.reshape(-1, nx)
    padded = np.zeros((flat.shape[0], nx + 2), dtype=bool)
    padded[:, 1:-1] = flat
    step = np.diff(padded.view(np.int8), axis=1)
    rows, start_col = np.nonzero(step == 1)
    _rows_again, end_col = np.nonzero(step == -1)
    return (rows.astype(np.int64), start_col.astype(np.int64),
            end_col.astype(np.int64))


def _components_of_edges(edges: np.ndarray, count: int) -> np.ndarray:
    """Component representative per node, by hooking and pointer jumping.

    Vectorised on purpose: a union-find with a Python loop over edges is slower
    than the flood fill it replaces once there are millions of them.
    """
    parent = np.arange(count, dtype=np.int64)
    if edges.size:
        left, right = edges[:, 0], edges[:, 1]
        while True:
            lowest = np.minimum(parent[left], parent[right])
            previous = parent.copy()
            np.minimum.at(parent, left, lowest)
            np.minimum.at(parent, right, lowest)
            parent = parent[parent]      # halves every chain each round
            if np.array_equal(parent, previous):
                break
    return parent


def _label_regions_runs(mask: np.ndarray, connectivity: int):
    """Connected components via runs rather than a per-voxel flood fill.

    The flood fill costs one pass over the frontier for every voxel of a
    component's diameter, which on a body-sized component in a reconstruction
    grid is hundreds of passes over millions of voxels. A row of solid voxels
    is one run, so this works on a few hundred thousand intervals instead, and
    resolves which of them are connected in one vectorised pass.

    Measured on an 87-million-voxel body: 19.0s for the flood fill, 3.7s here,
    with an identical partition. Verified identical on solid, hollow, split and
    speckled phantoms at both 6- and 26-connectivity.
    """
    mask = np.ascontiguousarray(mask, dtype=bool)
    nz, ny, nx = mask.shape
    rows, starts, ends = _row_runs(mask)
    if rows.size == 0:
        return (np.zeros(mask.shape, dtype=np.int32),
                np.array([mask.size], dtype=np.int64))

    order = np.lexsort((starts, rows))
    rows, starts, ends = rows[order], starts[order], ends[order]
    row_z, row_y = np.divmod(rows, ny)
    row_begin = np.searchsorted(rows, np.arange(nz * ny + 1), side="left")

    # 18- and 26-connectivity let runs touch diagonally, which widens the
    # overlap test by one column either side.
    slack = 1 if connectivity >= 18 else 0
    stride = nx + 2
    start_key = rows * stride + starts
    end_key = rows * stride + ends

    neighbours = []
    for dz in (-1, 0):
        for dy in (-1, 0, 1):
            if dz == 0 and dy >= 0:
                continue
            if connectivity == 6 and dz and dy:
                continue
            neighbours.append((dz, dy))

    edge_blocks = []
    for dz, dy in neighbours:
        zz, yy = row_z + dz, row_y + dy
        inside = (zz >= 0) & (zz < nz) & (yy >= 0) & (yy < ny)
        if not inside.any():
            continue
        src = np.nonzero(inside)[0]
        target = zz[src] * ny + yy[src]
        low, high = row_begin[target], row_begin[target + 1]
        # Keys fold the row in, so these two searches stay inside the target
        # row even though they run over the whole array.
        upper = np.searchsorted(
            start_key, target * stride + ends[src] + slack, side="left")
        lower = np.searchsorted(
            end_key, target * stride + starts[src] - slack, side="right")
        begin = np.minimum(np.maximum(lower, low), high)
        finish = np.minimum(np.maximum(upper, low), high)
        counts = np.maximum(finish - begin, 0)
        if not counts.any():
            continue
        total = int(counts.sum())
        ramp = np.arange(total) - np.repeat(np.cumsum(counts) - counts, counts)
        edge_blocks.append(
            np.stack((np.repeat(src, counts), np.repeat(begin, counts) + ramp),
                     axis=1)
        )

    edges = (np.concatenate(edge_blocks) if edge_blocks
             else np.zeros((0, 2), dtype=np.int64))
    parent = _components_of_edges(edges, rows.size)
    _roots, compact = np.unique(parent, return_inverse=True)
    run_label = (compact + 1).astype(np.int32)

    # Runs are painted by their end points and a running sum, so no Python
    # loop touches a voxel.
    marks = np.zeros(nz * ny * nx + 1, dtype=np.int64)
    np.add.at(marks, rows * nx + starts, run_label)
    np.add.at(marks, rows * nx + ends, -run_label.astype(np.int64))
    labels = np.cumsum(marks[:-1]).astype(np.int32).reshape(mask.shape)
    labels[~mask] = 0
    sizes = np.bincount(labels.reshape(-1),
                        minlength=int(run_label.max()) + 1).astype(np.int64)
    return labels, sizes


def label_regions(
    mask: np.ndarray,
    connectivity: int = 6,
    include_outside: bool = False,
):
    """Label connected components of ``True`` voxels in ``mask``.

    Args:
        mask: 3D boolean array. ``True`` voxels are labelled.
        connectivity: 6, 18 or 26 neighbour connectivity.
        include_outside: When ``True``, a virtual traversable shell is wrapped
            around the volume and flooded first, so **label 1 is always the
            region connected to the world outside the scan** and labels >= 2 are
            fully enclosed. This is what separates surrounding air from an
            internal cavity.

    Returns:
        ``(labels, sizes)``. ``labels`` has ``mask``'s shape; 0 means "not in
        mask". ``sizes[k]`` is the number of in-volume voxels carrying label
        ``k``. ``sizes[0]`` counts non-mask voxels and is not meaningful. The
        virtual outside shell is never counted in ``sizes``.
    """
    mask = np.ascontiguousarray(mask, dtype=bool)
    if mask.ndim != 3:
        raise ValueError("mask must be a 3D array")

    if not include_outside:
        # The run-based labeller cannot express the virtual shell that
        # ``include_outside`` floods first, so cavity classification keeps the
        # flood fill. Everything else - the island filter above all - takes the
        # fast path.
        return _label_regions_runs(mask, connectivity)

    padded = _pad_traversable(mask, border_traversable=include_outside)
    flat_traversable = padded.reshape(-1)
    flat_labels = np.zeros(flat_traversable.size, dtype=np.int32)
    offsets = _flat_offsets(padded.shape, connectivity)

    next_label = 1
    if include_outside:
        seed = _border_shell_indices(padded.shape)
        _bfs_fill(flat_traversable, flat_labels, offsets, seed, next_label)
        next_label += 1

    # Walk candidates with a cursor so repeatedly finding the next unlabelled
    # voxel stays O(total) instead of O(voxels x components).
    candidates = np.flatnonzero(flat_traversable).astype(np.int64)
    cursor = 0
    while cursor < candidates.size:
        start = int(candidates[cursor])
        if flat_labels[start] != 0:
            cursor += 1
            continue
        _bfs_fill(flat_traversable, flat_labels, offsets, np.array([start], dtype=np.int64), next_label)
        next_label += 1
        cursor += 1

    labels = flat_labels.reshape(padded.shape)[2:-2, 2:-2, 2:-2].copy()
    sizes = np.bincount(labels.reshape(-1), minlength=next_label).astype(np.int64)
    return labels, sizes


def largest_component(mask: np.ndarray, connectivity: int = 26) -> np.ndarray:
    """Keep only the biggest connected blob - drops isolated speckle."""
    labels, sizes = label_regions(mask, connectivity=connectivity, include_outside=False)
    if sizes.size <= 1:
        return np.zeros(mask.shape, dtype=bool)
    sizes = sizes.copy()
    sizes[0] = 0
    winner = int(np.argmax(sizes))
    if sizes[winner] <= 0:
        return np.zeros(mask.shape, dtype=bool)
    return labels == winner


def remove_small_components(mask: np.ndarray, min_voxels: int, connectivity: int = 26) -> np.ndarray:
    """Drop connected blobs smaller than ``min_voxels``."""
    if int(min_voxels) <= 1:
        return np.asarray(mask, dtype=bool)
    labels, sizes = label_regions(mask, connectivity=connectivity, include_outside=False)
    keep = sizes >= int(min_voxels)
    keep[0] = False
    return keep[labels]


# --------------------------------------------------------------------------
# Morphology
# --------------------------------------------------------------------------


def _dilate_axis(mask: np.ndarray, axis: int, fill: bool) -> np.ndarray:
    delta_pos = [0, 0, 0]
    delta_neg = [0, 0, 0]
    delta_pos[axis] = 1
    delta_neg[axis] = -1
    return mask | shift(mask, tuple(delta_pos), fill) | shift(mask, tuple(delta_neg), fill)


def binary_dilate(mask: np.ndarray, radius: int = 1, connectivity: int = 26, fill: bool = False) -> np.ndarray:
    """Grow ``mask`` by ``radius`` steps.

    ``connectivity=26`` is a cube structuring element applied separably (6
    shifts per step instead of 26); ``connectivity=6`` uses a cross.
    """
    out = np.asarray(mask, dtype=bool)
    radius = int(radius)
    if radius <= 0:
        return out.copy()

    for _ in range(radius):
        if connectivity == 26:
            grown = out
            for axis in (0, 1, 2):
                grown = _dilate_axis(grown, axis, fill)
            out = grown
        else:
            grown = out.copy()
            for view in _iter_neighbor_views(out, connectivity, fill):
                grown |= view
            out = grown
    return out


def ball_offsets(radius: int) -> np.ndarray:
    """Voxel offsets inside a Euclidean ball of ``radius``."""
    r = max(0, int(radius))
    if r == 0:
        return np.zeros((1, 3), dtype=np.int64)
    span = np.arange(-r, r + 1)
    zz, yy, xx = np.meshgrid(span, span, span, indexing="ij")
    inside = (zz ** 2 + yy ** 2 + xx ** 2) <= r * r + 1e-9
    return np.stack((zz[inside], yy[inside], xx[inside]), axis=1).astype(np.int64)


def ball_dilate(mask: np.ndarray, radius: int) -> np.ndarray:
    """Grow ``mask`` by a ball, not a box.

    ``binary_dilate`` applies a *cube* - separable and fast, but at radius 2 it
    reaches 3.46 voxels along a diagonal against 2 along an axis, 73% further
    one way than the other. Closing with it leaves axis-aligned steps, square
    notches and cube-shaped lumps that are not in the data: the structuring
    element's own shape, printed onto the surface.

    A ball reaches the same distance in every direction, so what it fills has no
    orientation of its own. It costs one shifted OR per offset - 33 at radius 2,
    123 at radius 3 - which is affordable here because this runs on the source
    grid, not the reconstruction grid.
    """
    source = np.asarray(mask, dtype=bool)
    r = max(0, int(radius))
    if r == 0:
        return source.copy()

    out = source.copy()
    for dz, dy, dx in ball_offsets(r):
        if dz == 0 and dy == 0 and dx == 0:
            continue
        src = [slice(None)] * 3
        dst = [slice(None)] * 3
        for axis, delta in enumerate((int(dz), int(dy), int(dx))):
            n = source.shape[axis]
            if delta > 0:
                src[axis] = slice(0, n - delta)
                dst[axis] = slice(delta, n)
            elif delta < 0:
                src[axis] = slice(-delta, n)
                dst[axis] = slice(0, n + delta)
        out[tuple(dst)] |= source[tuple(src)]
    return out


def ball_erode(mask: np.ndarray, radius: int, border_solid: bool = True) -> np.ndarray:
    """Shrink ``mask`` by a ball. ``border_solid`` treats outside as solid."""
    r = max(0, int(radius))
    if r == 0:
        return np.asarray(mask, dtype=bool).copy()
    complement = ~np.asarray(mask, dtype=bool)
    if border_solid:
        return ~ball_dilate(complement, r)
    padded = np.pad(complement, r, mode="constant", constant_values=True)
    grown = ball_dilate(padded, r)
    return ~grown[r:-r, r:-r, r:-r]


def ball_close(mask: np.ndarray, radius: int) -> np.ndarray:
    """Fill holes narrower than ``2 * radius`` without a box's orientation."""
    r = max(0, int(radius))
    if r == 0:
        return np.asarray(mask, dtype=bool).copy()
    return ball_erode(ball_dilate(mask, r), r, border_solid=True)


def binary_erode(mask: np.ndarray, radius: int = 1, connectivity: int = 26, border_solid: bool = True) -> np.ndarray:
    """Shrink ``mask`` by ``radius`` steps.

    ``border_solid=True`` treats everything outside the array as solid, so
    voxels sitting on the array edge are not eaten away.
    """
    radius = int(radius)
    if radius <= 0:
        return np.asarray(mask, dtype=bool).copy()
    complement = ~np.asarray(mask, dtype=bool)
    grown = binary_dilate(complement, radius=radius, connectivity=connectivity, fill=not border_solid)
    return ~grown


def binary_close(mask: np.ndarray, radius: int = 1, connectivity: int = 26) -> np.ndarray:
    """Dilate then erode - bridges sampling gaps without moving real surfaces.

    The array is padded by ``radius + 1`` first so material dilated past the
    edge is still present for the erosion to pull back.
    """
    radius = int(radius)
    mask = np.asarray(mask, dtype=bool)
    if radius <= 0:
        return mask.copy()

    pad = radius + 1
    padded = np.zeros(
        (mask.shape[0] + 2 * pad, mask.shape[1] + 2 * pad, mask.shape[2] + 2 * pad),
        dtype=bool,
    )
    padded[pad:-pad, pad:-pad, pad:-pad] = mask
    grown = binary_dilate(padded, radius=radius, connectivity=connectivity, fill=False)
    shrunk = binary_erode(grown, radius=radius, connectivity=connectivity, border_solid=False)
    return shrunk[pad:-pad, pad:-pad, pad:-pad].copy()


# --------------------------------------------------------------------------
# The "outside only" tests
# --------------------------------------------------------------------------


def boundary_mask(solid: np.ndarray, connectivity: int = 6) -> np.ndarray:
    """Solid voxels that are *not* surrounded on all sides.

    A voxel is interior only when every neighbour under ``connectivity`` is also
    solid. Voxels on the array edge count as exposed, because the space beyond
    the scanned region is not solid.
    """
    solid = np.asarray(solid, dtype=bool)
    exposed = np.zeros(solid.shape, dtype=bool)
    for view in _iter_neighbor_views(solid, connectivity, fill=False):
        exposed |= ~view
    return solid & exposed


def _shift_numeric(array: np.ndarray, axis: int, delta: int) -> np.ndarray:
    """Shift along one axis, replicating the edge value.

    Edge replication is the right boundary rule for grey morphology: it makes
    the border behave as if the volume continued unchanged, so a valley filter
    does not invent a valley at the array edge.
    """
    if delta == 0:
        return array
    out = np.empty_like(array)
    src, dst = _axis_slices(delta)
    slicer_dst = [slice(None)] * 3
    slicer_src = [slice(None)] * 3
    slicer_dst[axis] = dst
    slicer_src[axis] = src
    out[tuple(slicer_dst)] = array[tuple(slicer_src)]

    # Fill the vacated edge by repeating the nearest remaining plane.
    edge_dst = [slice(None)] * 3
    edge_src = [slice(None)] * 3
    if delta > 0:
        edge_dst[axis] = slice(-delta, None)
        edge_src[axis] = slice(-delta - 1, -delta)
    else:
        edge_dst[axis] = slice(0, -delta)
        edge_src[axis] = slice(-delta, -delta + 1)
    out[tuple(edge_dst)] = array[tuple(edge_src)]
    return out


def grey_dilate_box(volume: np.ndarray, radius: int = 1) -> np.ndarray:
    """Local maximum over a cube of the given radius (separable)."""
    out = np.asarray(volume)
    for _ in range(max(0, int(radius))):
        for axis in (0, 1, 2):
            out = np.maximum(
                out,
                np.maximum(_shift_numeric(out, axis, 1), _shift_numeric(out, axis, -1)),
            )
    return out


def grey_erode_box(volume: np.ndarray, radius: int = 1) -> np.ndarray:
    """Local minimum over a cube of the given radius (separable)."""
    out = np.asarray(volume)
    for _ in range(max(0, int(radius))):
        for axis in (0, 1, 2):
            out = np.minimum(
                out,
                np.minimum(_shift_numeric(out, axis, 1), _shift_numeric(out, axis, -1)),
            )
    return out


def valley_strength(volume: np.ndarray, radius: int = 2) -> np.ndarray:
    """How much darker each voxel is than the material enclosing it.

    This is a morphological black top-hat: grey-closing minus the original.
    Closing fills any dark structure thinner than ``2 * radius``, so the
    difference peaks exactly inside thin dark features and is ~0 in uniform
    material - which makes it a direct detector for the dark seams between
    touching bones, independent of absolute intensity.

    Using absolute HU instead would not work: a joint seam between two dense
    cortical surfaces and the marrow inside a bone can sit at similar values,
    so only the *local* contrast distinguishes them.

    Returns a float32 array in the same units as ``volume``.
    """
    vol = np.asarray(volume, dtype=np.float32)
    radius = max(1, int(radius))
    closed = grey_erode_box(grey_dilate_box(vol, radius), radius)
    return (closed - vol).astype(np.float32)


def propagate_labels(
    labels: np.ndarray,
    allowed: np.ndarray,
    connectivity: int = 6,
    max_steps: int | None = None,
) -> np.ndarray:
    """Grow existing labels outward, breadth-first, to fill ``allowed``.

    Every unlabelled voxel of ``allowed`` takes the label of whichever labelled
    region reaches it first, so each ends up with its nearest label in graph
    distance. Used to hand the seam voxels back to a bone after the seams have
    done their job of separating them - the seams decide *where* the cut runs,
    they are not themselves discarded.

    ``max_steps`` stops the growth after that many waves, which is a distance
    limit in voxels. Without one the fill does not merely return a seam: it
    keeps going until every reachable voxel has been claimed, so a region of
    ``allowed`` that holds no label of its own is handed wholesale to whichever
    label is nearest, however far away that is. When the labels are seeds
    rather than near-complete regions, that turns most of the output into a
    nearest-seed guess. Voxels beyond the limit are left unlabelled.

    Total work is O(voxels in ``allowed``): each voxel is claimed once.
    """
    labels = np.ascontiguousarray(labels, dtype=np.int32)
    allowed = np.ascontiguousarray(allowed, dtype=bool)
    if labels.shape != allowed.shape:
        raise ValueError("labels and allowed must have the same shape")

    # Pad so neighbour lookups by flat offset cannot wrap across a row.
    padded_allowed = _pad_traversable(allowed, border_traversable=False)
    padded_labels = np.zeros(padded_allowed.shape, dtype=np.int32)
    padded_labels[2:-2, 2:-2, 2:-2] = labels

    flat_allowed = padded_allowed.reshape(-1)
    flat_labels = padded_labels.reshape(-1)
    offsets = _flat_offsets(padded_allowed.shape, connectivity)

    frontier = np.flatnonzero((flat_labels > 0) & flat_allowed).astype(np.int64)
    block_size = max(1, _MAX_FRONTIER_ELEMENTS // max(1, int(offsets.size)))

    limit = None if max_steps is None else max(0, int(max_steps))
    steps = 0
    while frontier.size:
        if limit is not None and steps >= limit:
            break
        steps += 1
        collected = []
        for start in range(0, frontier.size, block_size):
            block = frontier[start : start + block_size]
            neighbors = (block[:, None] + offsets[None, :]).reshape(-1)
            source = np.repeat(flat_labels[block], offsets.size)
            keep = flat_allowed[neighbors] & (flat_labels[neighbors] == 0)
            if not np.any(keep):
                continue
            neighbors = neighbors[keep]
            source = source[keep]
            # Several fronts can reach the same voxel in one wave; first wins.
            unique_neighbors, first = np.unique(neighbors, return_index=True)
            flat_labels[unique_neighbors] = source[first]
            collected.append(unique_neighbors)

        if not collected:
            break
        frontier = collected[0] if len(collected) == 1 else np.concatenate(collected)

    return flat_labels.reshape(padded_allowed.shape)[2:-2, 2:-2, 2:-2].copy()


def gradient_magnitude(field: np.ndarray, spacing=(1.0, 1.0, 1.0)) -> np.ndarray:
    """Central-difference gradient magnitude, scaled by physical spacing.

    This is the general-purpose boundary detector, and the counterpart to
    :func:`valley_strength`. A valley filter only fires where material gets
    *darker* - correct for the seam between two touching bones, useless between
    two soft tissues, where the boundary may be a step up (muscle against fat),
    a step down (brain against CSF), or a thin bright line (fascia). Gradient
    magnitude responds to a change in either direction, so it works across
    tissue classes and imaging modalities.

    Spacing matters: on an anisotropic scan an unscaled difference exaggerates
    the axis with the widest voxels and the boundaries drift toward it.
    """
    values = np.asarray(field, dtype=np.float32)
    if values.ndim != 3:
        raise ValueError("field must be 3D")

    sx, sy, sz = (max(1e-9, float(v)) for v in spacing)
    # Axis order is [z, y, x], so the per-axis divisors are (sz, sy, sx).
    total = np.zeros(values.shape, dtype=np.float32)
    for axis, step in ((0, sz), (1, sy), (2, sx)):
        forward = _shift_numeric(values, axis, 1)
        backward = _shift_numeric(values, axis, -1)
        derivative = (forward - backward) / (2.0 * step)
        total += derivative * derivative
    return np.sqrt(total, out=total)


def erosion_depth(mask: np.ndarray, connectivity: int = 6, max_depth: int = 128) -> np.ndarray:
    """How many erosions each voxel survives - a distance to the surface.

    A cheap stand-in for a Euclidean distance transform: peel the mask one layer
    at a time and record the last layer each voxel was still present in. Surface
    voxels get 1, deep interior voxels get large values.

    Used to make thin material expensive to flood through. Without that, a
    watershed treats the outer skin of an object as cheap territory - the valley
    filter reads near zero along a convex outer surface - and a single region can
    race along it around the entire object, producing one component shaped like a
    shell wrapped around everything instead of a bone.

    Returns int32 depths, 0 outside the mask.
    """
    current = np.ascontiguousarray(mask, dtype=bool)
    depth = np.zeros(current.shape, dtype=np.int32)
    for level in range(1, int(max_depth) + 1):
        if not current.any():
            break
        depth[current] = level
        current = binary_erode(current, radius=1, connectivity=connectivity, border_solid=False)
    return depth


def watershed_by_cost(
    mask: np.ndarray,
    cost: np.ndarray,
    markers: np.ndarray,
    bands: int = 24,
    connectivity: int = 6,
) -> np.ndarray:
    """Marker-based watershed: flood ``mask`` cheapest-first from ``markers``.

    Regions expand through low-cost territory before high-cost, so two regions
    meet on the highest-cost ridge between them. With ``cost`` set to
    :func:`valley_strength`, that ridge is the dark seam between two touching
    bones - the split lands on the anatomy rather than on an intensity cutoff.

    Every voxel of ``mask`` reachable from a marker is labelled, so nothing is
    discarded: the seam decides where the boundary runs and then the voxels on
    either side are kept.

    Implemented as a banded flood rather than a per-voxel priority queue: the
    cost range is quantised into ``bands`` levels and each level is filled with
    a vectorised breadth-first wave. That keeps it to numpy array operations,
    where a heap over half a million voxels would be a Python-level loop.
    More bands means a more faithful ordering; 24 is ample for this purpose.

    Returns an int32 label volume (0 where unlabelled).
    """
    mask = np.ascontiguousarray(mask, dtype=bool)
    cost = np.asarray(cost, dtype=np.float32)
    labels = np.array(markers, dtype=np.int32, copy=True)
    if mask.shape != cost.shape or mask.shape != labels.shape:
        raise ValueError("mask, cost and markers must have the same shape")

    labels[~mask] = 0
    inside = cost[mask]
    if inside.size == 0:
        return labels

    bands = max(1, int(bands))
    # Quantise on percentiles so the levels track the actual distribution
    # rather than being dominated by a few extreme voxels.
    levels = np.percentile(inside, np.linspace(0.0, 100.0, bands + 1)[1:])
    levels = np.unique(levels.astype(np.float32))

    for level in levels:
        allowed = mask & (cost <= level)
        labels = propagate_labels(labels, allowed, connectivity=connectivity)

    # Anything the bands missed (ties at the very top of the range).
    return propagate_labels(labels, mask, connectivity=connectivity)


def isolated_fraction(mask: np.ndarray, connectivity: int = 6) -> float:
    """Fraction of occupied voxels that have no occupied neighbour.

    This is the sparsity alarm for the interior/exterior test. That test asks
    "is this voxel surrounded on all sides", which only means anything if the
    cloud actually samples its material densely. A randomly decimated cloud -
    what an import point cap produces - leaves most voxels standing alone, and
    then every voxel looks like surface. Near 0 is a solidly sampled cloud.
    """
    mask = np.asarray(mask, dtype=bool)
    occupied = int(np.count_nonzero(mask))
    if occupied == 0:
        return 0.0
    has_neighbor = np.zeros(mask.shape, dtype=bool)
    for view in _iter_neighbor_views(mask, connectivity, fill=False):
        has_neighbor |= view
    return float(np.count_nonzero(mask & ~has_neighbor)) / float(occupied)


def count_components(mask: np.ndarray, connectivity: int = 26) -> int:
    """Number of connected blobs of ``True`` voxels."""
    _labels, sizes = label_regions(mask, connectivity=connectivity, include_outside=False)
    return max(0, int(sizes.size) - 1)


def shell_mask(solid: np.ndarray, thickness: int = 1, connectivity: int = 6) -> np.ndarray:
    """A band ``thickness`` voxels deep on every exposed face of ``solid``.

    ``thickness=1`` is exactly ``boundary_mask``. Larger values keep more of the
    near-surface density, which helps when the source lattice is coarse or when
    a closing pass has pushed the surface outward.
    """
    solid = np.asarray(solid, dtype=bool)
    thickness = max(1, int(thickness))
    if thickness == 1:
        return boundary_mask(solid, connectivity=connectivity)
    core = binary_erode(solid, radius=thickness, connectivity=connectivity, border_solid=False)
    return solid & ~core


@dataclass
class CavityClassification:
    """Result of splitting the empty space around a solid into air vs cavities."""

    solid: np.ndarray
    """Input solid with sub-threshold noise pockets filled in."""

    cavity: np.ndarray
    """Enclosed empty regions kept as real voids (e.g. missing marrow)."""

    outside: np.ndarray
    """Empty space connected to the world outside the scanned region."""

    cavity_sizes: list
    """Voxel count of each kept cavity, largest first."""

    filled_voxels: int
    """How many noise-pocket voxels were absorbed into the solid."""

    discarded_cavities: int
    """How many enclosed voids were rejected as noise or as shell interiors."""


def classify_cavities(
    solid: np.ndarray,
    min_cavity_voxels: int = 8,
    connectivity: int = 6,
    max_cavity_fraction: float = 0.9,
) -> CavityClassification:
    """Separate surrounding air, real internal cavities, and sampling noise.

    Empty space is labelled with the outside flooded first, so every label >= 2
    is a fully enclosed void. Enclosed voids are then triaged:

    * smaller than ``min_cavity_voxels`` -> sampling noise, filled into the
      solid so it cannot become a spurious internal surface;
    * larger than ``max_cavity_fraction`` of the solid volume -> the input was
      already a hollow shell rather than a filled body, so this void is its
      interior and gets filled;
    * everything in between -> a genuine cavity, kept so it shows up in the
      final mesh as a distinct hollowed-out area.

    Args:
        solid: 3D boolean occupancy.
        min_cavity_voxels: Smallest void kept as a real cavity.
        connectivity: Connectivity used to flood the empty space. 6 is the
            strict reading - a void leaks out only through a shared face.
        max_cavity_fraction: Guard against treating a shell's interior as a
            cavity. Set to 0 to disable.
    """
    solid = np.ascontiguousarray(solid, dtype=bool)
    empty = ~solid
    labels, sizes = label_regions(empty, connectivity=connectivity, include_outside=True)

    outside = labels == 1
    enclosed = labels >= 2

    solid_voxels = int(np.count_nonzero(solid))
    keep = np.zeros(sizes.size, dtype=bool)
    if sizes.size > 2:
        keep[2:] = sizes[2:] >= max(1, int(min_cavity_voxels))
        if max_cavity_fraction > 0.0 and solid_voxels > 0:
            ceiling = float(max_cavity_fraction) * float(solid_voxels)
            keep[2:] &= sizes[2:] <= ceiling

    cavity = keep[labels] & enclosed
    absorbed = enclosed & ~cavity
    filled = solid | absorbed

    kept_sizes = sorted((int(sizes[i]) for i in np.flatnonzero(keep)), reverse=True)
    total_enclosed = max(0, int(sizes.size) - 2)
    return CavityClassification(
        solid=filled,
        cavity=cavity,
        outside=outside,
        cavity_sizes=kept_sizes,
        filled_voxels=int(np.count_nonzero(absorbed)),
        discarded_cavities=total_enclosed - len(kept_sizes),
    )


# --------------------------------------------------------------------------
# Points <-> grid
# --------------------------------------------------------------------------


def _density_spacing(points: np.ndarray, extent: np.ndarray) -> float:
    """Crude spacing from point density, ignoring degenerate axes.

    A flat sheet has one extent of zero, so a plain cube-root of the bounding
    box volume collapses to nearly nothing. Only axes with real thickness are
    counted.
    """
    real = np.asarray(extent, dtype=np.float64)
    real = real[real > np.max(real) * 1e-6] if np.max(real) > 0 else real
    if real.size == 0:
        return 1.0
    volume = float(np.prod(real))
    return max(1e-9, float(volume / max(1.0, float(points.shape[0]))) ** (1.0 / real.size))


def _probe_nn(pts, lower, extent, cell, probes, seed):
    """One nearest-neighbour pass at a given bucket size.

    Returns the finite neighbour distances found and how many probes were run.
    A probe whose 27-cell block holds no other point yields nothing, which is
    the caller's signal that the bucket is finer than the real point spacing.
    """
    dims = np.maximum(1, np.floor(extent / cell).astype(np.int64) + 1)
    if float(np.prod(dims.astype(np.float64))) > 20_000_000.0:
        return None, 0

    cid = np.clip(np.floor((pts - lower) / cell).astype(np.int64), 0, dims - 1)
    flat = (cid[:, 0] * dims[1] + cid[:, 1]) * dims[2] + cid[:, 2]
    order = np.argsort(flat, kind="stable")
    sorted_flat = flat[order]
    sorted_pts = pts[order]

    rng = np.random.default_rng(seed)
    probe_count = int(min(max(64, probes), pts.shape[0]))
    probe_idx = rng.choice(pts.shape[0], size=probe_count, replace=False)
    probe_pts = pts[probe_idx]
    probe_cells = cid[probe_idx]

    deltas = np.array(
        [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)],
        dtype=np.int64,
    )

    found = []
    for k in range(probe_count):
        neighbors = probe_cells[k][None, :] + deltas
        valid = np.all((neighbors >= 0) & (neighbors < dims[None, :]), axis=1)
        if not np.any(valid):
            continue
        neighbors = neighbors[valid]
        keys = (neighbors[:, 0] * dims[1] + neighbors[:, 1]) * dims[2] + neighbors[:, 2]
        starts = np.searchsorted(sorted_flat, keys, side="left")
        stops = np.searchsorted(sorted_flat, keys, side="right")
        closest = np.inf
        for start, stop in zip(starts, stops):
            if stop <= start:
                continue
            diff = sorted_pts[start:stop] - probe_pts[k]
            dist = np.sqrt(np.einsum("ij,ij->i", diff, diff))
            dist = dist[dist > 1e-9]
            if dist.size:
                local = float(dist.min())
                if local < closest:
                    closest = local
        if np.isfinite(closest):
            found.append(closest)
    return np.asarray(found, dtype=np.float64), probe_count


def nearest_neighbor_spacing(
    points: np.ndarray,
    probes: int = 1024,
    seed: int = 42,
) -> float:
    """Median distance from a point to its closest neighbour.

    This is the spacing estimate of last resort, and the only one that is
    trustworthy for a cloud that is *not* on an axis-aligned lattice - one that
    has had a transform baked in, or been densified by inserting points at
    arbitrary positions along segments. It is rotation invariant and depends on
    nothing but local geometry.

    It replaces an earlier occupancy-shrinking heuristic that proved badly
    unstable: on two real clouds differing by 905 points out of 1.1 million it
    returned 18.6 mm and 1.04 mm. A spacing that wrong collapses a 340 mm
    skeleton onto a 27x24x28 grid, and the reconstruction comes out as a smooth
    blob with no warning.

    Points are binned into a uniform bucket grid once, then each probe compares
    against its own bucket and the 26 around it. If the buckets turn out finer
    than the actual point spacing, most probes find nothing - so the bucket size
    grows and the pass repeats. Deterministic for a given ``seed``.
    """
    pts = np.asarray(points, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] < 2:
        return 1.0

    lower = pts.min(axis=0)
    extent = np.maximum(pts.max(axis=0) - lower, 1e-9)
    cell = max(float(np.max(extent)) / 64.0, float(np.max(extent)) / 4096.0)

    for _ in range(10):
        found, probe_count = _probe_nn(pts, lower, extent, cell, probes, seed)
        if found is None:
            cell *= 1.7
            continue
        # Enough probes found a neighbour for the median to mean something.
        if probe_count and found.size >= max(8, probe_count // 2):
            return max(1e-9, float(np.median(found)))
        cell *= 2.0

    if found is not None and found.size:
        return max(1e-9, float(np.median(found)))
    return _density_spacing(pts, extent)


def _cluster_sorted(values: np.ndarray, tolerance: float) -> np.ndarray:
    """Collapse runs of values separated by less than ``tolerance`` to their mean."""
    values = np.sort(np.asarray(values, dtype=np.float64))
    if values.size <= 1 or tolerance <= 0.0:
        return values
    breaks = np.flatnonzero(np.diff(values) > tolerance)
    starts = np.concatenate(([0], breaks + 1))
    counts = np.diff(np.concatenate((starts, [values.size])))
    sums = np.add.reduceat(values, starts)
    return sums / counts


MIN_LATTICE_ROWS = 4
"""Fewest rows an axis must resolve before its step is believable.

Kept low on purpose. A small object scanned with thick slices genuinely has few
rows along the slice axis - a 20 mm sphere on 3 mm slices has seven - so a high
threshold here silently discards real anisotropy, which is exactly the
information the reconstruction needs most. The load-bearing check against
nonsense candidates is the nearest-neighbour bound in
:func:`estimate_lattice_spacing`, not this count.
"""


def _lattice_step_for_axis(values: np.ndarray, axis_extent: float, tolerance: float):
    """Candidate lattice step from one axis's coordinate values, or None.

    Clusters near-identical values into lattice rows, reads the step off the
    row-to-row differences, then *verifies* it: on a real lattice every row sits
    at a near-integer multiple of the step, and there are many rows. Without
    both checks an irregular cloud yields an absurd step and a grid far too
    coarse to resolve anything.
    """
    rows = _cluster_sorted(values, tolerance)
    if rows.size < MIN_LATTICE_ROWS:
        return None

    diffs = np.diff(rows)
    diffs = diffs[diffs > axis_extent / 1e5]
    if diffs.size == 0:
        return None

    # A lattice produces a strongly peaked diff distribution; a low percentile
    # recovers the step even when whole rows are missing.
    candidate = float(np.percentile(diffs, 10.0))
    if candidate <= axis_extent / 1e5:
        return None
    # A step at or below the clustering tolerance means the tolerance blurred
    # real rows together; the caller retries finer.
    if tolerance > 0.0 and candidate <= tolerance * 2.0:
        return None

    # A step that spans most of the axis explains nothing about a lattice.
    if candidate > axis_extent / 3.0:
        return None

    ratio = (rows - rows[0]) / candidate
    if float(np.median(np.abs(ratio - np.round(ratio)))) > 0.1:
        return None
    return candidate


def estimate_lattice_spacing(points: np.ndarray, sample_limit: int = 400_000, with_source: bool = False):
    """Recover the per-axis sample spacing of a point cloud.

    DICOM-derived clouds sit on a regular lattice, so the row-to-row difference
    between distinct coordinate values along an axis is the real spacing, and
    detecting it per axis preserves the anisotropy that matters for
    reconstruction. Three clustering tolerances are tried per axis - exact
    first, then progressively looser - so a cloud carrying float rounding or
    small jitter is still recognised.

    Not every cloud is on a lattice, though. Bake a transform into the point
    data, or densify it by inserting points partway along segments, and the
    coordinates become effectively continuous. Those clouds are handed to
    :func:`nearest_neighbor_spacing`, which measures local geometry directly and
    does not care about axis alignment. The nearest-neighbour distance also sets
    the clustering tolerances, so they can never grow large enough to merge
    genuine lattice rows into one.

    Args:
        with_source: When True, return ``(spacing, source)`` where ``source`` is
            ``"lattice"``, ``"mixed"`` or ``"nearest-neighbour"``. Callers use it
            to tell the user how the spacing was arrived at, because a wrong
            spacing is the single most destructive input to reconstruction.
    """
    pts = np.asarray(points, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] == 0:
        return ((1.0, 1.0, 1.0), "default") if with_source else (1.0, 1.0, 1.0)

    if pts.shape[0] > int(sample_limit):
        rng = np.random.default_rng(42)
        pts = pts[rng.choice(pts.shape[0], size=int(sample_limit), replace=False)]

    extent = np.maximum(pts.max(axis=0) - pts.min(axis=0), 1e-9)

    # Pass one uses exact values, which needs no spacing prior at all. A clean
    # DICOM lattice resolves here, so the common case never pays for the
    # nearest-neighbour measurement.
    steps = [
        _lattice_step_for_axis(pts[:, axis], float(extent[axis]), 0.0) or 0.0
        for axis in range(3)
    ]

    if all(s > 0.0 for s in steps):
        spacing = tuple(float(s) for s in steps)
        return (spacing, "lattice") if with_source else spacing

    # Something did not resolve exactly, so measure the real point separation.
    # It both sets the clustering tolerances - which can then never grow large
    # enough to merge genuine lattice rows - and bounds what a per-axis step may
    # plausibly be. The upper bound is loose because real CT is anisotropic and
    # slice spacing 6-10x the in-plane spacing is normal; it still rejects the
    # 300x-too-large candidates a continuous cloud produces.
    neighbor = nearest_neighbor_spacing(pts)
    low, high = neighbor * 0.2, neighbor * 16.0

    for axis in range(3):
        candidate = steps[axis]
        if candidate > 0.0:
            steps[axis] = candidate if low <= candidate <= high else 0.0
            if steps[axis] > 0.0:
                continue
        column = pts[:, axis]
        for tolerance in (neighbor * 0.05, neighbor * 0.25):
            found = _lattice_step_for_axis(column, float(extent[axis]), float(tolerance))
            if found is not None and low <= found <= high:
                steps[axis] = found
                break

    known = [s for s in steps if s > 0.0]
    if len(known) == 3:
        source = "lattice"
    elif known:
        source = "mixed"
    else:
        source = "nearest-neighbour"

    fallback = float(np.median(known)) if known else neighbor
    spacing = tuple(float(s) if s > 0.0 else fallback for s in steps)
    return (spacing, source) if with_source else spacing


def occupancy_from_points(
    points: np.ndarray,
    spacing,
    pad_voxels: int = 3,
    values: np.ndarray | None = None,
    voxel_budget: int = DEFAULT_VOXEL_BUDGET,
    with_evidence: bool = False,
):
    """Snap a point cloud onto a lattice, returning dense occupancy.

    Args:
        points: ``(N, 3)`` world XYZ.
        spacing: Lattice spacing along X, Y, Z.
        pad_voxels: Empty margin added on every side. Needed so the exterior
            flood fill has somewhere to start and so isosurface extraction is
            not clipped at the array edge.
        values: Optional per-point scalar; the maximum per voxel is returned.
        voxel_budget: Hard cap on the allocation.
        with_evidence: Also return how much evidence each voxel holds - the
            point count and the sum of ``values``. Occupancy answers "is there
            anything here"; the evidence answers "how much, and how bright",
            which is what distinguishes solid material from a faint haze.

    Returns:
        ``(occupancy, value_grid, grid)``, or ``(occupancy, value_grid, grid,
        counts, value_sum)`` when ``with_evidence``. ``value_grid`` and
        ``value_sum`` are ``None`` when no ``values`` were supplied.
    """
    pts = np.asarray(points, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3:
        raise ValueError("points must be an (N, 3) array")
    if pts.shape[0] == 0:
        raise ValueError("point cloud is empty")

    sx, sy, sz = (max(1e-9, float(v)) for v in spacing)
    step = np.array([sx, sy, sz], dtype=np.float64)
    pad = max(0, int(pad_voxels))

    # A grid that will not fit is coarsened rather than refused: erroring out
    # mid-conversion is worse than a slightly coarser result the user is told
    # about, and the aspect ratio is kept so anisotropy handling is unaffected.
    #
    # The loop measures the shape the *same way* the code below does, rather
    # than predicting it. An earlier version predicted with floor() while the
    # real index computation used rint(), which is one voxel larger per axis -
    # enough to sail past the budget by a fraction of a percent and then throw
    # on a grid the loop believed it had already shrunk to fit.
    lower = pts.min(axis=0)
    coarsened = 1.0
    idx_xyz = None
    shape = None
    for _ in range(48):
        idx_xyz = np.rint((pts - lower) / step).astype(np.int64)
        idx_xyz -= idx_xyz.min(axis=0)
        extent = idx_xyz.max(axis=0) + 1
        shape = (
            int(extent[2]) + 2 * pad,
            int(extent[1]) + 2 * pad,
            int(extent[0]) + 2 * pad,
        )
        total = shape[0] * shape[1] * shape[2]
        if total <= int(voxel_budget):
            break
        scale = max(1.01, min((float(total) / float(voxel_budget)) ** (1.0 / 3.0), 4.0))
        step = step * scale
        coarsened *= scale

    sx, sy, sz = (float(v) for v in step)
    check_voxel_budget(
        shape,
        voxel_budget,
        what="Occupancy grid",
        hint="Raise the Voxel Budget, or reduce the extent of the selection.",
    )

    iz = idx_xyz[:, 2] + pad
    iy = idx_xyz[:, 1] + pad
    ix = idx_xyz[:, 0] + pad

    occupancy = np.zeros(shape, dtype=bool)
    occupancy[iz, iy, ix] = True

    value_grid = None
    if values is not None:
        vals = np.asarray(values, dtype=np.float32).reshape(-1)
        if vals.shape[0] != pts.shape[0]:
            raise ValueError("values must have one entry per point")
        value_grid = np.zeros(shape, dtype=np.float32)
        np.maximum.at(value_grid, (iz, iy, ix), vals)

    counts = value_sum = None
    if with_evidence:
        # Grouped by voxel via one sort rather than np.bincount, whose int64
        # output would be gigabytes on a budget-sized grid, or np.add.at, which
        # is an order of magnitude slower.
        flat = (iz.astype(np.int64) * shape[1] + iy) * shape[2] + ix
        order = np.argsort(flat, kind="stable")
        sorted_flat = flat[order]
        uniq, start = np.unique(sorted_flat, return_index=True)
        counts = np.zeros(shape, dtype=np.int32)
        counts.reshape(-1)[uniq] = np.diff(np.append(start, sorted_flat.size))
        if value_grid is not None:
            value_sum = np.zeros(shape, dtype=np.float32)
            value_sum.reshape(-1)[uniq] = np.add.reduceat(
                np.asarray(values, dtype=np.float32).reshape(-1)[order], start
            )

    origin = (
        float(lower[0] - pad * sx),
        float(lower[1] - pad * sy),
        float(lower[2] - pad * sz),
    )
    grid = GridSpec(
        origin=origin,
        spacing=(sx, sy, sz),
        shape=shape,
        # Lets callers tell the user their requested spacing was not achievable.
        coarsened=float(coarsened),
    )
    if with_evidence:
        return occupancy, value_grid, grid, counts, value_sum
    return occupancy, value_grid, grid


def accumulate_points(
    points: np.ndarray,
    spacing,
    pad_voxels: int = 3,
    values: np.ndarray | None = None,
    voxel_budget: int = DEFAULT_VOXEL_BUDGET,
):
    """Bin a cloud into a grid, counting how many points land in each voxel.

    ``occupancy_from_points`` answers "is there anything here", which throws
    away the single most informative thing a point cloud carries: how *densely*
    it is populated. A DICOM cloud is thresholded at import, so the boundary
    between two structures loses most of its points and shows up as a region
    that is both darker and markedly sparser than either structure. That
    sparseness is a separation signal in its own right, independent of
    intensity, and a binary mask cannot see it.

    For counts to vary at all the grid must be coarser than the point spacing -
    at the native spacing every occupied voxel holds exactly one point. Callers
    should pass a spacing a few times the cloud's own.

    Returns ``(counts, value_sum, grid)``: point counts per voxel as int32, the
    sum of ``values`` per voxel as float32 (``None`` if no values were given),
    and the grid they live on.
    """
    pts = np.asarray(points, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3:
        raise ValueError("points must be an (N, 3) array")
    if pts.shape[0] == 0:
        raise ValueError("point cloud is empty")

    step = np.array([max(1e-9, float(v)) for v in spacing], dtype=np.float64)
    pad = max(0, int(pad_voxels))
    lower = pts.min(axis=0)

    coarsened = 1.0
    idx_xyz = None
    shape = None
    for _ in range(48):
        idx_xyz = np.floor((pts - lower) / step).astype(np.int64)
        idx_xyz -= idx_xyz.min(axis=0)
        extent = idx_xyz.max(axis=0) + 1
        shape = (
            int(extent[2]) + 2 * pad,
            int(extent[1]) + 2 * pad,
            int(extent[0]) + 2 * pad,
        )
        total = shape[0] * shape[1] * shape[2]
        if total <= int(voxel_budget):
            break
        scale = max(1.01, min((float(total) / float(voxel_budget)) ** (1.0 / 3.0), 4.0))
        step = step * scale
        coarsened *= scale

    check_voxel_budget(
        shape,
        voxel_budget,
        what="Density grid",
        hint="Raise the Voxel Budget, or reduce the extent of the selection.",
    )

    iz = idx_xyz[:, 2] + pad
    iy = idx_xyz[:, 1] + pad
    ix = idx_xyz[:, 0] + pad

    counts = np.zeros(shape, dtype=np.int32)
    np.add.at(counts, (iz, iy, ix), 1)

    value_sum = None
    if values is not None:
        vals = np.asarray(values, dtype=np.float32).reshape(-1)
        if vals.shape[0] != pts.shape[0]:
            raise ValueError("values must have one entry per point")
        value_sum = np.zeros(shape, dtype=np.float32)
        np.add.at(value_sum, (iz, iy, ix), vals)

    sx, sy, sz = (float(v) for v in step)
    origin = (
        float(lower[0] - pad * sx),
        float(lower[1] - pad * sy),
        float(lower[2] - pad * sz),
    )
    grid = GridSpec(origin=origin, spacing=(sx, sy, sz), shape=shape, coarsened=float(coarsened))
    return counts, value_sum, grid


def interior_fill_fraction(occupancy, probe_radius=2):
    """Share of the object's interior that actually holds points.

    "Interior" is what survives closing and then eroding the occupancy, so this
    measures the inside rather than the surface.

    Deliberately blind to *why* the interior is unfilled. Two attempts were made
    to have it ignore genuine cavities - excluding empty regions above a size,
    and excluding ones that survive erosion - and neither can work: in an
    under-sampled cloud the empty interior is a single huge connected region, so
    it reads identically to a marrow cavity under both tests. Telling those
    apart is not this function's job; the caller does it from how the lattice
    spacing was obtained, which is actual evidence rather than a guess about
    shape.
    """
    occupancy = np.asarray(occupancy, dtype=bool)
    if not occupancy.any():
        return 1.0
    radius = max(1, int(probe_radius))
    closed = binary_close(occupancy, radius=radius, connectivity=26)
    interior = binary_erode(closed, radius=radius, connectivity=6, border_solid=False)
    if not interior.any():
        return 1.0
    return float(occupancy[interior].mean())


def solid_occupancy_from_points(
    points: np.ndarray,
    spacing,
    pad_voxels: int = 3,
    values: np.ndarray | None = None,
    voxel_budget: int = DEFAULT_VOXEL_BUDGET,
    close_radius: int = 1,
    with_evidence: bool = False,
    stats: dict | None = None,
):
    """Occupancy whose interior is solid rather than a sponge.

    Binning a cloud at its own spacing is correct when the cloud fills that
    lattice. A cloud that does not - a continuous one, or a subset of a
    lattice such as any segmentation output - leaves cells empty by chance, and
    binning it alone gives a sponge: measured 14.8% full on a uniformly filled
    ball, with an extracted surface 3.5-6.4x the true area.

    Growing the spacing until the interior filled used to be the remedy for the
    first kind. It is gone; the density estimate downstream handles both without
    touching the grid. What remains here is the optional close, which the caller
    sets. Closing does two things at once and only one of them is wanted: it
    fills holes *inside* a structure, and it bridges gaps *between* separate
    structures, both up to twice the radius. No local operator can tell those
    apart - a hole and a gap of the same width are the same thing to it - which
    is why it is off by default and never escalates on its own.

    Returns ``(occupancy, value_grid, grid, fill, close_radius)``, with
    ``counts`` and ``value_sum`` appended when ``with_evidence``.
    """
    step = np.asarray([max(1e-9, float(v)) for v in spacing], dtype=np.float64)

    def build(current_step):
        return occupancy_from_points(
            points,
            current_step,
            pad_voxels=pad_voxels,
            values=values,
            voxel_budget=voxel_budget,
            with_evidence=with_evidence,
        )

    result = build(step)
    if with_evidence:
        occupancy, value_grid, grid, counts, value_sum = result
    else:
        occupancy, value_grid, grid = result
        counts = value_sum = None

    fill = interior_fill_fraction(occupancy)
    # Named apart from the ``close_radius`` parameter on purpose: initialising
    # the result under the same name clobbered the incoming value, so the close
    # never ran and every cloud came back unsolidified.
    applied_radius = 0

    # Coarsening the grid until the interior filled used to live here, for
    # clouds with no lattice. It is gone: the density estimate in
    # :func:`surface.density_field` sizes its own kernel from this same fill
    # fraction and solidifies the interior without touching the grid. On a
    # continuous ball the two came out equally accurate in radius - 21.93
    # against 22.03, true 22.0 - but coarsening got there by doubling the
    # voxel, which cost three quarters of the vertices and every feature
    # finer than the new spacing.

    radius = max(0, int(close_radius))
    if radius > 0:
        # Count the pieces either side of it. Welding separate structures
        # together is the unwanted half of what closing does, and it is
        # invisible unless it is counted.
        before = count_components(occupancy, 26) if stats is not None else 0
        occupancy = ball_close(occupancy, radius)
        fill = interior_fill_fraction(occupancy)
        if stats is not None:
            stats["components_before_close"] = int(before)
            stats["components_after_close"] = int(count_components(occupancy, 26))
    applied_radius = radius

    if with_evidence:
        return (occupancy, value_grid, grid, float(fill), int(applied_radius),
                counts, value_sum)
    return occupancy, value_grid, grid, float(fill), int(applied_radius)


@dataclass
class DetailSplit:
    """An occupancy grid split into structural material and faint detail."""

    solid: np.ndarray
    """Gated occupancy: structural voxels, plus detail voxels that earned it."""

    structural: np.ndarray
    """Occupied voxels at or above the brightness cut - full geometry window."""

    detail_region: np.ndarray
    """Occupied voxels below the brightness cut, before gating."""

    kept_detail: np.ndarray
    """The subset of ``detail_region`` that cleared the density bar."""

    brightness_cut: float
    """Absolute mean intensity the threshold resolved to, for reporting."""

    density_reference: float
    """Point count a well-filled voxel holds; the density bar is relative to it."""

    density_floor: float
    """Point count a detail voxel had to reach."""

    discriminating: bool
    """False when the grid cannot tell dense from sparse (reference <= 1 point).
    Only the brightness split is applied then, and the caller should say so - a
    gate that silently does nothing is worse than one that reports it."""


def world_to_voxel_index(points: np.ndarray, grid: GridSpec) -> np.ndarray:
    """Nearest voxel ``[z, y, x]`` for each world point, clamped into the grid."""
    pts = np.asarray(points, dtype=np.float64)
    ox, oy, oz = grid.origin
    sx, sy, sz = grid.spacing
    nz, ny, nx = grid.shape

    ix = np.clip(np.rint((pts[:, 0] - ox) / max(1e-9, sx)).astype(np.int64), 0, nx - 1)
    iy = np.clip(np.rint((pts[:, 1] - oy) / max(1e-9, sy)).astype(np.int64), 0, ny - 1)
    iz = np.clip(np.rint((pts[:, 2] - oz) / max(1e-9, sz)).astype(np.int64), 0, nz - 1)
    return np.stack((iz, iy, ix), axis=1)


def sample_trilinear(field: np.ndarray, points: np.ndarray, grid: GridSpec) -> np.ndarray:
    """Trilinearly sample ``field`` at world positions ``points``."""
    pts = np.asarray(points, dtype=np.float64)
    ox, oy, oz = grid.origin
    sx, sy, sz = grid.spacing
    nz, ny, nx = field.shape

    gx = np.clip((pts[:, 0] - ox) / max(1e-9, sx), 0.0, nx - 1.0)
    gy = np.clip((pts[:, 1] - oy) / max(1e-9, sy), 0.0, ny - 1.0)
    gz = np.clip((pts[:, 2] - oz) / max(1e-9, sz), 0.0, nz - 1.0)

    x0 = np.floor(gx).astype(np.int64)
    y0 = np.floor(gy).astype(np.int64)
    z0 = np.floor(gz).astype(np.int64)
    x1 = np.minimum(x0 + 1, nx - 1)
    y1 = np.minimum(y0 + 1, ny - 1)
    z1 = np.minimum(z0 + 1, nz - 1)

    tx = (gx - x0).astype(np.float32)
    ty = (gy - y0).astype(np.float32)
    tz = (gz - z0).astype(np.float32)

    out = np.zeros(pts.shape[0], dtype=np.float32)
    for zi, wz in ((z0, 1.0 - tz), (z1, tz)):
        for yi, wy in ((y0, 1.0 - ty), (y1, ty)):
            for xi, wx in ((x0, 1.0 - tx), (x1, tx)):
                out += field[zi, yi, xi].astype(np.float32) * (wz * wy * wx)
    return out
