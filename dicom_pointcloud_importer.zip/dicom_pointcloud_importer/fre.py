"""GE "genesis" .fre images, as the Visible Human Project ships them.

These are the originals the VHP CT data was distributed as, before anyone
converted them to DICOM. Reading them directly matters because the conversion
is where the geometry gets lost, and this dataset loses it in three separate
ways at once.

**The field of view changes partway down the scan.** On the Visible Human
female, series 370 is reconstructed at four different fields of view - 250 mm
over the head, then 370, then 440, then 480 mm over the body - so the number
of millimetres a pixel covers is not a property of the study, it is a property
of the slice. A converter that picks one pixel size and applies it throughout
stretches the head by 48% and squashes the body by 23%.

**There is more than one series in the folder.** The same directory holds
series 370 (985 slices, -38 to -1022 mm) and series 371 (749 slices, -82 to
-830 mm), covering overlapping anatomy. Stacked together they are 749 pairs of
slices sitting at the same place.

**File order is not slice order.** The names run in one sequence across both
series, so sorting by name walks down series 370 and then jumps 940 mm back up
to start series 371.

So the position, the pixel size and the series all have to be read per slice,
out of the header, and the slices then resampled onto one grid. That is what
this module does.

The format itself is simple: a big-endian header of ``HEADER_BYTES``, then
width x height big-endian 16 bit samples, offset from Hounsfield units by
``HU_OFFSET``.
"""

from __future__ import annotations

import re
import struct
from pathlib import Path

import numpy as np

MAGIC = b"IMGF"
HEADER_BYTES = 3416
HU_OFFSET = 1024.0
"""GE stores Hounsfield units shifted so that air is zero rather than -1000."""

# Offsets found by reading the headers rather than from a specification: the
# slice location is the float that matches the position quoted in the text
# annotation, and the pixel size is the one that agrees with the field of view
# recorded beside it.
OFF_HEADER_LENGTH = 4
OFF_WIDTH = 8
OFF_HEIGHT = 12
OFF_DEPTH = 16
OFF_LOCATION = 2520
OFF_FOV = 2428
OFF_PIXEL_SIZE = 2444

_SERIES_RE = re.compile(rb"HSUC/(\d+)/")


class FreError(ValueError):
    """Raised when a file is not a .fre image this module can read."""


def _f32(blob: bytes, offset: int) -> float:
    return float(struct.unpack(">f", blob[offset:offset + 4])[0])


def _i32(blob: bytes, offset: int) -> int:
    return int(struct.unpack(">i", blob[offset:offset + 4])[0])


def read_header(path) -> dict:
    """The geometry of one slice, without touching its pixels."""
    with open(path, "rb") as handle:
        blob = handle.read(HEADER_BYTES)
    if len(blob) < HEADER_BYTES or blob[:4] != MAGIC:
        raise FreError(f"{Path(path).name} is not a GE genesis image")

    width = _i32(blob, OFF_WIDTH)
    height = _i32(blob, OFF_HEIGHT)
    if not (0 < width <= 4096 and 0 < height <= 4096):
        raise FreError(f"{Path(path).name} reports an implausible size")

    pixel_mm = _f32(blob, OFF_PIXEL_SIZE)
    fov = _f32(blob, OFF_FOV)
    if not 0.01 < pixel_mm < 10.0:
        # The field of view is the same statement made another way, so it
        # stands in when the pixel size itself is not readable.
        pixel_mm = fov / float(width) if 10.0 < fov < 1000.0 else 0.0
    if pixel_mm <= 0.0:
        raise FreError(f"{Path(path).name} has no usable pixel size")

    match = _SERIES_RE.search(blob)
    return {
        "path": str(path),
        "width": width,
        "height": height,
        "bits": _i32(blob, OFF_DEPTH),
        "data_offset": _i32(blob, OFF_HEADER_LENGTH),
        "location": _f32(blob, OFF_LOCATION),
        "pixel_mm": float(pixel_mm),
        "field_of_view": float(fov),
        "series": int(match.group(1)) if match else 0,
    }


def looks_like_fre(path) -> bool:
    """Cheap check, so a folder can be identified without parsing it all."""
    try:
        with open(path, "rb") as handle:
            return handle.read(4) == MAGIC
    except OSError:
        return False


def read_slice(header: dict) -> np.ndarray:
    """One slice in Hounsfield units."""
    width, height = header["width"], header["height"]
    start = int(header["data_offset"]) or HEADER_BYTES
    count = width * height
    with open(header["path"], "rb") as handle:
        handle.seek(start)
        raw = handle.read(count * 2)
    if len(raw) < count * 2:
        raise FreError(f"{Path(header['path']).name} is truncated")
    samples = np.frombuffer(raw, dtype=">i2", count=count)
    return samples.reshape(height, width).astype(np.float32) - HU_OFFSET


def discover(folder) -> list[dict]:
    """Every .fre under ``folder``, grouped into series and ordered properly.

    Returns one entry per series, each with its slices sorted by position
    rather than by name.
    """
    folder = Path(folder)
    headers = []
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or not looks_like_fre(path):
            continue
        try:
            headers.append(read_header(path))
        except FreError:
            continue

    grouped: dict[int, list[dict]] = {}
    for header in headers:
        grouped.setdefault(header["series"], []).append(header)

    out = []
    for series, slices in sorted(grouped.items()):
        # Most superior first, which is the direction a CT is read in and the
        # order the file names imply even though they do not follow it.
        slices.sort(key=lambda h: -h["location"])
        positions = np.asarray([h["location"] for h in slices])
        gaps = np.abs(np.diff(positions)) if positions.size > 1 else np.zeros(1)
        real = gaps[gaps > 1e-6]
        sizes = sorted({round(h["pixel_mm"], 6) for h in slices})
        out.append({
            "series": series,
            "slices": slices,
            "count": len(slices),
            "first": float(positions[0]) if positions.size else 0.0,
            "last": float(positions[-1]) if positions.size else 0.0,
            "spacing": float(np.median(real)) if real.size else 1.0,
            "pixel_sizes": sizes,
            "duplicate_positions": int(
                positions.size - len(np.unique(np.round(positions, 3)))),
        })
    return out


def _rescale(image: np.ndarray, source_mm: float, target_mm: float,
             out_size: int) -> np.ndarray:
    """Put one slice onto the common grid, about the image centre.

    Nearest neighbour on purpose. The slices that need rescaling are the ones
    whose field of view differs, and those are being combined with slices that
    were not rescaled at all; interpolating one and not the other would make
    the join between two fields of view look like a change in the tissue.
    """
    height, width = image.shape
    centre_x = (width - 1) * 0.5
    centre_y = (height - 1) * 0.5
    out_centre = (out_size - 1) * 0.5

    axis = (np.arange(out_size, dtype=np.float64) - out_centre) * (
        target_mm / source_mm)
    cols = np.rint(axis + centre_x).astype(np.int64)
    rows = np.rint(axis + centre_y).astype(np.int64)

    inside_c = (cols >= 0) & (cols < width)
    inside_r = (rows >= 0) & (rows < height)
    out = np.full((out_size, out_size), -HU_OFFSET, dtype=np.float32)
    if inside_c.any() and inside_r.any():
        out[np.ix_(inside_r, inside_c)] = image[
            np.ix_(rows[inside_r], cols[inside_c])]
    return out


def load_series(entry: dict, target_mm: float = 0.0, out_size: int = 0,
                progress_cb=None):
    """Stack one series onto a single grid.

    Returns ``(volume, spacing, info)`` with ``volume`` indexed ``[z, y, x]``
    in Hounsfield units and ``spacing`` as ``(x, y, z)`` millimetres.

    ``target_mm`` is the pixel size every slice is put onto; left at zero it
    is the one most of the slices already use, which keeps the majority of the
    scan untouched and rescales the minority.
    """
    report = progress_cb or (lambda *_a, **_k: None)
    slices = entry["slices"]
    if not slices:
        raise FreError("that series has no slices")

    if target_mm <= 0.0:
        sizes = [round(h["pixel_mm"], 6) for h in slices]
        # The size most of the scan already uses, so the majority is left
        # untouched and the minority is resampled. Ties go to the finer of
        # the two rather than to whichever the set happened to yield first,
        # because an arbitrary answer here is one that changes between runs.
        target_mm = min(set(sizes), key=lambda mm: (-sizes.count(mm), mm))
    if out_size <= 0:
        # Wide enough to hold the largest field of view present, so nothing
        # is cropped away when the scan widens over the body.
        widest = max(h["pixel_mm"] * h["width"] for h in slices)
        out_size = int(round(widest / target_mm))
        out_size = max(out_size, max(h["width"] for h in slices))

    volume = np.empty((len(slices), out_size, out_size), dtype=np.float32)
    rescaled = 0
    for index, header in enumerate(slices):
        if index % 32 == 0:
            report(100.0 * index / len(slices),
                   f"Reading slice {index + 1} of {len(slices)}")
        image = read_slice(header)
        if (abs(header["pixel_mm"] - target_mm) < 1e-6
                and image.shape[0] == out_size
                and image.shape[1] == out_size):
            volume[index] = image
        else:
            volume[index] = _rescale(image, header["pixel_mm"], target_mm,
                                     out_size)
            rescaled += 1

    spacing = (float(target_mm), float(target_mm), float(entry["spacing"]))
    info = {
        "series": entry["series"],
        "slices": len(slices),
        "rescaled": rescaled,
        "pixel_mm": float(target_mm),
        "size": int(out_size),
        "pixel_sizes": entry["pixel_sizes"],
        "spacing": spacing,
        "first": entry["first"],
        "last": entry["last"],
        "duplicate_positions": entry["duplicate_positions"],
    }
    return volume, spacing, info
