"""Isosurface extraction using the Surface Nets algorithm.

Produces smooth meshes directly from volumetric data by placing vertices
at interpolated edge-crossing positions and connecting adjacent surface cells
with quad faces. This avoids the stair-stepping artifacts of voxel-based
approaches because vertices track the actual isosurface boundary rather than
snapping to grid positions.

References:
    Gibson, S.F.F. (1998). "Constrained Elastic Surface Nets"
"""

from __future__ import annotations

import numpy as np


# Corner positions of a unit cube (x, y, z) — 8 corners
_CORNER_POS = np.array(
    [
        [0, 0, 0],  # 0
        [1, 0, 0],  # 1
        [1, 1, 0],  # 2
        [0, 1, 0],  # 3
        [0, 0, 1],  # 4
        [1, 0, 1],  # 5
        [1, 1, 1],  # 6
        [0, 1, 1],  # 7
    ],
    dtype=np.float32,
)

# 12 edges of a cube defined by pairs of corner indices
_EDGE_PAIRS = np.array(
    [
        [0, 1],
        [1, 2],
        [2, 3],
        [3, 0],  # bottom ring
        [4, 5],
        [5, 6],
        [6, 7],
        [7, 4],  # top ring
        [0, 4],
        [1, 5],
        [2, 6],
        [3, 7],  # vertical edges
    ],
    dtype=np.int32,
)


_FACE_SLICES = (
    # The three families of square grid faces, as the four corner slices of
    # each: normal to x, to y, to z.
    ((slice(None, -1), slice(None, -1), slice(None)),
     (slice(None, -1), slice(1, None), slice(None)),
     (slice(1, None), slice(None, -1), slice(None)),
     (slice(1, None), slice(1, None), slice(None))),
    ((slice(None, -1), slice(None), slice(None, -1)),
     (slice(None, -1), slice(None), slice(1, None)),
     (slice(1, None), slice(None), slice(None, -1)),
     (slice(1, None), slice(None), slice(1, None))),
    ((slice(None), slice(None, -1), slice(None, -1)),
     (slice(None), slice(None, -1), slice(1, None)),
     (slice(None), slice(1, None), slice(None, -1)),
     (slice(None), slice(1, None), slice(1, None))),
)


def _close_alternating_faces(above, max_passes: int = 64):
    """Remove the corner patterns that make a non-manifold surface.

    Surface Nets puts one vertex in every cell the surface passes through and
    joins four of them around each grid edge that crosses. Two neighbouring
    cells therefore share a mesh edge carrying one quad per crossing along the
    square face between them. A surface that enters and leaves that face
    crosses two of its four sides, giving the two quads an edge is allowed to
    have. When the four corners of the face alternate solid, empty, solid,
    empty, all four sides cross, four quads land on the single edge, and the
    surface is pinched to a line there. Blender cannot give such an edge a
    consistent normal, which is what the bad shading is, and a remesh has no
    inside and outside to work from.

    Measured on a head reconstruction: 44,439 such faces and 44,439
    non-manifold edges - the same number, because each one makes exactly one.

    The pattern is broken by filling one of the two empty corners, which joins
    the two sheets instead of leaving them pinched. Filling can create the
    pattern somewhere else, so this repeats until none is left; filling never
    carves, so it cannot cycle and is bounded by the number of corners. Three
    passes and 0.235% of the solid corners on that reconstruction. A field
    noisy enough to make the pattern everywhere took twelve, which is why the
    cap is loose - stopping early leaves exactly the edges this is for.

    Returns ``(above, corners_filled)``.
    """
    filled = 0
    for _ in range(max(1, int(max_passes))):
        flips = np.zeros_like(above)
        found = 0
        for s00, s01, s10, s11 in _FACE_SLICES:
            c00, c01 = above[s00], above[s01]
            alt = (c00 == above[s11]) & (c01 == above[s10]) & (c00 != c01)
            if not alt.any():
                continue
            found += int(alt.sum())
            flips[s00] |= alt & ~c00
            flips[s01] |= alt & c00
        if not found:
            break
        above = above | flips
        filled += int(flips.sum())
    return above, filled


def extract_isosurface(
    volume: np.ndarray,
    isovalue: float,
    spacing: tuple[float, float, float] = (1.0, 1.0, 1.0),
    step_size: int = 1,
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0),
    progress_cb=None,
) -> tuple[np.ndarray, np.ndarray]:
    """Extract an isosurface mesh from a 3D volume using Surface Nets.

    Every closed component of the level set is extracted, including the walls of
    fully enclosed voids. Face winding is derived from which side of the
    isovalue each grid corner falls on, so a cavity's wall ends up facing into
    the cavity - i.e. outward from the solid material, same as the outer skin.

    Args:
        volume: 3D numpy array indexed as [z, y, x].
        isovalue: Scalar threshold defining the isosurface.
        spacing: Physical voxel spacing (sx, sy, sz).
        step_size: Process every Nth voxel along each axis (performance control).
        origin: World XYZ of voxel (0, 0, 0). Vertices are emitted in world
            space, so this must match the grid the volume came from - otherwise
            the mesh will not line up with the source point cloud.
        progress_cb: Optional callable taking a 0-100 float.

    Returns:
        Tuple of (vertices, faces) where vertices is Nx3 float32 array of
        world-space positions and faces is a list of index tuples (quads or tris).
    """
    if volume.ndim != 3:
        raise ValueError("Volume must be 3D")

    if step_size > 1:
        volume = volume[::step_size, ::step_size, ::step_size]
        spacing = (spacing[0] * step_size, spacing[1] * step_size, spacing[2] * step_size)

    nz, ny, nx = volume.shape
    if nz < 2 or ny < 2 or nx < 2:
        return np.empty((0, 3), dtype=np.float32), []

    sx, sy, sz = float(spacing[0]), float(spacing[1]), float(spacing[2])
    ox, oy, oz = float(origin[0]), float(origin[1]), float(origin[2])

    above = volume >= isovalue
    above, pinches_filled = _close_alternating_faces(above)
    if progress_cb is not None:
        progress_cb(5.0)

    # Identify surface cells: cells where the 8 corners are NOT all the same sign.
    # A cell at index (cz, cy, cx) spans volume[cz:cz+2, cy:cy+2, cx:cx+2].
    corner_sum = (
        above[:-1, :-1, :-1].astype(np.uint8)
        + above[1:, :-1, :-1]
        + above[:-1, 1:, :-1]
        + above[1:, 1:, :-1]
        + above[:-1, :-1, 1:]
        + above[1:, :-1, 1:]
        + above[:-1, 1:, 1:]
        + above[1:, 1:, 1:]
    )
    surface_mask = (corner_sum > 0) & (corner_sum < 8)

    # Assign vertex indices to surface cells
    cells = np.argwhere(surface_mask)  # (N, 3) with columns (cz, cy, cx)
    if cells.shape[0] == 0:
        return np.empty((0, 3), dtype=np.float32), []

    n_cells = cells.shape[0]
    vertex_index = np.full((nz - 1, ny - 1, nx - 1), -1, dtype=np.int32)
    vertex_index[surface_mask] = np.arange(n_cells, dtype=np.int32)

    # Compute vertex positions via edge-crossing interpolation.
    # For each surface cell, average the interpolated positions of all
    # isosurface crossings along its 12 edges.
    cz, cy, cx = cells[:, 0], cells[:, 1], cells[:, 2]

    # Gather 8 corner values for all surface cells
    v = np.empty((n_cells, 8), dtype=np.float32)
    v[:, 0] = volume[cz, cy, cx]
    v[:, 1] = volume[cz, cy, cx + 1]
    v[:, 2] = volume[cz, cy + 1, cx + 1]
    v[:, 3] = volume[cz, cy + 1, cx]
    v[:, 4] = volume[cz + 1, cy, cx]
    v[:, 5] = volume[cz + 1, cy, cx + 1]
    v[:, 6] = volume[cz + 1, cy + 1, cx + 1]
    v[:, 7] = volume[cz + 1, cy + 1, cx]

    # The same eight corners again as repaired signs. Taking the crossings
    # from the raw values instead would undo the repair: the faces would be
    # built from one set of signs and the vertices placed from another.
    a = np.empty((n_cells, 8), dtype=bool)
    a[:, 0] = above[cz, cy, cx]
    a[:, 1] = above[cz, cy, cx + 1]
    a[:, 2] = above[cz, cy + 1, cx + 1]
    a[:, 3] = above[cz, cy + 1, cx]
    a[:, 4] = above[cz + 1, cy, cx]
    a[:, 5] = above[cz + 1, cy, cx + 1]
    a[:, 6] = above[cz + 1, cy + 1, cx + 1]
    a[:, 7] = above[cz + 1, cy + 1, cx]

    # For each of 12 edges, find which cells have a crossing and interpolate
    pos_sum = np.zeros((n_cells, 3), dtype=np.float64)
    pos_count = np.zeros(n_cells, dtype=np.int32)

    iso = float(isovalue)
    for ei in range(12):
        i0, i1 = int(_EDGE_PAIRS[ei, 0]), int(_EDGE_PAIRS[ei, 1])
        val0 = v[:, i0]
        val1 = v[:, i1]

        # Edge crosses if endpoints differ in sign relative to isovalue
        crosses = a[:, i0] != a[:, i1]
        if not np.any(crosses):
            continue

        # Linear interpolation: t in [0,1] along edge
        denom = val1[crosses] - val0[crosses]
        denom = np.where(np.abs(denom) < 1e-10, 1e-10, denom)
        t = np.clip((iso - val0[crosses]) / denom, 0.0, 1.0)

        # Position in cell-local coords (x, y, z)
        p0 = _CORNER_POS[i0]  # shape (3,)
        p1 = _CORNER_POS[i1]  # shape (3,)
        pos = p0[np.newaxis, :] + t[:, np.newaxis] * (p1 - p0)[np.newaxis, :]

        cross_idx = np.where(crosses)[0]
        # Use np.add.at for correct accumulation with repeated indices
        np.add.at(pos_sum, cross_idx, pos.astype(np.float64))
        np.add.at(pos_count, cross_idx, 1)

    # Average crossing positions
    valid = pos_count > 0
    pos_sum[valid] /= pos_count[valid, np.newaxis]
    pos_sum[~valid] = 0.5  # Fallback: cell center (shouldn't happen)

    # Convert cell-local positions to world coordinates
    vertices = np.empty((n_cells, 3), dtype=np.float32)
    vertices[:, 0] = (cx.astype(np.float32) + pos_sum[:, 0].astype(np.float32)) * sx + ox
    vertices[:, 1] = (cy.astype(np.float32) + pos_sum[:, 1].astype(np.float32)) * sy + oy
    vertices[:, 2] = (cz.astype(np.float32) + pos_sum[:, 2].astype(np.float32)) * sz + oz

    if progress_cb is not None:
        progress_cb(55.0)

    # Generate faces: for each grid edge that crosses the isosurface,
    # create a quad connecting the 4 surface cells that share that edge.
    # Kept as numpy blocks and concatenated once. These used to be flattened
    # with ``.tolist()``, which turns every quad into its own Python list - a
    # few million of those is both slow to build and enormous in memory, and it
    # was the first half of a freeze when a large mesh reached Blender.
    face_blocks = []

    # X-direction edges: from grid point (gx,gy,gz) to (gx+1,gy,gz)
    # Crossing condition: above[gz,gy,gx] != above[gz,gy,gx+1]
    # Shared by cells at (cx=gx, cy=gy, cz=gz), (cx=gx, cy=gy-1, cz=gz),
    #                     (cx=gx, cy=gy, cz=gz-1), (cx=gx, cy=gy-1, cz=gz-1)
    # Valid when gy in [1, ny-2] and gz in [1, nz-2]
    if ny > 2 and nz > 2:
        x_cross = above[1:-1, 1:-1, :-1] != above[1:-1, 1:-1, 1:]  # (nz-2, ny-2, nx-1)
        if np.any(x_cross):
            gz, gy, gx = np.where(x_cross)
            gz += 1  # adjust for slicing offset
            gy += 1
            c0 = vertex_index[gz, gy, gx]
            c1 = vertex_index[gz, gy - 1, gx]
            c2 = vertex_index[gz - 1, gy - 1, gx]
            c3 = vertex_index[gz - 1, gy, gx]
            mask = (c0 >= 0) & (c1 >= 0) & (c2 >= 0) & (c3 >= 0)
            if np.any(mask):
                # Winding: flip based on edge direction for consistent normals
                sign = above[gz[mask], gy[mask], gx[mask]]
                q = np.empty((int(mask.sum()), 4), dtype=np.int32)
                q[:, 0] = c0[mask]
                q[:, 1] = np.where(sign, c1[mask], c3[mask])
                q[:, 2] = c2[mask]
                q[:, 3] = np.where(sign, c3[mask], c1[mask])
                face_blocks.append(q)

    # Y-direction edges: from grid point (gx,gy,gz) to (gx,gy+1,gz)
    # Shared by cells at (gx, gy, gz), (gx-1, gy, gz), (gx, gy, gz-1), (gx-1, gy, gz-1)
    # Valid when gx in [1, nx-2] and gz in [1, nz-2]
    if nx > 2 and nz > 2:
        y_cross = above[1:-1, :-1, 1:-1] != above[1:-1, 1:, 1:-1]  # (nz-2, ny-1, nx-2)
        if np.any(y_cross):
            gz, gy, gx = np.where(y_cross)
            gz += 1
            gx += 1
            c0 = vertex_index[gz, gy, gx]
            c1 = vertex_index[gz, gy, gx - 1]
            c2 = vertex_index[gz - 1, gy, gx - 1]
            c3 = vertex_index[gz - 1, gy, gx]
            mask = (c0 >= 0) & (c1 >= 0) & (c2 >= 0) & (c3 >= 0)
            if np.any(mask):
                sign = above[gz[mask], gy[mask], gx[mask]]
                q = np.empty((int(mask.sum()), 4), dtype=np.int32)
                q[:, 0] = c0[mask]
                q[:, 1] = np.where(sign, c3[mask], c1[mask])
                q[:, 2] = c2[mask]
                q[:, 3] = np.where(sign, c1[mask], c3[mask])
                face_blocks.append(q)

    # Z-direction edges: from grid point (gx,gy,gz) to (gx,gy,gz+1)
    # Shared by cells at (gx, gy, gz), (gx-1, gy, gz), (gx, gy-1, gz), (gx-1, gy-1, gz)
    # Valid when gx in [1, nx-2] and gy in [1, ny-2]
    if nx > 2 and ny > 2:
        z_cross = above[:-1, 1:-1, 1:-1] != above[1:, 1:-1, 1:-1]  # (nz-1, ny-2, nx-2)
        if np.any(z_cross):
            gz, gy, gx = np.where(z_cross)
            gy += 1
            gx += 1
            c0 = vertex_index[gz, gy, gx]
            c1 = vertex_index[gz, gy, gx - 1]
            c2 = vertex_index[gz, gy - 1, gx - 1]
            c3 = vertex_index[gz, gy - 1, gx]
            mask = (c0 >= 0) & (c1 >= 0) & (c2 >= 0) & (c3 >= 0)
            if np.any(mask):
                sign = above[gz[mask], gy[mask], gx[mask]]
                q = np.empty((int(mask.sum()), 4), dtype=np.int32)
                q[:, 0] = c0[mask]
                q[:, 1] = np.where(sign, c1[mask], c3[mask])
                q[:, 2] = c2[mask]
                q[:, 3] = np.where(sign, c3[mask], c1[mask])
                face_blocks.append(q)

    if progress_cb is not None:
        progress_cb(100.0)

    if face_blocks:
        faces = np.concatenate(face_blocks, axis=0)
    else:
        faces = np.zeros((0, 4), dtype=np.int32)
    return vertices, faces
