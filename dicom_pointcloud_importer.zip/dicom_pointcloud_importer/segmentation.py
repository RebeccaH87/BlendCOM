from __future__ import annotations

from collections import deque
import heapq

import numpy as np

from . import voxelgrid as _vg



MAX_CORE_FRACTION = 0.6
"""Largest share of the bone a core level may select and still be a core."""


def split_pointcloud_by_intensity(
    points: np.ndarray,
    intensities: np.ndarray,
    range_count: int = 6,
    stats: dict | None = None,
) -> list:
    """Separate a cloud into intensity ranges. The whole of segmentation.

    This is the intensity filter's principle, used to separate rather than to
    remove. That filter sorts every point by brightness and takes a *count* off
    one end - so its "20%" means the darkest fifth of the points, not the
    darkest fifth of the intensity scale. Doing the same thing with N cuts
    instead of one gives N ranges, each holding an equal share of the points.

    Rank rather than value matters on real data. Intensities are nowhere near
    uniform - a lumbar T2 series measured here had a median of 0.206 against a
    98th percentile of 0.995, so evenly spaced *value* bands put almost every
    point in the darkest one and left the rest nearly empty. Cutting by rank
    puts the detail where the points actually are.

    Nothing else is consulted: no grid, no connectivity, no thresholds. A range
    gathers its brightness from across the whole scan, wherever it occurs.

    Args:
        points: ``(N, 3)`` coordinates, any units.
        intensities: Per-point brightness; the only thing this splits on.
        range_count: How many ranges, 2-32. More means narrower.
        stats: Optional dict; receives the accounting.

    Returns:
        A list of arrays of **point indices**, darkest range first.
    """
    pts = np.asarray(points, dtype=np.float32)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] == 0:
        return []
    if intensities is None:
        raise ValueError(
            "Segmentation needs the cloud's Intensity attribute - brightness is "
            "the only thing it splits on. Re-import with a colour mode."
        )

    values = np.asarray(intensities, dtype=np.float32).reshape(-1)
    if values.shape[0] != pts.shape[0]:
        raise ValueError("Point and intensity buffers must match in length")

    count = int(np.clip(int(range_count), 2, 32))
    order = np.argsort(values, kind="stable")
    groups = [g for g in np.array_split(order, count) if g.size]

    report = []
    for index, group in enumerate(groups):
        band = values[group]
        report.append(
            {
                "range": (float(band.min()), float(band.max())),
                "points": int(group.size),
                "index": index,
            }
        )

    if stats is not None:
        stats.update(
            {
                "source": "pointcloud",
                "method": "intensity_ranges",
                "range_count": count,
                "ranges": report,
                "components_kept": len(groups),
                "components_found": len(groups),
                "input_points": int(pts.shape[0]),
                "kept_points": int(sum(int(g.size) for g in groups)),
            }
        )
    return groups


def build_points_from_point_indices(
    component_idx: np.ndarray,
    points: np.ndarray,
    intensities: np.ndarray,
    max_points: int,
) -> tuple[np.ndarray, np.ndarray]:
    idx = np.asarray(component_idx, dtype=np.int32)
    if idx.ndim != 1 or idx.shape[0] == 0:
        return np.empty((0, 3), dtype=np.float32), np.empty((0,), dtype=np.float32)

    if max_points > 0 and idx.shape[0] > max_points:
        rng = np.random.default_rng(42)
        keep = rng.choice(idx.shape[0], size=max_points, replace=False)
        idx = idx[keep]

    pts = np.asarray(points, dtype=np.float32)[idx]
    vals = np.asarray(intensities, dtype=np.float32).reshape(-1)[idx]
    return pts.astype(np.float32), vals.astype(np.float32)

