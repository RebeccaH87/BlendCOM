"""DICOM volumes as OpenVDB grids, for Blender's native Volume object.

A point cloud answers "where is this tissue"; a volume answers "what does the
scan look like". They are different questions and the second one Blender can
already render, so almost all of this module is about handing the data over in
the form Blender expects rather than about reconstructing anything.

Three things are worth knowing about the handover.

**The transform carries patient space.** A VDB grid has its own affine, in the
row-vector convention: the three voxel axes scaled by the voxel size sit in the
rows, and the origin in the last row. Filling it from the same origin,
orientation and spacing the point cloud path uses puts the volume exactly on
top of the clouds built from the same series - measured at 0.0000 mm against
the cloud placement on an oblique sagittal stack, where a transposed matrix
could not hide. A wrong convention is caught rather than tolerated: OpenVDB
refuses a non-affine matrix outright.

**The grid is written from the raw volume, not the enhanced one.** Enhancement
exists so a threshold has somewhere accurate to land, which matters for
meshing. A volume renderer interpolates the field itself, so resampling first
multiplies memory without adding information.

**Air is thrown away, which is what makes this affordable.** VDB stores only
the voxels that differ from its background value, so clipping everything below
the window to zero leaves a sparse grid. On a 195x512x512 CT that is 9.3 MB
against 59.8 MB dense - smaller than the DICOM series it came from.

Only :func:`write_grid` needs OpenVDB, which exists only inside Blender. The
rest is numpy, so the parts that can be wrong in a quiet way are testable.
"""

from __future__ import annotations

import hashlib
import re

import numpy as np

CACHE_FORMAT = 2
"""Bumped when a change makes previously written .vdb files wrong.

It goes into the cache key, so old files are simply never looked up again
rather than needing to be found and deleted.
"""


# --------------------------------------------------------------------------
# Windows
# --------------------------------------------------------------------------

HU_WINDOWS = {
    "BONE": (-450.0, 1050.0),
    "SOFT": (-150.0, 250.0),
    "LUNG": (-1350.0, 150.0),
    "FULL": (-1000.0, 2000.0),
}
"""Radiology windows as (low, high) in Hounsfield units.

Quoted in the clinic as a level and a width - bone is level 300, width 1500 -
which is the same thing said differently: low = level - width/2. They are
stored expanded because every use here wants the ends.
"""

PERCENTILE_WINDOWS = {
    "MID": (10.0, 90.0),
    "BRIGHT": (55.0, 99.9),
    "WIDE": (1.0, 99.5),
}
"""Windows expressed as percentiles of the data, for scans with no units.

An MR intensity means nothing on its own - it changes with the sequence, the
coil and the scanner - so there is no table to look a window up in. What can
still be said is "show the brightest half" or "ignore the extremes", and that
is what these are. They work on a CT too, they are simply less precise than
asking for a range of Hounsfield units.
"""

WINDOW_LABELS = {
    "BONE": "Bone",
    "SOFT": "Soft Tissue",
    "LUNG": "Lung",
    "FULL": "Everything",
    "AUTO": "Auto (from the data)",
    "MID": "Middle of the data",
    "BRIGHT": "Brightest only",
    "WIDE": "Nearly everything",
}


def resolve_window(volume, window: str = "AUTO", is_ct: bool = False):
    """The (low, high) to map onto 0..1, and a note if the ask was changed.

    A named Hounsfield window only means something on CT. Asked for one on an
    MR, every window used to collapse to the same automatic range: the control
    appeared to do nothing, and because the range decided the cache name, the
    same file came back each time with "already converted" - which reads as a
    broken cache rather than as a window that does not apply.
    """
    values = np.asarray(volume)
    name = str(window or "AUTO").upper()
    note = ""

    if name in HU_WINDOWS:
        if is_ct:
            return HU_WINDOWS[name][0], HU_WINDOWS[name][1], note
        note = (
            "{} is a Hounsfield window and this series is not a CT, so its "
            "numbers are not on that scale. Showing the middle of the data "
            "instead - the percentage windows work on any scan.".format(
                WINDOW_LABELS.get(name, name))
        )
        name = "MID"

    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return 0.0, 1.0, note
    if is_ct:
        tissue = finite[finite > -900.0]
        if tissue.size:
            finite = tissue

    lo_pct, hi_pct = PERCENTILE_WINDOWS.get(name, PERCENTILE_WINDOWS["WIDE"])
    low = float(np.percentile(finite, lo_pct))
    high = float(np.percentile(finite, hi_pct))
    if high - low < 1e-6:
        high = low + 1.0
    return low, high, note


def window_bounds(volume, window: str = "AUTO", is_ct: bool = False):
    """The (low, high) to map onto 0..1 for this volume.

    A named window only means anything on CT, where the numbers are calibrated
    Hounsfield units. MR intensities are arbitrary and differ between
    sequences, coils and scanners, so there is nothing to look a window up by
    and the ends come from the data instead. The high end is a percentile
    rather than the maximum because a handful of bright outliers - a marker, a
    bit of metal - would otherwise push everything else into the bottom of the
    range.
    """
    low, high, _note = resolve_window(volume, window, is_ct)
    return low, high


def to_unit(volume, low: float, high: float):
    """Map a window onto 0..1, with everything below it set to exactly zero.

    Exactly zero matters: that is the VDB background, and a voxel holding the
    background value costs nothing to store. Clipping rather than rescaling
    the tail is what makes the written file sparse.
    """
    values = np.asarray(volume, dtype=np.float32)
    span = float(high) - float(low)
    if abs(span) < 1e-9:
        span = 1.0
    scaled = (values - float(low)) / span
    if scaled.ndim == 0:
        return np.clip(scaled, 0.0, 1.0)
    # In place on the way out: a full-resolution CT is 200 MB a copy, and the
    # subtraction above has already made one.
    return np.clip(scaled, 0.0, 1.0, out=scaled)


def unit_to_source(unit, low: float, high: float):
    """The inverse of :func:`to_unit`, for reading a value back in HU.

    The window is recorded on the object so a shader ramp can be specified in
    Hounsfield units rather than in whatever 0..1 happened to fall out.
    """
    return float(low) + np.asarray(unit, dtype=np.float64) * (
        float(high) - float(low))


# --------------------------------------------------------------------------
# Geometry
# --------------------------------------------------------------------------

def transform_matrix(spacing, origin=None, orientation=None):
    """The 4x4 OpenVDB wants, placing voxel (0,0,0) where the scanner says.

    Row-vector convention: ``indexToWorld((ix, iy, iz))`` has to equal
    ``origin + ix*sx*row + iy*sy*col + iz*sz*normal``, which is exactly where
    :func:`pointcloud.build_points_from_volume` puts the same voxel. Without
    an origin and orientation the grid is centred on the world origin, which
    is what the import does when Use Scanner Position is off.
    """
    sx, sy, sz = (float(v) for v in spacing)
    if orientation is not None:
        row, col, normal = (np.asarray(v, dtype=np.float64)
                            for v in orientation)
        length = float(np.linalg.norm(normal))
        normal = normal / length if length > 1e-9 else np.cross(row, col)
    else:
        row = np.asarray([1.0, 0.0, 0.0])
        col = np.asarray([0.0, 1.0, 0.0])
        normal = np.asarray([0.0, 0.0, 1.0])
    start = (np.asarray(origin, dtype=np.float64) if origin is not None
             else np.zeros(3, dtype=np.float64))
    return [
        list(row * sx) + [0.0],
        list(col * sy) + [0.0],
        list(normal * sz) + [0.0],
        list(start) + [1.0],
    ]


def centred_placement(shape, spacing):
    """Origin and axes for a volume centred on the world origin.

    What this must match is not "centred" in the abstract but exactly what
    ``build_points_from_volume`` does with the same series when Use Scanner
    Position is off - and what it does there is ignore the patient
    orientation completely and lay the voxels out on the world axes. A volume
    that honoured the orientation would be correct in isolation and sitting at
    an angle to its own point cloud, which is worse. The offset itself is
    taken from ``volume_world_origin`` rather than repeated here, because that
    is the one place that arithmetic is allowed to live.

    Returns ``(origin, orientation)`` ready for :func:`transform_matrix`.
    """
    from .pointcloud import volume_world_origin

    spacing = (float(spacing[0]), float(spacing[1]), float(spacing[2]))
    identity = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
    return volume_world_origin(shape, spacing), identity


# --------------------------------------------------------------------------
# The cache
# --------------------------------------------------------------------------

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def cache_name(series_uid: str, low: float, high: float, half: bool = True,
               label: str = "", placement=None) -> str:
    """A file name that changes whenever the contents would.

    Everything that changes the written grid has to be in here, or the cache
    answers a question it was not asked. The window, because two windows of
    one series are two different grids. The precision, because that is what
    was written. And the placement, because a grid carries its own transform:
    a volume converted in patient space really is a different file from the
    same series centred on the origin, and handing the first one back for the
    second puts the scan a metre and a half from where it was asked for -
    which looks like nothing rendering rather than like a stale cache.

    The series UID is hashed rather than used directly: it is long, it is
    patient-identifying, and it is not always a legal file name.
    """
    parts = [str(series_uid), f"{float(low):.4f}", f"{float(high):.4f}",
             "half" if half else "full", str(CACHE_FORMAT)]
    if placement is not None:
        flat = np.asarray(placement, dtype=np.float64).reshape(-1)
        parts.extend(f"{float(v):.6f}" for v in flat)
    key = "|".join(parts)
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
    stem = _UNSAFE.sub("_", str(label or "volume")).strip("_")[:40] or "volume"
    return f"{stem}_{digest}.vdb"


# --------------------------------------------------------------------------
# Writing
# --------------------------------------------------------------------------

def write_grid(path, volume, spacing, origin=None, orientation=None,
               name: str = "density", half: bool = True):
    """Write one numpy volume to ``path`` as a .vdb, and say what it cost.

    ``volume`` is indexed ``[z, y, x]`` as everything else here is; OpenVDB
    indexes ``(x, y, z)``, so it is transposed on the way out. Returns a dict
    of what happened, for the status line and for the tests.
    """
    import openvdb                                   # Blender only

    values = np.asarray(volume, dtype=np.float32)
    if values.ndim != 3:
        raise ValueError("volume must be 3D")

    grid = openvdb.FloatGrid()
    grid.name = str(name)
    grid.copyFromArray(np.ascontiguousarray(np.transpose(values, (2, 1, 0))))
    grid.transform = openvdb.createLinearTransform(
        transform_matrix(spacing, origin, orientation))
    if half:
        # Half the file for a precision no scan justifies: the grid holds a
        # window mapped onto 0..1, and half floats resolve that far finer than
        # the noise already in the measurement.
        grid.saveFloatAsHalf = True

    path = str(path)
    openvdb.write(path, grids=[grid])

    import os
    occupied = float(np.mean(values > 0.0)) if values.size else 0.0
    return {
        "path": path,
        "grid": str(name),
        "shape": tuple(int(v) for v in values.shape),
        "voxels": int(values.size),
        "occupancy": occupied,
        "bytes": int(os.path.getsize(path)),
        "half": bool(half),
    }
