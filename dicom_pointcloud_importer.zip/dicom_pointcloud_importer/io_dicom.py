from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import tempfile
import zipfile
from typing import Callable

import struct as _struct

import numpy as np
import pydicom


@dataclass
class SeriesInfo:
    uid: str
    label: str
    count: int
    contrast: str = ""
    """Dixon reconstruction this series holds, or "" if it is not one."""
    modality: str = ""
    """``CT``, ``MR`` and so on. CT is calibrated in Hounsfield units, which
    is a different kind of measurement from MR brightness and has to be read
    differently - so the pipeline needs to know which it has."""
    localizer: bool = False
    """A planning image rather than a volume - three orthogonal planes, or a
    handful of thick slices. Stacking one as if it were a stack produces a
    slanted shape that looks like a settings problem and is not one."""
    position: float = 0.0
    """Patient coordinate of the station along its stacking axis.

    Whole-body studies are acquired as several stations, one series each, and
    the only thing that says which is the shoulders and which the pelvis is
    this number. Sorting on the description instead puts station 10 before
    station 2."""


@dataclass
class SourceContext:
    root_path: Path
    cleanup: Callable[[], None]


def _noop_cleanup() -> None:
    return None


def prepare_source(source_path: str, source_is_zip: bool) -> SourceContext:
    path = Path(source_path)
    if not path.exists():
        raise FileNotFoundError(f"Source path does not exist: {source_path}")

    if source_is_zip:
        if not zipfile.is_zipfile(path):
            raise ValueError("Source is marked as zip, but the file is not a valid zip archive.")
        tmp = tempfile.TemporaryDirectory(prefix="dicom_import_")
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(tmp.name)
        return SourceContext(Path(tmp.name), tmp.cleanup)

    if not path.is_dir():
        raise ValueError("Source must be a directory when 'Source Is Zip' is disabled.")

    return SourceContext(path, _noop_cleanup)


DICOM_MAGIC = b"DICM"

_VALID_VRS = frozenset(
    b"AE AS AT CS DA DS DT FD FL IS LO LT OB OD OF OL OV OW PN SH SL SQ "
    b"SS ST SV TM UC UI UL UN UR US UT UV".split()
)


def looks_like_dicom(file_path) -> bool:
    """Cheap check that a file is worth handing to the DICOM parser.

    This exists because of how the parser has to be called. Plenty of real
    DICOM files have no preamble, so reading them needs ``force=True``, which
    tells pydicom to skip the format check and parse whatever it is given.
    On a file that is not DICOM it reads whatever happens to sit where the
    length fields belong and tries to allocate that much: a 2.5 KB Python
    source file in a scan folder was measured asking for 1.8 GB. A folder
    holding a few thousand files of some other format therefore does not
    produce an error, it takes the machine down - which is exactly what a
    folder of Visible Human .Z files did.

    So the format is checked here, where it costs one short read, instead of
    being left to a parser that has been told not to check it.
    """
    try:
        with open(file_path, "rb") as handle:
            head = handle.read(144)
    except OSError:
        return False
    if len(head) < 8:
        return False
    if len(head) >= 132 and head[128:132] == DICOM_MAGIC:
        return True

    # No preamble. A headerless file still has to open with a plausible first
    # element: the file meta group or the identifying group, and then either a
    # valid two letter VR or an implicit length that fits inside the file.
    group = int.from_bytes(head[0:2], "little")
    if group not in (0x0002, 0x0008):
        return False
    if head[4:6] in _VALID_VRS:
        return True
    try:
        size = os.path.getsize(file_path)
    except OSError:
        return False
    return int.from_bytes(head[4:8], "little") <= size


def _iter_candidate_files(root: Path):
    """Every file under ``root``, DICOM or not.

    Deliberately unfiltered: the series scan counts what it looked at and
    tallies the extensions so that pointing at the wrong folder produces
    "none were DICOM (.png, .txt)" rather than silence. Filtering here made
    that message go blank. The guard against parsing the wrong thing belongs
    at the parse itself, in :func:`_read_dicom_header` and
    :func:`_fast_scan_header`, which is also where the cost was.
    """
    for file in root.rglob("*"):
        if file.is_file():
            yield file


def _read_dicom_header(file_path: Path):
    if not looks_like_dicom(file_path):
        return None
    try:
        return pydicom.dcmread(str(file_path), stop_before_pixels=True, force=True)
    except Exception:
        return None


DIXON_CONTRASTS = ("WATER", "FAT", "IN", "OPP")

DIXON_CONTRAST_LABELS = {
    "WATER": "Water",
    "FAT": "Fat",
    "IN": "In phase",
    "OPP": "Out of phase",
}

# Longest first, so "OPPOSED" is not matched as "OPP" inside a longer word and
# "INPHASE" is not reached by the bare "IN" token rule below.
_CONTRAST_SUBSTRINGS = (
    ("OPP", ("OUTOFPHASE", "OUTPHASE", "OPPOSEDPHASE", "OPPOSED", "DIXOP", "OPPHASE")),
    ("IN", ("INPHASE", "DIXIP", "DIXIN")),
    ("WATER", ("WATER", "DIXW")),
    ("FAT", ("FATONLY", "FAT", "DIXF")),
)

# Bare codes, matched only as a whole token. A description like "t1_vibe_dixon_F"
# carries the contrast in a one-letter suffix, and substring matching on "F"
# would fire on half the alphabet soup in a Siemens protocol name.
_CONTRAST_TOKENS = {
    "W": "WATER",
    "F": "FAT",
    "IP": "IN",
    "IN": "IN",
    "OP": "OPP",
    "OPP": "OPP",
    "O": "OPP",
}


def _contrast_tokens(*sources) -> tuple[str, list[str]]:
    """Uppercased text and word tokens from descriptions and ImageType values."""
    parts: list[str] = []
    for source in sources:
        if source is None:
            continue
        if isinstance(source, (list, tuple)):
            parts.extend(str(v) for v in source)
        else:
            parts.append(str(source))
    text = " ".join(parts).upper()
    cleaned = "".join(ch if ch.isalnum() else " " for ch in text)
    return "".join(text.split()), cleaned.split()


def classify_dixon_contrast(description=None, image_type=None) -> str:
    """Which Dixon reconstruction a series holds: WATER, FAT, IN, OPP or "".

    Read from the series description and ``ImageType`` together, because
    neither is dependable alone: the description is free text a site can set to
    anything, and ImageType carries the contrast on some scanners and not
    others. Returning "" when nothing matches is deliberate - a wrong guess
    here silently imports the wrong tissue, so an unrecognised series is left
    unclassified and shown as such rather than assigned a best guess.
    """
    squashed, tokens = _contrast_tokens(description, image_type)
    for contrast, needles in _CONTRAST_SUBSTRINGS:
        if any(needle in squashed for needle in needles):
            return contrast
    for token in tokens:
        hit = _CONTRAST_TOKENS.get(token)
        if hit:
            return hit
    return ""


_TAG_IMAGE_TYPE = (0x0008, 0x0008)
_TAG_MODALITY = (0x0008, 0x0060)
_TAG_SERIES_DESC = (0x0008, 0x103E)
_TAG_SLICE_THICK = (0x0018, 0x0050)
_TAG_SERIES_UID = (0x0020, 0x000E)
_TAG_POSITION = (0x0020, 0x0032)
_SCAN_TAGS = {
    _TAG_IMAGE_TYPE: "ImageType",
    _TAG_MODALITY: "Modality",
    _TAG_SERIES_DESC: "SeriesDescription",
    _TAG_SLICE_THICK: "SliceThickness",
    _TAG_SERIES_UID: "SeriesInstanceUID",
    _TAG_POSITION: "ImagePositionPatient",
}
_LAST_SCAN_TAG = max(_SCAN_TAGS)
_ITEM = (0xFFFE, 0xE000)
_ITEM_END = (0xFFFE, 0xE00D)
_SEQ_END = (0xFFFE, 0xE0DD)
_UNDEFINED_LENGTH = 0xFFFFFFFF
_LONG_VR = {b"OB", b"OW", b"OF", b"SQ", b"UT", b"UN", b"OD", b"OL", b"OV", b"UC", b"UR"}
_IMPLICIT_LE = "1.2.840.10008.1.2"
_EXPLICIT_BE = "1.2.840.10008.1.2.2"


def _file_meta(buf):
    """Transfer syntax UID and where the dataset begins, or ``(None, 0)``."""
    if len(buf) < 132 or buf[128:132] != b"DICM":
        return None, 0
    pos = 132
    if buf[pos:pos + 4] != b"\x02\x00\x00\x00":
        return "1.2.840.10008.1.2.1", pos
    group_length = _struct.unpack_from("<I", buf, pos + 8)[0]
    end = pos + 12 + group_length
    syntax = "1.2.840.10008.1.2.1"
    scan = pos + 12
    while scan + 8 <= min(end, len(buf)):
        group, elem = _struct.unpack_from("<HH", buf, scan)
        vr = buf[scan + 4:scan + 6]
        if vr in _LONG_VR:
            length = _struct.unpack_from("<I", buf, scan + 8)[0]
            head = 12
        else:
            length = _struct.unpack_from("<H", buf, scan + 6)[0]
            head = 8
        if (group, elem) == (0x0002, 0x0010):
            syntax = buf[scan + head:scan + head + length].decode(
                "ascii", "replace").strip("\x00 ")
            break
        scan += head + length
    return syntax, end


def _fast_scan_header(file_path, chunk: int = 65536, limit: int = 4 << 20):
    """The six tags the series list needs, read without building a Dataset.

    pydicom parses and objectifies every element of a header; this walks the
    bytes and stops at the last tag wanted. Measured 8x faster over 2,000 real
    files, with every one of the six fields matching pydicom exactly - which
    matters because scanning touches every file in the study, and a whole-body
    study is thousands of them.

    Returns ``None`` for anything it will not read confidently - big-endian
    transfer syntax, a truncated header, any parse error - and the caller falls
    back to pydicom, so an unusual file is slow rather than wrong.
    """
    try:
        with open(file_path, "rb") as handle:
            buf = handle.read(chunk)
            syntax, pos = _file_meta(buf)
            if syntax is None or syntax == _EXPLICIT_BE:
                return None
            implicit = syntax == _IMPLICIT_LE
            found: dict[str, str] = {}
            depth = 0
            while True:
                if pos + 8 > len(buf):
                    if len(buf) >= limit:
                        break
                    more = handle.read(chunk)
                    if not more:
                        break
                    buf += more
                    continue
                group, elem = _struct.unpack_from("<HH", buf, pos)
                tag = (group, elem)
                if tag in (_ITEM, _ITEM_END, _SEQ_END):
                    length = _struct.unpack_from("<I", buf, pos + 4)[0]
                    pos += 8
                    if tag == _SEQ_END and depth:
                        depth -= 1
                    elif tag == _ITEM and length != _UNDEFINED_LENGTH:
                        pos += length
                    continue
                if implicit:
                    length = _struct.unpack_from("<I", buf, pos + 4)[0]
                    head = 8
                else:
                    vr = buf[pos + 4:pos + 6]
                    if vr in _LONG_VR:
                        length = _struct.unpack_from("<I", buf, pos + 8)[0]
                        head = 12
                    else:
                        length = _struct.unpack_from("<H", buf, pos + 6)[0]
                        head = 8
                if length == _UNDEFINED_LENGTH:
                    # A sequence of unknown extent: step inside and let the
                    # delimiters unwind it. Skipping it blindly was what made
                    # the first attempt miss every tag past 0008,103E, which
                    # included the series UID - fast and completely wrong.
                    depth += 1
                    pos += head
                    continue
                if tag in _SCAN_TAGS:
                    if pos + head + length > len(buf):
                        more = handle.read(max(chunk, length))
                        if not more:
                            break
                        buf += more
                        continue
                    raw = buf[pos + head:pos + head + length]
                    found[_SCAN_TAGS[tag]] = raw.decode("ascii", "replace").strip("\x00 ")
                if tag >= _LAST_SCAN_TAG and depth == 0:
                    break
                pos += head + length
            return found if found.get("SeriesInstanceUID") else None
    except Exception:
        return None


def _scan_fields(file_path) -> dict | None:
    """Header fields for the series list, fast path first, pydicom as backstop."""
    fields = _fast_scan_header(file_path)
    if fields is None:
        header = _read_dicom_header(file_path)
        if header is None:
            return None
        uid = getattr(header, "SeriesInstanceUID", None)
        if not uid:
            return None
        position = getattr(header, "ImagePositionPatient", None)
        return {
            "SeriesInstanceUID": str(uid),
            "SeriesDescription": str(getattr(header, "SeriesDescription", "Series")),
            "Modality": str(getattr(header, "Modality", "")),
            "SliceThickness": str(getattr(header, "SliceThickness", "") or ""),
            "ImageType": "\\".join(str(v) for v in (getattr(header, "ImageType", []) or [])),
            "ImagePositionPatient": "\\".join(
                str(v) for v in (position or [])
            ),
        }
    return fields


def _as_floats(text: str) -> list:
    out = []
    for part in str(text or "").split("\\"):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(float(part))
        except ValueError:
            return []
    return out


_STUDY_INDEX_CACHE: dict = {}


def _study_index(root) -> dict:
    """Everything the addon needs from a study's headers, read once.

    Keyed by series UID, each entry holds that series' files and the header
    fields the series list is built from.

    One pass, because the file walk is not what costs - parsing 4,777 headers
    is 4.0s and listing the files is 0.07s. Scanning and then importing used to
    pay that 4.0s twice, and once more for every station imported. Reading only
    the six tags actually wanted was measured and changes nothing (1.07s against
    1.06s on 1,500 files): the cost is per-file overhead, not tag parsing.
    Threads make it worse - 4 workers took 8.90s against 4.08s sequential,
    because pydicom is pure Python and the GIL serialises it anyway.
    """
    files = sorted(_iter_candidate_files(root))
    signature = (str(root), len(files),
                 files[0].name if files else "", files[-1].name if files else "")
    cached = _STUDY_INDEX_CACHE.get(signature)
    if cached is not None:
        return cached

    index: dict = {}
    for file_path in files:
        fields = _scan_fields(file_path)
        if fields is None:
            continue
        uid = fields.get("SeriesInstanceUID")
        if not uid:
            continue
        try:
            thickness = float(fields.get("SliceThickness") or 0.0)
        except ValueError:
            thickness = 0.0
        entry = index.setdefault(
            str(uid),
            {
                "files": [],
                "desc": fields.get("SeriesDescription") or "Series",
                "modality": fields.get("Modality") or "",
                "thickness": thickness,
                "image_type": [
                    v for v in str(fields.get("ImageType") or "").split("\\") if v
                ],
                "positions": [],
            },
        )
        entry["files"].append(file_path)
        position = _as_floats(fields.get("ImagePositionPatient"))
        if len(position) >= 3:
            entry["positions"].append(position[:3])

    # One study at a time is the realistic case; this only stops a long session
    # across many studies from holding every index it ever built.
    if len(_STUDY_INDEX_CACHE) > 4:
        _STUDY_INDEX_CACHE.clear()
    _STUDY_INDEX_CACHE[signature] = index
    return index


def _series_file_index(root) -> dict:
    """Series UID to its files."""
    return {uid: info["files"] for uid, info in _study_index(root).items()}


def discover_series(source_path: str, source_is_zip: bool, stats: dict | None = None) -> list[SeriesInfo]:
    """List the DICOM series under a folder or zip.

    Args:
        stats: Optional dict; receives how many files were looked at, how many
            parsed as DICOM, and a breakdown of file extensions. Without it a
            source containing no DICOM at all is indistinguishable from one the
            reader choked on, and the user gets no clue which.
    """
    context = prepare_source(source_path, source_is_zip)
    extensions: dict[str, int] = {}
    files_scanned = 0
    try:
        for file_path in _iter_candidate_files(context.root_path):
            files_scanned += 1
            suffix = file_path.suffix.lower().lstrip(".")
            extensions[suffix] = extensions.get(suffix, 0) + 1

        # The same pass the importer uses, so scanning and then importing does
        # not read every header in the study twice.
        grouped = _study_index(context.root_path)
        dicom_files = sum(len(info["files"]) for info in grouped.values())

        out: list[SeriesInfo] = []
        for uid, info in grouped.items():
            info = dict(info)
            info["count"] = len(info["files"])
            label = f"{info['desc']} [{info['modality']}] ({info['count']} slices"
            thickness = float(info.get("thickness", 0.0) or 0.0)
            if thickness:
                label += f", {thickness:g}mm thick"
            label += ")"
            # Flagged right in the dropdown, because by the time a localizer has
            # been imported and meshed it looks like a settings problem.
            localizer = any(w in str(info["desc"]).lower()
                            for w in LOCALIZER_WORDS)
            if localizer:
                label += "  [LOCALIZER - not a volume]"
            elif int(info["count"]) < 10:
                label += "  [too few slices for 3D]"
            contrast = classify_dixon_contrast(info["desc"], info.get("image_type"))
            if contrast:
                label += f"  [{DIXON_CONTRAST_LABELS[contrast]}]"

            # The station is identified by the position of its stack, taken on
            # whichever axis the slices actually advance along.
            station = 0.0
            stack = info.get("positions") or []
            if stack:
                arr = np.asarray(stack, dtype=np.float64)
                if len(arr) > 1:
                    axis = int(np.argmax(np.abs(arr.max(axis=0) - arr.min(axis=0))))
                else:
                    axis = 2
                station = float(arr[:, axis].min())

            out.append(SeriesInfo(uid=uid, label=label, count=int(info["count"]),
                                  contrast=contrast, localizer=bool(localizer),
                                  modality=str(info.get("modality") or "").upper(),
                                  position=station))

        # A folder of GE .fre images is listed alongside anything DICOM that
        # is there, rather than instead of it: the Visible Human directories
        # hold both the originals and somebody's conversion of them.
        for entry in _fre_series(context.root_path):
            out.append(_fre_series_info(entry))
            if stats is not None:
                stats["fre_series"] = stats.get("fre_series", 0) + 1

        out.sort(key=lambda s: s.label.lower())
        return out
    finally:
        if stats is not None:
            stats["files_scanned"] = files_scanned
            stats["dicom_files"] = dicom_files
            stats["extensions"] = extensions
        context.cleanup()


FRE_PREFIX = "FRE:"
"""Marks a series identifier that names a .fre run rather than a DICOM one."""


_FRE_SERIES_CACHE: dict = {}


def _fre_series(root):
    """The .fre series under ``root``, or an empty list.

    Cached on the same reasoning as the DICOM study index: finding the series
    means reading the header of every file, and the listing then asks again
    for each preview it builds. Reading 1,734 headers three times over took
    ten seconds to show two thumbnails.
    """
    try:
        from .fre import discover
    except Exception:
        return []

    root = Path(root)
    try:
        names = sorted(p.name for p in root.rglob("*.fre"))
        if not names:
            names = sorted(p.name for p in root.rglob("*") if p.is_file())
        signature = (str(root), len(names),
                     names[0] if names else "", names[-1] if names else "")
    except OSError:
        signature = None

    if signature is not None:
        cached = _FRE_SERIES_CACHE.get(signature)
        if cached is not None:
            return cached
    try:
        found = discover(root)
    except Exception:
        return []
    if signature is not None:
        if len(_FRE_SERIES_CACHE) > 4:
            _FRE_SERIES_CACHE.clear()
        _FRE_SERIES_CACHE[signature] = found
    return found


def _fre_series_info(entry):
    """One .fre run described the way the series list expects."""
    sizes = entry["pixel_sizes"]
    label = "GE .fre series {} ({} slices, {:.0f} to {:.0f} mm)".format(
        entry["series"], entry["count"], entry["first"], entry["last"])
    if len(sizes) > 1:
        # Said in the list, because it is the thing that goes wrong silently:
        # one pixel size applied to all of them stretches part of the scan.
        label += "  [{} fields of view, rescaled]".format(len(sizes))
    return SeriesInfo(
        uid=f"{FRE_PREFIX}{entry['series']}",
        label=label,
        count=int(entry["count"]),
        contrast="",
        localizer=False,
        modality="CT",
        position=float(entry["first"]),
    )


def _load_fre_volume(root, series_uid, stats):
    """Stack a .fre run, with the geometry its own headers give."""
    from .fre import load_series

    wanted = str(series_uid)[len(FRE_PREFIX):]
    entries = _fre_series(root)
    entry = next((e for e in entries if str(e["series"]) == wanted), None)
    if entry is None:
        raise ValueError(f"No .fre series {wanted} at that path")

    volume, spacing, info = load_series(entry)
    if stats is not None:
        nz, ny, nx = volume.shape
        # Centred on the scanner axis in plane, and running from the most
        # superior slice downwards, which is the order discover() put them in.
        stats["volume_origin"] = (
            -(nx - 1) * spacing[0] * 0.5,
            -(ny - 1) * spacing[1] * 0.5,
            float(info["first"]),
        )
        stats["volume_orientation"] = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
                                       (0.0, 0.0, -1.0))
        stats["has_patient_geometry"] = True
        stats["modality"] = "CT"
        stats["series_description"] = f"GE .fre series {info['series']}"
        stats["slice_count"] = int(info["slices"])
        stats["slice_thickness"] = float(spacing[2])
        stats["slice_spacing"] = float(spacing[2])
        stats["in_plane_spacing"] = float(min(spacing[0], spacing[1]))
        stats["is_localizer"] = False
        stats["slice_gaps"] = 0
        stats["duplicate_slices"] = int(info["duplicate_positions"])
        notes = []
        if info["rescaled"]:
            notes.append(
                "{} of {} slices were reconstructed at a different field of "
                "view and have been rescaled onto {:.4f} mm pixels. The scan "
                "changes field of view partway down, so a single pixel size "
                "taken from one part of it distorts the rest.".format(
                    info["rescaled"], info["slices"], info["pixel_mm"]))
        if info["duplicate_positions"]:
            notes.append("{} slices share a position with another.".format(
                info["duplicate_positions"]))
        stats["geometry_warnings"] = notes
    return volume, spacing


def _sort_key(ds):
    position = getattr(ds, "ImagePositionPatient", None)
    if position and len(position) >= 3:
        return float(position[2])
    return float(getattr(ds, "InstanceNumber", 0.0))


def stack_normal(ds):
    """The direction a stack advances in, as a unit vector.

    ``ImageOrientationPatient`` gives the two in-plane axes; their cross
    product is the through-plane one. The sign is not fixed by the tag, so it
    is chosen to make the largest component positive. That makes an axial
    stack sort by increasing z exactly as before, and gives a sagittal or
    coronal one the same kind of deterministic order instead of sorting it by
    an axis it barely moves along.
    """
    orient = getattr(ds, "ImageOrientationPatient", None)
    if orient is not None and len(orient) >= 6:
        row = np.asarray([float(v) for v in orient[:3]], dtype=np.float64)
        col = np.asarray([float(v) for v in orient[3:6]], dtype=np.float64)
        normal = np.cross(row, col)
    else:
        normal = np.asarray([0.0, 0.0, 1.0], dtype=np.float64)
    length = float(np.linalg.norm(normal))
    if length < 1e-9:
        return np.asarray([0.0, 0.0, 1.0], dtype=np.float64)
    normal = normal / length
    if normal[int(np.argmax(np.abs(normal)))] < 0.0:
        normal = -normal
    return normal


def _depth_along(ds, normal):
    """How far up the stack one slice sits, in mm.

    Hard-coding index 2 of ``ImagePositionPatient`` works for an axial series
    and nothing else: a sagittal stack advances along x, so every slice
    reports nearly the same z and the order comes down to whatever the sort
    does with ties - that is, to the order the files happened to be read in.
    Projecting onto the through-plane axis asks the question the tag was
    meant to answer, and handles an oblique stack as well as a cardinal one.
    """
    position = getattr(ds, "ImagePositionPatient", None)
    if position is not None and len(position) >= 3:
        pos = np.asarray([float(v) for v in position[:3]], dtype=np.float64)
        return float(np.dot(pos, normal))
    return float(getattr(ds, "InstanceNumber", 0.0))


def stack_report(depths, thickness: float = 0.0) -> dict:
    """What the slice positions say about whether this is one clean stack.

    Returns the spacing to use plus a list of warnings. The spacing is the
    median gap, not the mean: one missing slice leaves a double gap, and a
    mean over that stretches every slice in the volume to cover ground the
    scanner never measured. The median ignores a handful of such gaps
    entirely, so the spacing stays right and the problem is reported instead
    of being silently absorbed into the geometry.
    """
    out = {"slice_spacing": 0.0, "stack_warnings": [], "slice_gaps": 0,
           "duplicate_slices": 0, "tied_slices": 0}
    depths = np.sort(np.asarray(depths, dtype=np.float64))
    if depths.size < 2:
        return out

    gaps = np.diff(depths)
    real = gaps[gaps > 1e-6]
    duplicates = int(gaps.size - real.size)
    out["duplicate_slices"] = duplicates
    if real.size == 0:
        # Every slice at the same depth is not a stack at all. A three-plane
        # localizer looks like this: three fans about one point.
        out["tied_slices"] = int(depths.size)
        out["stack_warnings"].append(
            "All {:d} slices report the same position, so they are not a "
            "stack. This is usually a localizer or a mixed series; stacking "
            "it gives a shape that is not anatomy.".format(int(depths.size))
        )
        return out

    step = float(np.median(real))
    out["slice_spacing"] = step

    if duplicates:
        out["stack_warnings"].append(
            "{:d} slice(s) sit at the same position as another. They are "
            "stacked as if they were separate, which repeats that piece of "
            "anatomy and shifts everything after it.".format(duplicates)
        )

    # A gap is only a gap if it is close to a whole multiple of the step; a
    # scanner that varied the spacing slightly is a different complaint.
    if step > 1e-6:
        multiples = real / step
        missing = int(np.sum(np.rint(multiples[multiples > 1.5]) - 1.0))
        if missing > 0:
            out["slice_gaps"] = missing
            total = int(depths.size) + missing
            out["stack_warnings"].append(
                "{:d} slice(s) are missing from this series - it has {:d} of "
                "the {:d} the positions span. They are stacked without the "
                "gaps, so everything past a gap sits too close to the "
                "start.".format(missing, int(depths.size), total)
            )

        ragged = real[(multiples > 1.02) & (multiples < 1.5)]
        if ragged.size > max(1, int(0.05 * real.size)):
            out["stack_warnings"].append(
                "Slice spacing varies from {:.2f} to {:.2f} units against a "
                "typical {:.2f}. The volume is built on an even grid, so "
                "slices do not sit exactly where they were "
                "measured.".format(float(real.min()), float(real.max()), step)
            )

    if thickness > 0.0 and step > 1e-6 and step > 1.25 * thickness:
        out["stack_warnings"].append(
            "Slices are {:.1f} units apart but only {:.1f} thick, so {:.0f}% "
            "of the region was never imaged. The gaps are filled by "
            "interpolation, not measurement.".format(
                step, thickness, 100.0 * (1.0 - thickness / step))
        )
    return out


LOCALIZER_WORDS = ("localizer", "localiser", "scout", "survey", "topogram", "plan")
"""Series descriptions that mean "this is a planning image, not a volume"."""


def assess_series_geometry(header, slice_count: int, spacing) -> dict:
    """Judge whether a series can support a 3D reconstruction at all.

    This exists because of a case that cost an entire debugging session. The
    series was an MR "Lumb localizer": three sagittal slices, 15 mm thick, 15 mm
    apart. In-plane it looks like a detailed lumbar spine and the point cloud
    renders beautifully, so every failure to mesh the vertebrae looked like a
    tuning problem - and no amount of tuning could ever have worked, because
    through-plane there are three samples, each an average over 15 mm of tissue.
    A localizer is for positioning the real scan; it is not a volume.

    Returns a dict of measurements plus a ``geometry_warnings`` list.
    """
    warnings = []
    description = str(getattr(header, "SeriesDescription", "") or "")
    thickness = float(getattr(header, "SliceThickness", 0.0) or 0.0)
    in_plane = min(float(spacing[0]), float(spacing[1]))
    step = float(spacing[2])

    lowered = description.lower()
    is_localizer = any(word in lowered for word in LOCALIZER_WORDS)
    if is_localizer:
        warnings.append(
            "'{}' is a localizer/scout series - a planning image, not a volume. It "
            "cannot support a 3D reconstruction however the settings are tuned. Import "
            "the diagnostic series instead.".format(description)
        )

    if slice_count < 10:
        warnings.append(
            "This series has only {:d} slice(s). Anything through-plane will be "
            "interpolation between them, not measured anatomy.".format(slice_count)
        )

    if in_plane > 0 and step > 6.0 * in_plane:
        warnings.append(
            "Slice spacing is {:.1f} units against {:.2f} in-plane - {:.0f}x "
            "anisotropic. Through-plane detail cannot be recovered at that ratio; "
            "structures will smear along the slice axis.".format(
                step, in_plane, step / in_plane
            )
        )

    if thickness > 0 and thickness > 3.0 * max(step, 1e-6):
        warnings.append(
            "Each slice is {:.1f} units thick but they are only {:.1f} apart, so every "
            "sample is an average through overlapping tissue. Contrast between small "
            "structures is averaged away before it reaches the mesher.".format(
                thickness, step
            )
        )
    elif thickness >= 8.0:
        warnings.append(
            "Each slice averages over {:.0f} units of tissue. Structures thinner than "
            "that - cortical bone, discs - are blended with their surroundings, so the "
            "intensity contrast that would separate them is not in the data.".format(
                thickness
            )
        )

    return {
        "series_description": description,
        "slice_count": int(slice_count),
        "slice_thickness": thickness,
        "slice_spacing": step,
        "in_plane_spacing": in_plane,
        "is_localizer": bool(is_localizer),
        "geometry_warnings": warnings,
    }


def _fre_thumbnail_pixels(root, target_uid):
    """The middle slice of a .fre run, by position rather than by name.

    By position because the file names do not follow it: one folder holds two
    series whose names run straight through both, so the middle name can be
    in the other series entirely. :func:`fre.discover` has already put each
    run in order, so the middle of that list is the middle of the body.
    """
    from .fre import FreError, read_slice

    wanted = str(target_uid)[len(FRE_PREFIX):]
    entry = next((e for e in _fre_series(root)
                  if str(e["series"]) == wanted), None)
    if entry is None or not entry["slices"]:
        return None
    try:
        return read_slice(entry["slices"][len(entry["slices"]) // 2])
    except (FreError, OSError):
        return None


def load_series_thumbnail(source_path: str, source_is_zip: bool, target_uid: str,
                          size: int = 96):
    """A small square preview of one series, as floats in 0..1.

    The middle slice rather than the first: the first slice of a stack is
    usually the edge of the field of view, where there is little to recognise,
    while the middle is the part someone is trying to identify.

    Returns ``None`` when the series has no readable pixels, so a preview that
    cannot be built is simply absent rather than fatal to the whole listing.
    """
    context = prepare_source(source_path, source_is_zip)
    try:
        if str(target_uid).startswith(FRE_PREFIX):
            pixels = _fre_thumbnail_pixels(context.root_path, target_uid)
        else:
            files = _series_file_index(context.root_path).get(
                str(target_uid), [])
            if not files:
                return None
            ordered = sorted(files)
            chosen = ordered[len(ordered) // 2]
            try:
                ds = pydicom.dcmread(str(chosen), force=True)
                pixels = ds.pixel_array.astype(np.float32)
            except Exception:
                return None
        if pixels is None or pixels.ndim != 2 or pixels.size == 0:
            return None

        # Window on percentiles, not the extremes: a single bright artefact
        # otherwise drives everything else to black.
        low = float(np.percentile(pixels, 2.0))
        high = float(np.percentile(pixels, 98.0))
        if high <= low:
            high = low + 1.0
        normalised = np.clip((pixels - low) / (high - low), 0.0, 1.0)

        # Pad to square before resizing, so the preview keeps the anatomy's
        # proportions instead of stretching a wide chest into a square.
        rows, cols = normalised.shape
        side = max(rows, cols)
        square = np.zeros((side, side), dtype=np.float32)
        top = (side - rows) // 2
        left = (side - cols) // 2
        square[top:top + rows, left:left + cols] = normalised

        step = max(1, side // max(1, int(size)))
        trimmed = square[: (side // step) * step, : (side // step) * step]
        reduced = trimmed.reshape(
            trimmed.shape[0] // step, step, trimmed.shape[1] // step, step
        ).mean(axis=(1, 3))

        out = np.zeros((int(size), int(size)), dtype=np.float32)
        take = min(int(size), reduced.shape[0])
        out[:take, :take] = reduced[:take, :take]
        return out
    finally:
        context.cleanup()


def load_series_volume(
    source_path: str, source_is_zip: bool, target_uid: str, stats: dict | None = None
):
    context = prepare_source(source_path, source_is_zip)
    try:
        if str(target_uid).startswith(FRE_PREFIX):
            return _load_fre_volume(context.root_path, target_uid, stats)
        slices = []
        # Only the files of this series are opened. Reading every file in the
        # study - pixel data and all - to find the 64 that matched meant
        # decoding 4,777 images per station.
        for file_path in _series_file_index(context.root_path).get(target_uid, []):
            try:
                ds = pydicom.dcmread(str(file_path), force=True)
                pixel = ds.pixel_array.astype(np.float32)
            except Exception:
                continue

            slope = float(getattr(ds, "RescaleSlope", 1.0) or 1.0)
            intercept = float(getattr(ds, "RescaleIntercept", 0.0) or 0.0)
            pixel = pixel * slope + intercept
            slices.append((ds, pixel))

        if not slices:
            raise ValueError("No readable DICOM slices found for selected series.")

        normal = stack_normal(slices[0][0])
        slices.sort(key=lambda item: _depth_along(item[0], normal))

        arrays = [item[1] for item in slices]
        volume = np.stack(arrays, axis=0)

        first = slices[0][0]
        pixel_spacing = getattr(first, "PixelSpacing", [1.0, 1.0])
        sx = float(pixel_spacing[1]) if len(pixel_spacing) > 1 else 1.0
        sy = float(pixel_spacing[0]) if len(pixel_spacing) > 0 else 1.0

        sz = float(getattr(first, "SliceThickness", 1.0) or 1.0)
        positions = []
        for ds, _ in slices:
            pos = getattr(ds, "ImagePositionPatient", None)
            if pos and len(pos) >= 3:
                positions.append([float(v) for v in pos[:3]])

        # Measured along the axis the stack actually advances along, which is
        # the same one it was just sorted by.
        stack = stack_report(
            [float(np.dot(np.asarray(p, dtype=np.float64), normal))
             for p in positions],
            thickness=float(getattr(first, "SliceThickness", 0.0) or 0.0),
        )
        if stack["slice_spacing"] > 1e-6:
            sz = stack["slice_spacing"]

        spacing = (sx, sy, sz)

        # Where voxel (0, 0, 0) sits in patient coordinates, and which way the
        # axes point. Reported through stats rather than the return value so
        # existing callers are untouched.
        #
        # Without this every cloud is centred on the world origin, which is
        # only correct for one series at a time: a whole-body study acquired as
        # several stations comes in with every station stacked on top of the
        # others, and two contrasts of different field of view do not line up
        # either. The tag that says where each one belongs was being read for
        # slice spacing and then discarded.
        if stats is not None:
            orient = getattr(first, "ImageOrientationPatient", None)
            if orient is not None and len(orient) >= 6:
                row = np.asarray([float(v) for v in orient[:3]], dtype=np.float64)
                col = np.asarray([float(v) for v in orient[3:6]], dtype=np.float64)
            else:
                row = np.asarray([1.0, 0.0, 0.0])
                col = np.asarray([0.0, 1.0, 0.0])
            if len(positions) > 1:
                step = np.asarray(positions[-1]) - np.asarray(positions[0])
                norm = float(np.linalg.norm(step))
                # From the slice positions themselves, not row x col: the cross
                # product gives the right line but not which way along it the
                # stack was sorted, and a flipped normal mirrors the volume.
                normal = step / norm if norm > 1e-9 else np.cross(row, col)
            else:
                normal = np.cross(row, col)
            stats["volume_origin"] = tuple(
                float(v) for v in (positions[0] if positions else (0.0, 0.0, 0.0))
            )
            stats["volume_orientation"] = (
                tuple(float(v) for v in row),
                tuple(float(v) for v in col),
                tuple(float(v) for v in normal),
            )
            stats["has_patient_geometry"] = bool(positions)
        if stats is not None:
            stats.update(
                assess_series_geometry(first, len(slices), spacing)
            )
            stats["modality"] = str(
                getattr(first, "Modality", "") or "").upper()
            stats["slice_gaps"] = int(stack["slice_gaps"])
            stats["duplicate_slices"] = int(stack["duplicate_slices"])
            # Ahead of the tuning advice: a scrambled or gappy stack is not a
            # settings problem and cannot be tuned out of.
            stats["geometry_warnings"] = (
                list(stack["stack_warnings"])
                + list(stats.get("geometry_warnings") or [])
            )
        return volume, spacing
    finally:
        context.cleanup()
